# 🌕 Mangetsu

**A modern, modular, source-agnostic manga reader for Android.**

Built with Clean Architecture, Jetpack Compose, and a first-class extension system — inspired by Tachiyomi but designed from scratch with a cleaner separation of concerns.

> Mangetsu (満月) means "full moon" in Japanese.

---

## ✨ Features

- 📚 **Library management** — add, favourite, track manga
- 🔍 **Source browsing** — popular, latest, search with filters
- 📖 **Chapter reader** — horizontal pager + vertical/webtoon scroll modes
- 🔌 **Extension system** — install content sources as APKs at runtime
- 📦 **Repository system** — add custom source repos by URL
- 📥 **Offline downloads** — save chapters for offline reading
- 🕐 **Reading history** — resume where you left off
- 💾 **Backup & restore** — JSON export/import of your entire library
- 🌙 **Material 3 + dark mode** — adaptive colour schemes

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────┐
│                      app                            │
│  Compose UI · ViewModels · Hilt DI · Navigation     │
└────────────────────────┬────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────┐
│                     domain                          │
│     Use Cases  ·  Repository Interfaces             │
└────────────────────────┬────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────┐
│                      data                           │
│  Room DB · OkHttp · ExtensionLoader · WorkManager   │
└────────────────────────┬────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────┐
│                      core                           │
│          Domain Models · Utilities · Mappers         │
└────────────────────────┬────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────┐
│                  extension-api                      │
│   MangaSource interface · SManga · SChapter · SPage  │
└─────────────────────────────────────────────────────┘
```

---

## 🔌 Extension System

Extensions are separate APKs installed alongside the main app. They implement the `MangaSource` interface and are loaded via `PathClassLoader` at runtime.

```kotlin
class MySource : MangaSource {
    override val id   = 9876543210L
    override val name = "My Source"
    override val lang = "en"

    override suspend fun fetchPopularManga(page: Int): MangasPage { ... }
    override suspend fun fetchChapterList(manga: SManga): List<SChapter> { ... }
    override suspend fun fetchPageList(chapter: SChapter): List<SPage> { ... }
}
```

See [`docs/EXTENSION_GUIDE.md`](docs/EXTENSION_GUIDE.md) for the full developer guide.

---

## 📦 Repository System

Users can add extension repositories by URL. The app fetches an `index.json`:

```json
[
  {
    "name": "My Source",
    "package": "com.example.mysource",
    "apkUrl": "https://yourhost.com/my-source.apk",
    "version": "1.0.0",
    "versionCode": 1,
    "lang": "en",
    "sourceId": 9876543210
  }
]
```

---

## 🚀 Building

### Requirements

- Android Studio Hedgehog or newer
- JDK 17
- Android SDK 34

### Clone & build

```bash
git clone https://github.com/yourusername/mangetsu.git
cd mangetsu
./gradlew assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### CI / GitHub Actions

Every push to `main` or `develop` triggers an automated build.  
Release APKs (unsigned) are produced on every merge to `main`.

See [`.github/workflows/build.yml`](.github/workflows/build.yml).

---

## 📁 Module Structure

| Module            | Purpose                                          |
|-------------------|--------------------------------------------------|
| `extension-api`   | Pure Kotlin — `MangaSource` interface + models   |
| `core`            | Domain models, mappers, `Result<T>` utility      |
| `domain`          | Repository interfaces + all use cases            |
| `data`            | Room DB, OkHttp, extension loader/installer, impls|
| `app`             | Compose UI, ViewModels, Hilt DI, Navigation      |
| `extension-template` | Starter project for extension developers      |

---

## 📄 License

```
Copyright 2024 Mangetsu Contributors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0
```

---

## ⚠️ Disclaimer

Mangetsu is a **source-agnostic reading platform**. It contains no manga content
and no scrapers. Extensions are developed and distributed independently by third
parties. The Mangetsu project is not responsible for the content or legality of
any user-installed extension.
