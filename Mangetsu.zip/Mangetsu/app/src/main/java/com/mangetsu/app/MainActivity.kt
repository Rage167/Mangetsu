package com.mangetsu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CollectionsBookmark
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mangetsu.app.navigation.MangetsuNavGraph
import com.mangetsu.app.navigation.Screen
import com.mangetsu.app.ui.theme.MangetsuTheme
import com.mangetsu.data.updates.LibraryUpdateService
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

// ── Nav badge state ───────────────────────────────────────────────────────────

data class NavBadges(val updateCount: Int = 0)

@HiltViewModel
class NavViewModel @Inject constructor(
    updateService: LibraryUpdateService
) : ViewModel() {
    val badges: StateFlow<NavBadges> = updateService.updates
        .map { updates -> NavBadges(updateCount = updates.size) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NavBadges())
}

// ── Activity ──────────────────────────────────────────────────────────────────

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MangetsuTheme {
                val windowSizeClass = calculateWindowSizeClass(this)
                val useRail = windowSizeClass.widthSizeClass >= WindowWidthSizeClass.Medium
                MangetsuApp(useRail = useRail)
            }
        }
    }
}

// ── Nav items ─────────────────────────────────────────────────────────────────

private data class NavItem(
    val screen:       Screen,
    val label:        String,
    val icon:         ImageVector,
    val selectedIcon: ImageVector
)

private val navItems = listOf(
    NavItem(Screen.Library,    "Library",    Icons.Outlined.CollectionsBookmark, Icons.Filled.CollectionsBookmark),
    NavItem(Screen.Browse,     "Browse",     Icons.Outlined.Search,              Icons.Filled.Search),
    NavItem(Screen.Extensions, "Extensions", Icons.Outlined.Extension,           Icons.Filled.Extension),
    NavItem(Screen.History,    "History",    Icons.Outlined.History,             Icons.Filled.History),
    NavItem(Screen.Settings,   "Settings",   Icons.Outlined.Settings,            Icons.Filled.Settings),
)

private val topLevelRoutes = navItems.map { it.screen.route }.toSet()

// ── Root composable ───────────────────────────────────────────────────────────

@Composable
private fun MangetsuApp(
    useRail: Boolean = false,
    vm: NavViewModel = hiltViewModel()
) {
    val navController = rememberNavController()
    val backStack     by navController.currentBackStackEntryAsState()
    val currentRoute  = backStack?.destination?.route
    val badges        by vm.badges.collectAsStateWithLifecycle()
    val showNav       = currentRoute in topLevelRoutes

    fun navigate(screen: Screen) {
        navController.navigate(screen.route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState    = true
        }
    }

    if (useRail) {
        // Tablet / landscape: side rail
        Row(Modifier.fillMaxSize()) {
            AnimatedVisibility(visible = showNav) {
                MangetsuNavRail(
                    currentRoute = currentRoute,
                    badges       = badges,
                    onNavigate   = ::navigate
                )
            }
            MangetsuNavGraph(navController = navController)
        }
    } else {
        // Phone: bottom bar
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                AnimatedVisibility(
                    visible = showNav,
                    enter   = fadeIn(tween(200)) + slideInVertically { it },
                    exit    = fadeOut(tween(200)) + slideOutVertically { it }
                ) {
                    MangetsuBottomBar(
                        currentRoute = currentRoute,
                        badges       = badges,
                        onNavigate   = ::navigate
                    )
                }
            }
        ) { _ ->
            MangetsuNavGraph(navController = navController)
        }
    }
}

// ── Bottom navigation bar ─────────────────────────────────────────────────────

@Composable
private fun MangetsuBottomBar(
    currentRoute: String?,
    badges:       NavBadges,
    onNavigate:   (Screen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        windowInsets   = WindowInsets.navigationBars
    ) {
        navItems.forEach { item ->
            val selected    = currentRoute == item.screen.route
            val badgeCount  = if (item.screen == Screen.Extensions) badges.updateCount else 0

            NavigationBarItem(
                selected = selected,
                onClick  = { onNavigate(item.screen) },
                icon     = {
                    NavIcon(item = item, selected = selected, badgeCount = badgeCount)
                },
                label    = {
                    AnimatedContent(
                        targetState = selected,
                        transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(150)) },
                        label = "navLabel"
                    ) { isSelected ->
                        Text(
                            item.label,
                            style = if (isSelected) MaterialTheme.typography.labelMedium
                                    else MaterialTheme.typography.labelSmall
                        )
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor   = MaterialTheme.colorScheme.primary,
                    selectedTextColor   = MaterialTheme.colorScheme.primary,
                    indicatorColor      = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

// ── Navigation rail (tablet) ──────────────────────────────────────────────────

@Composable
private fun MangetsuNavRail(
    currentRoute: String?,
    badges:       NavBadges,
    onNavigate:   (Screen) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        navItems.forEach { item ->
            val selected   = currentRoute == item.screen.route
            val badgeCount = if (item.screen == Screen.Extensions) badges.updateCount else 0

            NavigationRailItem(
                selected = selected,
                onClick  = { onNavigate(item.screen) },
                icon     = { NavIcon(item = item, selected = selected, badgeCount = badgeCount) },
                label    = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                colors   = NavigationRailItemDefaults.colors(
                    selectedIconColor   = MaterialTheme.colorScheme.primary,
                    selectedTextColor   = MaterialTheme.colorScheme.primary,
                    indicatorColor      = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

// ── Shared icon with badge + scale animation ──────────────────────────────────

@Composable
private fun NavIcon(item: NavItem, selected: Boolean, badgeCount: Int) {
    BadgedBox(badge = {
        if (badgeCount > 0) {
            Badge { Text(if (badgeCount > 99) "99+" else badgeCount.toString()) }
        }
    }) {
        AnimatedContent(
            targetState = selected,
            transitionSpec = {
                (fadeIn(tween(150)) + scaleIn(
                    spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                    initialScale = 0.85f
                )) togetherWith fadeOut(tween(100))
            },
            label = "navIcon"
        ) { isSelected ->
            Icon(
                imageVector        = if (isSelected) item.selectedIcon else item.icon,
                contentDescription = item.label
            )
        }
    }
}
