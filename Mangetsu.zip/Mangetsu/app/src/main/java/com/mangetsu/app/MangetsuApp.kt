package com.mangetsu.app

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.data.extension.lifecycle.PackageEventReceiver
import com.mangetsu.app.BuildConfig
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class MangetsuApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory:       HiltWorkerFactory
    @Inject lateinit var extensionRepository: ExtensionRepositoryImpl

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        // Register dynamic package broadcast receiver (replaces old static approach)
        PackageEventReceiver.register(PackageEventReceiver(), this)

        // Scan all installed APKs via DexLoader → ExtensionRegistry
        applicationScope.launch(Dispatchers.IO) {
            extensionRepository.init()
        }
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
}
