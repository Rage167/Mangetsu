package com.mangetsu.app.di

import android.content.Context
import androidx.room.Room
import com.mangetsu.data.backup.BackupManager
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.repository.ExtensionRepoRepositoryImpl
import com.mangetsu.data.repository.HistoryRepositoryImpl
import com.mangetsu.data.repository.LibraryRepositoryImpl
import com.mangetsu.domain.repository.BackupRepository
import com.mangetsu.domain.repository.ExtensionRepoRepository
import com.mangetsu.domain.repository.HistoryRepository
import com.mangetsu.domain.repository.LibraryRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MangetsuDatabase =
        Room.databaseBuilder(context, MangetsuDatabase::class.java, MangetsuDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigrationFrom(1)
            .build()
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides @Singleton
    fun provideMoshi(): Moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    @Provides @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .build()
}

@Module
@InstallIn(SingletonComponent::class)
object AppContextModule {
    @Provides @Singleton
    fun provideContext(@ApplicationContext context: Context): Context = context
}

@Module
@InstallIn(SingletonComponent::class)
abstract class CoreRepositoryModule {

    @Binds @Singleton
    abstract fun bindLibraryRepository(impl: LibraryRepositoryImpl): LibraryRepository

    @Binds @Singleton
    abstract fun bindExtensionRepoRepository(impl: ExtensionRepoRepositoryImpl): ExtensionRepoRepository

    @Binds @Singleton
    abstract fun bindHistoryRepository(impl: HistoryRepositoryImpl): HistoryRepository

    @Binds @Singleton
    abstract fun bindBackupRepository(impl: BackupManager): BackupRepository
}
