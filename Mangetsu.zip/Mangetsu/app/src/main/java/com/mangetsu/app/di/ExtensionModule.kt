package com.mangetsu.app.di

import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.data.repository.BrowseRepositoryImpl
import com.mangetsu.data.repository.ChapterRepositoryImpl
import com.mangetsu.domain.repository.BrowseRepository
import com.mangetsu.domain.repository.ChapterRepository
import com.mangetsu.domain.repository.ExtensionRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * UPDATED ExtensionModule
 *
 * Binds the new deep extension engine implementations.
 * Old ExtensionLoader binding is removed — the new DexLoader + registry replace it.
 * BrowseRepository and ChapterRepository are also updated here since their
 * implementations changed.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class ExtensionModule {

    @Binds
    @Singleton
    abstract fun bindExtensionRepository(impl: ExtensionRepositoryImpl): ExtensionRepository

    @Binds
    @Singleton
    abstract fun bindBrowseRepository(impl: BrowseRepositoryImpl): BrowseRepository

    @Binds
    @Singleton
    abstract fun bindChapterRepository(impl: ChapterRepositoryImpl): ChapterRepository
}
