package com.mangetsu.app.di

import com.mangetsu.data.reader.ReaderImageLoader
import com.mangetsu.data.reader.ReaderSettingsRepository
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Reader module — all classes use @Inject constructor + @Singleton so
 * Hilt discovers them automatically. This module exists as a hook for tests.
 *
 * Provided singletons:
 *  - [ReaderImageLoader]        → Coil ImageLoader + prefetch engine
 *  - [ReaderSettingsRepository] → DataStore-backed settings persistence
 */
@Module
@InstallIn(SingletonComponent::class)
object ReaderModule
