package com.mangetsu.app.di

import com.mangetsu.data.extension.repo.MultiRepoFetcher
import com.mangetsu.data.extension.repo.RepoCache
import com.mangetsu.data.extension.repo.RepoIndexParser
import com.mangetsu.data.extension.repo.RepoManager
import com.mangetsu.data.extension.repo.VersionManager
import com.mangetsu.data.extension.download.ApkDownloadManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module providing the multi-repo and download system.
 *
 * All classes use constructor injection so this module only needs to
 * declare the ones that require factory methods (none currently —
 * everything is @Inject constructor + @Singleton).
 *
 * Kept as an explicit module for clarity and future overrides in tests.
 */
@Module
@InstallIn(SingletonComponent::class)
object RepoModule
// All beans in this system use @Inject constructor + @Singleton directly:
//   RepoCache, RepoIndexParser, MultiRepoFetcher, VersionManager,
//   ApkDownloadManager, RepoManager
// Hilt discovers them automatically — no @Provides needed.
