package com.mangetsu.app.di

import android.content.Context
import androidx.work.ListenableWorker
import androidx.work.WorkManager
import com.mangetsu.app.worker.DownloadWorker
import com.mangetsu.data.repository.DownloadRepositoryImpl
import com.mangetsu.data.repository.DownloadWorkerClass
import com.mangetsu.domain.repository.DownloadRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Qualifier
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object WorkModule {

    @Provides @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager =
        WorkManager.getInstance(context)

    @Provides @Singleton
    @DownloadWorkerClass
    fun provideDownloadWorkerClass(): Class<out ListenableWorker> = DownloadWorker::class.java
}

@Module
@InstallIn(SingletonComponent::class)
abstract class DownloadModule {
    @Binds @Singleton
    abstract fun bindDownloadRepository(impl: DownloadRepositoryImpl): DownloadRepository
}
