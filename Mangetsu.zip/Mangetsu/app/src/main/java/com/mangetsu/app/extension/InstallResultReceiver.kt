package com.mangetsu.app.extension

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import com.mangetsu.data.extension.ExtensionInstaller
import com.mangetsu.data.extension.lifecycle.ExtensionLifecycleManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Receives the result broadcast from [PackageInstaller] after an extension
 * APK install or uninstall attempt completes.
 *
 * On success, delegates to [ExtensionLifecycleManager.onPackageInstalled] which
 * triggers validation → DEX loading → registry registration.
 *
 * Note: [PackageEventReceiver] handles ongoing system package events.
 * This receiver handles only the one-shot result from our own installer session.
 */
@AndroidEntryPoint
class InstallResultReceiver : BroadcastReceiver() {

    @Inject
    lateinit var lifecycleManager: ExtensionLifecycleManager

    // Receiver-scoped coroutine scope — tied to goAsync() lifetime
    private val receiverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ExtensionInstaller.INSTALL_ACTION) return

        val status      = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)
        val packageName = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME)
        val message     = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)

        Timber.d("InstallResultReceiver: status=$status pkg=$packageName msg=$message")

        when (status) {
            PackageInstaller.STATUS_SUCCESS -> {
                Timber.i("InstallResultReceiver: ✅ install succeeded for $packageName")
                if (packageName != null) {
                    val pendingResult = goAsync()
                    receiverScope.launch {
                        try {
                            // Delegate to lifecycle manager — validates, loads DEX, registers
                            lifecycleManager.onPackageInstalled(packageName)
                        } finally {
                            pendingResult.finish()
                        }
                    }
                }
            }

            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Android requires explicit user confirmation — launch the confirm activity
                @Suppress("DEPRECATION")
                val confirmIntent = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                confirmIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                confirmIntent?.let {
                    Timber.d("InstallResultReceiver: launching user confirmation")
                    context.startActivity(it)
                }
            }

            else -> {
                Timber.e("InstallResultReceiver: ❌ install failed status=$status: $message")
            }
        }
    }
}
