package com.mangetsu.app.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.mangetsu.app.ui.backup.BackupScreen
import com.mangetsu.app.ui.browse.BrowseScreen
import com.mangetsu.app.ui.browse.MangaDetailScreen
import com.mangetsu.app.ui.extensions.ExtensionsScreen
import com.mangetsu.app.ui.extensions.ExtensionStatsScreen
import com.mangetsu.app.ui.history.HistoryScreen
import com.mangetsu.app.ui.library.LibraryScreen
import com.mangetsu.app.ui.reader.ReaderScreen
import com.mangetsu.app.ui.repo.RepoScreen
import com.mangetsu.app.ui.settings.SettingsScreen

// ── Routes ────────────────────────────────────────────────────────────────────

sealed class Screen(val route: String) {
    data object Library        : Screen("library")
    data object Browse         : Screen("browse")
    data object Extensions     : Screen("extensions")
    data object ExtensionStats : Screen("extensions/stats")
    data object Repos          : Screen("repos")
    data object History        : Screen("history")
    data object Settings       : Screen("settings")
    data object Backup         : Screen("backup")

    data object MangaDetail : Screen("manga/{sourceId}/{mangaId}") {
        fun createRoute(sourceId: Long, mangaId: Long) = "manga/$sourceId/$mangaId"
    }
    data object Reader : Screen("reader/{mangaId}/{chapterId}") {
        fun createRoute(mangaId: Long, chapterId: Long) = "reader/$mangaId/$chapterId"
    }
}

// ── Easing curves ─────────────────────────────────────────────────────────────

private val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
private val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

private const val ENTER_DURATION  = 350
private const val EXIT_DURATION   = 250
private const val FADE_DURATION   = 200

// ── NavHost ───────────────────────────────────────────────────────────────────

@Composable
fun MangetsuNavGraph(navController: NavHostController) {
    NavHost(
        navController    = navController,
        startDestination = Screen.Library.route,
        // Default transitions for bottom-nav level screens (cross-fade)
        enterTransition  = { fadeIn(tween(FADE_DURATION)) },
        exitTransition   = { fadeOut(tween(FADE_DURATION)) },
        popEnterTransition = { fadeIn(tween(FADE_DURATION)) },
        popExitTransition  = { fadeOut(tween(FADE_DURATION)) }
    ) {

        // ── Bottom nav destinations (cross-fade) ────────────────────────────
        composable(Screen.Library.route) {
            LibraryScreen(onMangaClick = { manga ->
                navController.navigate(Screen.MangaDetail.createRoute(manga.sourceId, manga.id))
            })
        }

        composable(Screen.Browse.route) {
            BrowseScreen(onMangaClick = { sourceId, mangaId ->
                navController.navigate(Screen.MangaDetail.createRoute(sourceId, mangaId))
            })
        }

        composable(Screen.Extensions.route) {
            ExtensionsScreen(
                onHealthClick = { navController.navigate(Screen.ExtensionStats.route) },
                onReposClick  = { navController.navigate(Screen.Repos.route) }
            )
        }

        composable(Screen.History.route) {
            HistoryScreen(onMangaClick = { mangaId ->
                navController.navigate(Screen.MangaDetail.createRoute(0L, mangaId))
            })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onNavigateToBackup = { navController.navigate(Screen.Backup.route) })
        }

        // ── Detail screens (slide in from right) ────────────────────────────
        composable(
            route = Screen.MangaDetail.route,
            arguments = listOf(
                navArgument("sourceId") { type = NavType.LongType },
                navArgument("mangaId")  { type = NavType.LongType }
            ),
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(ENTER_DURATION, easing = EmphasizedDecelerate)
                ) + fadeIn(tween(FADE_DURATION))
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(EXIT_DURATION, easing = EmphasizedAccelerate)
                ) + fadeOut(tween(FADE_DURATION))
            },
            popEnterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.End,
                    tween(ENTER_DURATION, easing = EmphasizedDecelerate)
                ) + fadeIn(tween(FADE_DURATION))
            },
            popExitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.End,
                    tween(EXIT_DURATION, easing = EmphasizedAccelerate)
                ) + fadeOut(tween(FADE_DURATION))
            }
        ) { back ->
            val sourceId = back.arguments?.getLong("sourceId") ?: 0L
            val mangaId  = back.arguments?.getLong("mangaId")  ?: 0L
            MangaDetailScreen(
                mangaId        = mangaId,
                sourceId       = sourceId,
                onChapterClick = { chapterId ->
                    navController.navigate(Screen.Reader.createRoute(mangaId, chapterId))
                },
                onBack = { navController.popBackStack() }
            )
        }

        // ── Reader (scale up from centre) ───────────────────────────────────
        composable(
            route = Screen.Reader.route,
            arguments = listOf(
                navArgument("mangaId")   { type = NavType.LongType },
                navArgument("chapterId") { type = NavType.LongType }
            ),
            enterTransition = {
                scaleIn(tween(ENTER_DURATION, easing = EmphasizedDecelerate), initialScale = 0.92f) +
                fadeIn(tween(FADE_DURATION))
            },
            exitTransition = {
                scaleOut(tween(EXIT_DURATION, easing = EmphasizedAccelerate), targetScale = 0.92f) +
                fadeOut(tween(FADE_DURATION))
            },
            popEnterTransition = {
                scaleIn(tween(ENTER_DURATION, easing = EmphasizedDecelerate), initialScale = 0.92f) +
                fadeIn(tween(FADE_DURATION))
            },
            popExitTransition = {
                scaleOut(tween(EXIT_DURATION, easing = EmphasizedAccelerate), targetScale = 0.92f) +
                fadeOut(tween(FADE_DURATION))
            }
        ) { back ->
            val mangaId   = back.arguments?.getLong("mangaId")   ?: 0L
            val chapterId = back.arguments?.getLong("chapterId") ?: 0L
            ReaderScreen(mangaId = mangaId, chapterId = chapterId,
                onBack = { navController.popBackStack() })
        }

        // ── Secondary screens (slide in from right) ───────────────────────────

        composable(
            Screen.ExtensionStats.route,
            enterTransition = {
                slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(ENTER_DURATION, easing = EmphasizedDecelerate)) + fadeIn(tween(FADE_DURATION))
            },
            popExitTransition = {
                slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End,
                    tween(EXIT_DURATION, easing = EmphasizedAccelerate)) + fadeOut(tween(FADE_DURATION))
            }
        ) {
            ExtensionStatsScreen(onBack = { navController.popBackStack() })
        }

        composable(
            Screen.Repos.route,
            enterTransition = {
                slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(ENTER_DURATION, easing = EmphasizedDecelerate)) + fadeIn(tween(FADE_DURATION))
            },
            popExitTransition = {
                slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End,
                    tween(EXIT_DURATION, easing = EmphasizedAccelerate)) + fadeOut(tween(FADE_DURATION))
            }
        ) {
            RepoScreen(onBack = { navController.popBackStack() })
        }

        composable(
            Screen.Backup.route,
            enterTransition = {
                slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(ENTER_DURATION, easing = EmphasizedDecelerate)) + fadeIn(tween(FADE_DURATION))
            },
            popExitTransition = {
                slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End,
                    tween(EXIT_DURATION, easing = EmphasizedAccelerate)) + fadeOut(tween(FADE_DURATION))
            }
        ) {
            BackupScreen(onBack = { navController.popBackStack() })
        }
    }
}
