package com.mangetsu.app.ui.backup

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mangetsu.data.backup.BackupPreview
import com.mangetsu.data.backup.RestoreMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(
    onBack: () -> Unit,
    vm: BackupViewModel = hiltViewModel()
) {
    val state        by vm.state.collectAsStateWithLifecycle()
    val snackbarHost  = remember { SnackbarHostState() }

    // File pickers
    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let { vm.createBackup(it) } }

    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { vm.inspectBackup(it) } }

    // Feedback
    LaunchedEffect(state.error) {
        state.error?.let { snackbarHost.showSnackbar(it); vm.clearError() }
    }
    LaunchedEffect(state.successMessage) {
        state.successMessage?.let { snackbarHost.showSnackbar(it); vm.clearSuccess() }
    }

    // Restore confirm dialog
    if (state.confirmDialogOpen && state.preview != null) {
        RestoreConfirmDialog(
            preview        = state.preview!!,
            errors         = state.previewErrors,
            restoreMode    = state.restoreMode,
            isRestoring    = state.isRestoring,
            onModeChange   = vm::setRestoreMode,
            onConfirm      = vm::confirmRestore,
            onDismiss      = vm::dismissConfirmDialog
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHost) },
        topBar = {
            TopAppBar(
                title = { Text("Backup & Restore") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ── Backup section ────────────────────────────────────────────────
            SectionCard(title = "Create Backup", icon = Icons.Filled.Backup) {
                Text(
                    "Export your library, history, categories, reading progress and settings to a JSON file.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(8.dp))

                state.lastBackupStats?.let { stats ->
                    StatsRow("Manga",      stats.mangaCount.toString())
                    StatsRow("Chapters",   stats.chapterCount.toString())
                    StatsRow("History",    stats.historyCount.toString())
                    StatsRow("Categories", stats.categoryCount.toString())
                    StatsRow("File size",  "${stats.fileSizeBytes / 1024}KB")
                    Spacer(Modifier.height(8.dp))
                }

                Button(
                    onClick  = { backupLauncher.launch(state.suggestedFilename) },
                    enabled  = !state.isBackingUp && !state.isRestoring,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isBackingUp) {
                        CircularProgressIndicator(
                            modifier    = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color       = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Creating backup…")
                    } else {
                        Icon(Icons.Filled.Backup, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Create Backup")
                    }
                }
            }

            // ── Restore section ───────────────────────────────────────────────
            SectionCard(title = "Restore Backup", icon = Icons.Filled.Restore) {
                Text(
                    "Import a previously created backup file. Choose between merging with existing data or replacing it entirely.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(8.dp))

                state.lastRestoreStats?.let { stats ->
                    val modeLabel = if (stats.mode == RestoreMode.OVERWRITE) "Overwrite" else "Merge"
                    Surface(
                        color  = MaterialTheme.colorScheme.primaryContainer,
                        shape  = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.CheckCircle, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Last restore [$modeLabel]: ${stats.mangaRestored} manga, " +
                                    "${stats.chaptersRestored} chapters",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                OutlinedButton(
                    onClick  = { restoreLauncher.launch(arrayOf("application/json", "*/*")) },
                    enabled  = !state.isBackingUp && !state.isRestoring && !state.isInspecting,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isInspecting || state.isRestoring) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(if (state.isInspecting) "Reading file…" else "Restoring…")
                    } else {
                        Icon(Icons.Filled.Restore, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Choose Backup File")
                    }
                }
            }

            // ── Info section ──────────────────────────────────────────────────
            SectionCard(title = "What's included", icon = Icons.Filled.Info) {
                listOf(
                    "✓ Library manga (titles, metadata, read status)",
                    "✓ All chapters (read progress, page position)",
                    "✓ Reading history",
                    "✓ Library categories and organisation",
                    "✓ Tracking records (MAL, AniList, etc.)",
                    "✓ Extension repository URLs",
                    "✓ Reader settings",
                    "✗ Downloaded chapter images (too large)",
                    "✗ Extension APKs",
                    "✗ OAuth tokens (log back in after restore)"
                ).forEach { line ->
                    Text(line,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (line.startsWith("✓"))
                            MaterialTheme.colorScheme.onSurface
                        else
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
            }
        }
    }
}

// ── Restore Confirm Dialog ────────────────────────────────────────────────────

@Composable
private fun RestoreConfirmDialog(
    preview:      BackupPreview,
    errors:       List<String>,
    restoreMode:  RestoreMode,
    isRestoring:  Boolean,
    onModeChange: (RestoreMode) -> Unit,
    onConfirm:    () -> Unit,
    onDismiss:    () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!isRestoring) onDismiss() },
        title = { Text("Restore Backup") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

                // Preview
                val fmt = SimpleDateFormat("MMM d yyyy, HH:mm", Locale.getDefault())
                Text("Backup from ${fmt.format(Date(preview.createdAt))} · v${preview.version}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        PreviewRow("Manga",      preview.mangaCount)
                        PreviewRow("Chapters",   preview.chapterCount)
                        PreviewRow("History",    preview.historyCount)
                        PreviewRow("Categories", preview.categoryCount)
                        PreviewRow("Tracking",   preview.trackingCount)
                        PreviewRow("Repos",      preview.repoCount)
                    }
                }

                // Validation warnings
                if (errors.isNotEmpty()) {
                    Surface(
                        color  = MaterialTheme.colorScheme.errorContainer,
                        shape  = MaterialTheme.shapes.small
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Warning, null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp))
                                Text(" ${errors.size} validation warning(s)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.SemiBold)
                            }
                            errors.take(5).forEach { err ->
                                Text("• $err",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error)
                            }
                            if (errors.size > 5) {
                                Text("…and ${errors.size - 5} more",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                HorizontalDivider()

                // Mode selector
                Text("Restore mode", style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold)

                RestoreMode.entries.forEach { mode ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = restoreMode == mode,
                            onClick  = { onModeChange(mode) },
                            enabled  = !isRestoring
                        )
                        Column(Modifier.padding(start = 4.dp)) {
                            Text(
                                if (mode == RestoreMode.MERGE) "Merge" else "Overwrite",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                if (mode == RestoreMode.MERGE)
                                    "Add new items without removing existing ones"
                                else
                                    "Replace library — existing data will be deleted",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (mode == RestoreMode.OVERWRITE)
                                    MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                else
                                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick  = onConfirm,
                enabled  = !isRestoring,
                colors   = if (restoreMode == RestoreMode.OVERWRITE)
                    ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                else
                    ButtonDefaults.buttonColors()
            ) {
                if (isRestoring) {
                    CircularProgressIndicator(
                        modifier    = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color       = Color.White
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text("Restore")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isRestoring) { Text("Cancel") }
        }
    )
}

// ── Shared composables ────────────────────────────────────────────────────────

@Composable
private fun SectionCard(
    title:   String,
    icon:    ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun StatsRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PreviewRow(label: String, count: Int) {
    if (count == 0) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Text(count.toString(), style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary)
    }
}
