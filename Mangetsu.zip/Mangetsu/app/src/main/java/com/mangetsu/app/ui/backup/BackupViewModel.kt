package com.mangetsu.app.ui.backup

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.data.backup.BackupManager
import com.mangetsu.data.backup.BackupPreview
import com.mangetsu.data.backup.BackupResult
import com.mangetsu.data.backup.BackupStats
import com.mangetsu.data.backup.InspectResult
import com.mangetsu.data.backup.RestoreMode
import com.mangetsu.data.backup.RestoreResult
import com.mangetsu.data.backup.RestoreStats
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BackupUiState(
    // Backup
    val isBackingUp:       Boolean         = false,
    val lastBackupStats:   BackupStats?    = null,

    // Restore
    val isInspecting:      Boolean         = false,
    val isRestoring:       Boolean         = false,
    val pendingUri:        Uri?            = null,
    val preview:           BackupPreview?  = null,
    val previewErrors:     List<String>    = emptyList(),
    val restoreMode:       RestoreMode     = RestoreMode.MERGE,
    val lastRestoreStats:  RestoreStats?   = null,
    val confirmDialogOpen: Boolean         = false,

    // Feedback
    val error:             String?         = null,
    val successMessage:    String?         = null,
    val suggestedFilename: String          = "mangetsu_backup.json"
)

@HiltViewModel
class BackupViewModel @Inject constructor(
    private val backupManager: BackupManager
) : ViewModel() {

    private val _state = MutableStateFlow(BackupUiState())
    val state: StateFlow<BackupUiState> = _state

    init {
        _state.update { it.copy(suggestedFilename = backupManager.suggestedFilename()) }
    }

    // ── Backup ────────────────────────────────────────────────────────────────

    fun createBackup(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(isBackingUp = true, error = null) }

            when (val result = backupManager.createBackupToUri(uri, pretty = true)) {
                is BackupResult.Success -> _state.update {
                    it.copy(
                        isBackingUp      = false,
                        lastBackupStats  = result.stats,
                        successMessage   = buildBackupSuccessMessage(result.stats),
                        suggestedFilename = backupManager.suggestedFilename()
                    )
                }
                is BackupResult.Failure -> _state.update {
                    it.copy(isBackingUp = false, error = "Backup failed: ${result.message}")
                }
            }
        }
    }

    // ── Inspect (preview before restore) ──────────────────────────────────────

    fun inspectBackup(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(isInspecting = true, error = null, pendingUri = uri) }

            when (val result = backupManager.inspect(uri)) {
                is InspectResult.Valid -> _state.update {
                    it.copy(
                        isInspecting    = false,
                        preview         = result.preview,
                        previewErrors   = emptyList(),
                        confirmDialogOpen = true
                    )
                }
                is InspectResult.Invalid -> _state.update {
                    it.copy(
                        isInspecting    = false,
                        preview         = result.preview,
                        previewErrors   = result.errors,
                        confirmDialogOpen = true   // show warnings but allow user to decide
                    )
                }
                is InspectResult.Failure -> _state.update {
                    it.copy(
                        isInspecting  = false,
                        pendingUri    = null,
                        error         = "Cannot read backup: ${result.message}"
                    )
                }
            }
        }
    }

    // ── Restore ───────────────────────────────────────────────────────────────

    fun setRestoreMode(mode: RestoreMode) = _state.update { it.copy(restoreMode = mode) }

    fun confirmRestore() {
        val uri  = _state.value.pendingUri ?: return
        val mode = _state.value.restoreMode
        _state.update { it.copy(confirmDialogOpen = false, isRestoring = true, error = null) }

        viewModelScope.launch {
            when (val result = backupManager.restoreFromUri(uri, mode)) {
                is RestoreResult.Success -> _state.update {
                    it.copy(
                        isRestoring      = false,
                        lastRestoreStats = result.stats,
                        pendingUri       = null,
                        preview          = null,
                        previewErrors    = emptyList(),
                        successMessage   = buildRestoreSuccessMessage(result.stats)
                    )
                }
                is RestoreResult.ValidationError -> _state.update {
                    it.copy(
                        isRestoring    = false,
                        previewErrors  = result.errors,
                        confirmDialogOpen = true,  // re-show dialog with errors
                        error          = "Backup validation failed (${result.errors.size} issue(s))"
                    )
                }
                is RestoreResult.Failure -> _state.update {
                    it.copy(
                        isRestoring = false,
                        pendingUri  = null,
                        error       = "Restore failed: ${result.message}"
                    )
                }
            }
        }
    }

    fun dismissConfirmDialog() = _state.update {
        it.copy(confirmDialogOpen = false, pendingUri = null, preview = null, previewErrors = emptyList())
    }

    // ── Feedback ──────────────────────────────────────────────────────────────

    fun clearError()   = _state.update { it.copy(error = null) }
    fun clearSuccess() = _state.update { it.copy(successMessage = null) }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun buildBackupSuccessMessage(stats: BackupStats) = buildString {
        append("Backup saved! ")
        append("${stats.mangaCount} manga, ${stats.chapterCount} chapters, ")
        append("${stats.historyCount} history entries")
        val kb = stats.fileSizeBytes / 1024
        append(" (${kb}KB)")
    }

    private fun buildRestoreSuccessMessage(stats: RestoreStats) = buildString {
        val mode = if (stats.mode == RestoreMode.OVERWRITE) "Overwrite" else "Merge"
        append("[$mode] Restored: ")
        append("${stats.mangaRestored} manga, ")
        append("${stats.chaptersRestored} chapters, ")
        append("${stats.historyRestored} history entries")
        if (stats.categoriesRestored > 0) append(", ${stats.categoriesRestored} categories")
        if (stats.trackingRestored > 0)   append(", ${stats.trackingRestored} tracking records")
    }
}
