package com.mangetsu.app.ui.browse

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mangetsu.app.ui.detail.MangaDetailViewModel
import com.mangetsu.core.model.Manga

// ═══════════════════════════════════════════════════════════════════════════════
// BrowseScreen
// ═══════════════════════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    onMangaClick: (Long, Long) -> Unit,
    vm: BrowseViewModel = hiltViewModel()
) {
    val state     by vm.uiState.collectAsStateWithLifecycle()
    val gridState  = rememberLazyGridState()
    var sourceMenuExpanded by remember { mutableStateOf(false) }

    // Trigger infinite scroll
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
            .collect { lastVisible ->
                if (lastVisible != null && lastVisible >= state.mangas.size - 6) {
                    vm.loadMore()
                }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Browse", style = MaterialTheme.typography.titleLarge)
                        if (state.selectedSource != null) {
                            val ext = state.extensions.find { it.sourceId == state.selectedSource }
                            Text(
                                text  = ext?.name ?: "Unknown source",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                },
                actions = {
                    // Source picker
                    Box {
                        IconButton(onClick = { sourceMenuExpanded = true }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Select source")
                        }
                        DropdownMenu(
                            expanded        = sourceMenuExpanded,
                            onDismissRequest = { sourceMenuExpanded = false }
                        ) {
                            state.extensions.forEach { ext ->
                                DropdownMenuItem(
                                    text    = { Text(ext.name) },
                                    onClick = {
                                        vm.selectSource(ext.sourceId)
                                        sourceMenuExpanded = false
                                    },
                                    leadingIcon = if (ext.sourceId == state.selectedSource) ({
                                        Icon(Icons.Filled.Check, contentDescription = null)
                                    }) else null
                                )
                            }
                            if (state.extensions.isEmpty()) {
                                DropdownMenuItem(
                                    text    = { Text("No extensions installed") },
                                    enabled = false,
                                    onClick = {}
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search + Mode chips
            TextField(
                value           = state.query,
                onValueChange   = vm::onQueryChange,
                placeholder     = { Text("Search source…") },
                singleLine      = true,
                modifier        = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )

            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = state.mode == BrowseMode.POPULAR,
                    onClick  = { vm.setMode(BrowseMode.POPULAR) },
                    label    = { Text("Popular") }
                )
                FilterChip(
                    selected = state.mode == BrowseMode.LATEST,
                    onClick  = { vm.setMode(BrowseMode.LATEST) },
                    label    = { Text("Latest") }
                )
            }

            // Content
            when {
                state.isLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator()
                }
                state.error != null && state.mangas.isEmpty() -> ErrorState(
                    message = state.error!!,
                    onRetry = vm::retry
                )
                state.selectedSource == null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Install an extension to start browsing")
                }
                else -> LazyVerticalGrid(
                    state         = gridState,
                    columns       = GridCells.Adaptive(110.dp),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement   = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.mangas, key = { it.url }) { manga ->
                        BrowseMangaItem(
                            manga    = manga,
                            onClick  = { onMangaClick(manga.sourceId, manga.id) }
                        )
                    }
                    if (state.isLoadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                Alignment.Center
                            ) { CircularProgressIndicator(modifier = Modifier.size(24.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BrowseMangaItem(manga: Manga, onClick: () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth().clickable { onClick() },
        shape     = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        AsyncImage(
            model              = manga.thumbnailUrl,
            contentDescription = manga.title,
            contentScale       = ContentScale.Crop,
            modifier           = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
        )
        Text(
            text     = manga.title,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            style    = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(6.dp)
        )
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Error: $message", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onRetry) { Text("Retry") }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MangaDetailScreen
// ═══════════════════════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaDetailScreen(
    mangaId: Long,
    sourceId: Long,
    onChapterClick: (Long) -> Unit,
    onBack: () -> Unit,
    vm: MangaDetailViewModel = hiltViewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(mangaId, sourceId) {
        vm.load(mangaId, sourceId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.manga?.title ?: "Manga Detail") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            state.manga?.let { manga ->
                if (!manga.inLibrary) {
                    FloatingActionButton(onClick = { vm.addToLibrary() }) {
                        Icon(Icons.Filled.Add, contentDescription = "Add to library")
                    }
                }
            }
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val manga = state.manga ?: return@Scaffold

        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Header: cover + info
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AsyncImage(
                    model              = manga.thumbnailUrl,
                    contentDescription = manga.title,
                    contentScale       = ContentScale.Crop,
                    modifier           = Modifier
                        .width(100.dp)
                        .height(150.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Column {
                    Text(manga.title, style = MaterialTheme.typography.titleMedium)
                    manga.author?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    }
                    Spacer(Modifier.height(8.dp))
                    if (manga.inLibrary) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        ) {
                            Text(
                                "In Library",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // Description
            manga.description?.let { desc ->
                Text(
                    text     = desc,
                    style    = MaterialTheme.typography.bodySmall,
                    maxLines = 5,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(Modifier.height(12.dp))
            }

            // Genre chips
            if (manga.genre.isNotEmpty()) {
                Row(
                    Modifier.padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    manga.genre.take(5).forEach { g ->
                        FilterChip(selected = false, onClick = {}, label = { Text(g) })
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // Chapters header
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Text("${state.chapters.size} Chapters", style = MaterialTheme.typography.titleSmall)
                IconButton(onClick = { vm.syncChapters() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Sync chapters")
                }
            }

            // Chapter list
            state.chapters.forEach { chapter ->
                ChapterListItem(
                    name      = chapter.name,
                    isRead    = chapter.read,
                    scanlator = chapter.scanlator,
                    onClick   = { onChapterClick(chapter.id) }
                )
            }
        }
    }
}

@Composable
private fun ChapterListItem(
    name: String,
    isRead: Boolean,
    scanlator: String?,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text  = name,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isRead)
                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                else
                    MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            scanlator?.let {
                Text(
                    text  = it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
        if (isRead) {
            Icon(
                imageVector        = Icons.Filled.Check,
                contentDescription = "Read",
                tint               = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                modifier           = Modifier.size(16.dp)
            )
        }
    }
}
