package com.mangetsu.app.ui.browse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.Manga
import com.mangetsu.core.util.Result
import com.mangetsu.domain.usecase.AddMangaToLibraryUseCase
import com.mangetsu.domain.usecase.GetInstalledExtensionsUseCase
import com.mangetsu.domain.usecase.GetLatestMangaUseCase
import com.mangetsu.domain.usecase.GetPopularMangaUseCase
import com.mangetsu.domain.usecase.SearchMangaUseCase
import com.mangetsu.extensionapi.model.SManga
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class BrowseMode { POPULAR, LATEST, SEARCH }

data class BrowseUiState(
    val extensions:     List<Extension>   = emptyList(),
    val selectedSource: Long?             = null,
    val mangas:         List<Manga>       = emptyList(),
    val isLoading:      Boolean           = false,
    val isLoadingMore:  Boolean           = false,
    val hasNextPage:    Boolean           = false,
    val error:          String?           = null,
    val query:          String            = "",
    val mode:           BrowseMode        = BrowseMode.POPULAR,
    val currentPage:    Int               = 1
)

@OptIn(FlowPreview::class)
@HiltViewModel
class BrowseViewModel @Inject constructor(
    private val getInstalledExtensions: GetInstalledExtensionsUseCase,
    private val getPopularManga:        GetPopularMangaUseCase,
    private val getLatestManga:         GetLatestMangaUseCase,
    private val searchManga:            SearchMangaUseCase,
    private val addToLibrary:           AddMangaToLibraryUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(BrowseUiState())
    val uiState: StateFlow<BrowseUiState> = _uiState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), BrowseUiState())

    init {
        viewModelScope.launch {
            getInstalledExtensions()
                .debounce(100)
                .distinctUntilChanged()
                .collect { exts ->
                    _uiState.value = _uiState.value.copy(extensions = exts)
                    // Auto-select first source if none selected
                    if (_uiState.value.selectedSource == null && exts.isNotEmpty()) {
                        selectSource(exts.first().sourceId)
                    }
                }
        }
    }

    fun selectSource(sourceId: Long) {
        if (_uiState.value.selectedSource == sourceId) return
        _uiState.value = _uiState.value.copy(
            selectedSource = sourceId,
            mangas         = emptyList(),
            currentPage    = 1,
            error          = null
        )
        loadPage(1)
    }

    fun setMode(mode: BrowseMode) {
        _uiState.value = _uiState.value.copy(mode = mode, mangas = emptyList(), currentPage = 1)
        loadPage(1)
    }

    fun onQueryChange(q: String) {
        _uiState.value = _uiState.value.copy(query = q)
        if (q.isNotBlank()) {
            _uiState.value = _uiState.value.copy(mode = BrowseMode.SEARCH, mangas = emptyList(), currentPage = 1)
            loadPage(1)
        }
    }

    fun loadMore() {
        val state = _uiState.value
        if (!state.hasNextPage || state.isLoadingMore) return
        loadPage(state.currentPage + 1, append = true)
    }

    fun retry() = loadPage(1)

    private fun loadPage(page: Int, append: Boolean = false) {
        val state    = _uiState.value
        val sourceId = state.selectedSource ?: return

        viewModelScope.launch {
            _uiState.value = if (append)
                state.copy(isLoadingMore = true)
            else
                state.copy(isLoading = true, error = null)

            val result = when (state.mode) {
                BrowseMode.POPULAR -> getPopularManga(sourceId, page)
                BrowseMode.LATEST  -> getLatestManga(sourceId, page)
                BrowseMode.SEARCH  -> searchManga(sourceId, page, state.query)
            }

            _uiState.value = when (result) {
                is Result.Success -> {
                    val newMangas = result.data.mangas.map { it.toDomainManga(sourceId) }
                    _uiState.value.copy(
                        mangas        = if (append) state.mangas + newMangas else newMangas,
                        hasNextPage   = result.data.hasNextPage,
                        currentPage   = page,
                        isLoading     = false,
                        isLoadingMore = false,
                        error         = null
                    )
                }
                is Result.Error -> _uiState.value.copy(
                    isLoading     = false,
                    isLoadingMore = false,
                    error         = result.message ?: "Unknown error"
                )
                is Result.Loading -> _uiState.value
            }
        }
    }

    fun addToLibrary(manga: Manga) {
        viewModelScope.launch { addToLibrary.invoke(manga) }
    }
}

// Extension to convert SManga to Manga domain model inline
private fun com.mangetsu.extensionapi.model.SManga.toDomainManga(sourceId: Long) =
    com.mangetsu.core.model.Manga(
        sourceId     = sourceId,
        url          = url,
        title        = title,
        thumbnailUrl = thumbnailUrl,
        author       = author,
        description  = description,
        genre        = genre?.split(",")?.map { it.trim() } ?: emptyList(),
        status       = status
    )
