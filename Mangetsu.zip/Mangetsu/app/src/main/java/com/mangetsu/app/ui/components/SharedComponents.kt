package com.mangetsu.app.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import coil.compose.SubcomposeAsyncImage
import com.mangetsu.app.ui.theme.MangetsuColors
import com.mangetsu.app.ui.theme.Spacing
import com.mangetsu.app.ui.theme.extended

// ── Shimmer ───────────────────────────────────────────────────────────────────

@Composable
fun ShimmerBox(
    modifier: Modifier = Modifier,
    shape:    RoundedCornerShape = RoundedCornerShape(8.dp)
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateX by transition.animateFloat(
        initialValue  = -600f,
        targetValue   = 600f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label         = "shimmerX"
    )
    val shimmerColors = listOf(
        MaterialTheme.colorScheme.surfaceVariant,
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        MaterialTheme.colorScheme.surfaceVariant
    )
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = shimmerColors,
                    start  = Offset(translateX, 0f),
                    end    = Offset(translateX + 400f, 400f)
                )
            )
    )
}

@Composable
fun MangaCoverShimmer(modifier: Modifier = Modifier) {
    Column(modifier) {
        ShimmerBox(
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f),
            shape    = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
        )
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            ShimmerBox(Modifier.fillMaxWidth(0.9f).height(12.dp), RoundedCornerShape(4.dp))
            ShimmerBox(Modifier.fillMaxWidth(0.6f).height(10.dp), RoundedCornerShape(4.dp))
        }
    }
}

// ── Empty state ───────────────────────────────────────────────────────────────

@Composable
fun EmptyState(
    icon:     ImageVector,
    title:    String,
    subtitle: String,
    modifier: Modifier = Modifier,
    action:   String?  = null,
    onAction: () -> Unit = {}
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(Spacing.sm),
            modifier = Modifier.padding(Spacing.xxxl)
        ) {
            Surface(
                shape    = RoundedCornerShape(28.dp),
                color    = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(88.dp)
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier           = Modifier.padding(22.dp)
                )
            }
            Spacer(Modifier.height(Spacing.xs))
            Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            Text(
                subtitle,
                style     = MaterialTheme.typography.bodyMedium,
                color     = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                textAlign = TextAlign.Center
            )
            if (action != null) {
                Spacer(Modifier.height(Spacing.sm))
                Button(onClick = onAction) { Text(action) }
            }
        }
    }
}

// ── Error state ───────────────────────────────────────────────────────────────

@Composable
fun ErrorState(
    message:  String,
    modifier: Modifier = Modifier,
    onRetry:  (() -> Unit)? = null
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(Spacing.sm),
            modifier = Modifier.padding(Spacing.xxxl)
        ) {
            Surface(
                shape    = CircleShape,
                color    = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.size(72.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("!", style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.error)
                }
            }
            Text("Something went wrong", style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center)
            Text(message, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                textAlign = TextAlign.Center)
            if (onRetry != null) {
                Spacer(Modifier.height(Spacing.xs))
                Button(onClick = onRetry) { Text("Try again") }
            }
        }
    }
}

// ── Loading spinner ───────────────────────────────────────────────────────────

@Composable
fun FullScreenLoading(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            color = MaterialTheme.colorScheme.primary,
            strokeWidth = 3.dp,
            modifier = Modifier.size(40.dp)
        )
    }
}

// ── Manga cover ───────────────────────────────────────────────────────────────

@Composable
fun MangaCover(
    url:          String?,
    title:        String,
    unreadCount:  Int     = 0,
    isDownloaded: Boolean = false,
    modifier:     Modifier = Modifier,
    cornerRadius: Dp      = 12.dp
) {
    val extended = MaterialTheme.extended
    Box(modifier.clip(RoundedCornerShape(cornerRadius))) {
        SubcomposeAsyncImage(
            model              = url,
            contentDescription = title,
            contentScale       = ContentScale.Crop,
            modifier           = Modifier.fillMaxSize(),
            loading = {
                ShimmerBox(modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(0.dp))
            },
            error = {
                Box(
                    Modifier.fillMaxSize()
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        title.take(2).uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
        )

        // Bottom gradient scrim
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f   to Color.Transparent,
                    0.4f to Color.Transparent,
                    1f   to extended.coverScrim
                )
            )
        )

        // Unread badge — top right
        if (unreadCount > 0) {
            Surface(
                color    = extended.unreadBadge,
                shape    = RoundedCornerShape(bottomStart = 8.dp),
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Text(
                    if (unreadCount > 99) "99+" else unreadCount.toString(),
                    style    = MaterialTheme.typography.labelSmall,
                    color    = Color.White,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                )
            }
        }

        // Downloaded dot — bottom left
        if (isDownloaded) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp)
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(MangetsuColors.Success)
            )
        }
    }
}

// ── Pull-to-refresh wrapper ───────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PullRefreshContainer(
    isRefreshing: Boolean,
    onRefresh:    () -> Unit,
    modifier:     Modifier = Modifier,
    content:      @Composable () -> Unit
) {
    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh    = onRefresh,
        modifier     = modifier
    ) {
        content()
    }
}

// ── Status badge ──────────────────────────────────────────────────────────────

@Composable
fun StatusBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color    = color.copy(alpha = 0.12f),
        shape    = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = color,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
    }
}

// ── Section header ────────────────────────────────────────────────────────────

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text          = text.uppercase(),
        style         = MaterialTheme.typography.labelSmall,
        color         = MaterialTheme.colorScheme.primary,
        letterSpacing = 1.sp,
        modifier      = modifier.padding(start = Spacing.lg, top = Spacing.xl, bottom = Spacing.xs)
    )
}

// ── Chip row ──────────────────────────────────────────────────────────────────

@Composable
fun FilterChipRow(
    chips:    List<Pair<String, Boolean>>,
    onToggle: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier              = modifier,
        horizontalArrangement = Arrangement.spacedBy(Spacing.xs)
    ) {
        chips.forEachIndexed { index, (label, selected) ->
            Surface(
                onClick  = { onToggle(index) },
                shape    = RoundedCornerShape(50),
                color    = if (selected) MaterialTheme.colorScheme.primaryContainer
                           else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.animateContentSize()
            ) {
                Text(
                    label,
                    style    = MaterialTheme.typography.labelMedium,
                    color    = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                               else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

// ── Pulsing dot (online indicator) ───────────────────────────────────────────

@Composable
fun PulsingDot(color: Color = MangetsuColors.Success, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        initialValue  = 0.8f,
        targetValue   = 1.2f,
        animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label         = "pulseScale"
    )
    Box(
        modifier
            .size(8.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(color)
    )
}

private val androidx.compose.ui.unit.TextUnit.sp get() = this
