package com.mangetsu.app.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.core.model.Chapter
import com.mangetsu.core.model.Manga
import com.mangetsu.core.util.Result
import com.mangetsu.domain.repository.LibraryRepository
import com.mangetsu.domain.usecase.AddMangaToLibraryUseCase
import com.mangetsu.domain.usecase.GetChaptersUseCase
import com.mangetsu.domain.usecase.GetMangaDetailsUseCase
import com.mangetsu.domain.usecase.SyncChaptersUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MangaDetailUiState(
    val manga:        Manga?        = null,
    val chapters:     List<Chapter> = emptyList(),
    val isLoading:    Boolean       = true,
    val isSyncing:    Boolean       = false,
    val error:        String?       = null
)

@HiltViewModel
class MangaDetailViewModel @Inject constructor(
    private val libraryRepository:   LibraryRepository,
    private val getMangaDetails:     GetMangaDetailsUseCase,
    private val getChapters:         GetChaptersUseCase,
    private val syncChaptersUseCase: SyncChaptersUseCase,
    private val addToLibraryUseCase: AddMangaToLibraryUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(MangaDetailUiState())
    val uiState: StateFlow<MangaDetailUiState> = _uiState

    private var currentMangaId  = 0L
    private var currentSourceId = 0L

    /**
     * Primary load entry-point. Safe to call multiple times — guards against
     * re-loading the same manga.
     */
    fun load(mangaId: Long, sourceId: Long) {
        if (currentMangaId == mangaId && _uiState.value.manga != null) return
        currentMangaId  = mangaId
        currentSourceId = sourceId

        // 1 — Start chapter collection (DB-backed, instant if cached)
        viewModelScope.launch {
            getChapters(mangaId).collect { chapters ->
                _uiState.update { it.copy(chapters = chapters) }
            }
        }

        // 2 — Load manga details (DB first, then optionally refresh from source)
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val localManga = libraryRepository.getMangaByIdOrNull(mangaId)

            if (localManga != null) {
                _uiState.update { it.copy(manga = localManga, isLoading = false) }
                // If details haven't been fetched yet, refresh from source
                if (!localManga.initialized) {
                    refreshDetailsFromSource(localManga)
                }
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error     = "Manga not found. It may have been removed from the library."
                    )
                }
            }
        }
    }

    private fun refreshDetailsFromSource(manga: Manga) {
        viewModelScope.launch {
            when (val result = getMangaDetails(currentSourceId, manga)) {
                is Result.Success -> {
                    val updated = result.data.copy(id = manga.id, inLibrary = manga.inLibrary)
                    libraryRepository.updateManga(updated)
                    _uiState.update { it.copy(manga = updated) }
                }
                is Result.Error -> {
                    // Non-fatal — we already have local data, just log
                    android.util.Log.w("MangaDetail", "Detail refresh failed: ${result.message}")
                }
                else -> {}
            }
        }
    }

    fun syncChapters() {
        val manga = _uiState.value.manga ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, error = null) }
            when (val result = syncChaptersUseCase(manga.id, currentSourceId, manga)) {
                is Result.Success -> _uiState.update {
                    it.copy(isSyncing = false, chapters = result.data)
                }
                is Result.Error   -> _uiState.update {
                    it.copy(isSyncing = false, error = result.message)
                }
                else -> _uiState.update { it.copy(isSyncing = false) }
            }
        }
    }

    fun addToLibrary() {
        val manga = _uiState.value.manga ?: return
        viewModelScope.launch {
            addToLibraryUseCase(manga)
            _uiState.update { it.copy(manga = manga.copy(inLibrary = true)) }
        }
    }

    fun clearError() = _uiState.update { it.copy(error = null) }
}
