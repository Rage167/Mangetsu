package com.mangetsu.app.ui.extensions

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.mangetsu.data.extension.lifecycle.ExtensionLifecycleManager
import com.mangetsu.data.extension.registry.ExtensionRegistry
import com.mangetsu.data.extension.registry.ExtensionStats
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── ViewModel ─────────────────────────────────────────────────────────────────

@HiltViewModel
class ExtensionStatsViewModel @Inject constructor(
    private val registry:          ExtensionRegistry,
    private val lifecycleManager:  ExtensionLifecycleManager
) : ViewModel() {

    val stats: StateFlow<List<ExtensionStats>> = registry.state
        .map { it.all.let { exts -> registry.getStats() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun resetCircuit(packageName: String) {
        viewModelScope.launch { registry.resetCircuit(packageName) }
    }

    fun forceReload(packageName: String) {
        viewModelScope.launch { lifecycleManager.forceReload(packageName) }
    }
}

// ── Screen ────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionStatsScreen(
    onBack: () -> Unit = {},
    vm: ExtensionStatsViewModel = hiltViewModel()
) {
    val stats by vm.stats.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Extension Health") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            }
        )

        if (stats.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("No extensions loaded")
            }
            return
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(stats, key = { it.packageName }) { stat ->
                ExtensionStatCard(
                    stat        = stat,
                    onReset     = { vm.resetCircuit(stat.packageName) },
                    onReload    = { vm.forceReload(stat.packageName) }
                )
            }
        }
    }
}

@Composable
private fun ExtensionStatCard(
    stat:     ExtensionStats,
    onReset:  () -> Unit,
    onReload: () -> Unit
) {
    val statusColor = when {
        stat.circuitOpen || stat.disabled -> MaterialTheme.colorScheme.error
        stat.consecutiveErrors > 0        -> Color(0xFFFFA000)  // amber
        else                              -> Color(0xFF4CAF50)  // green
    }

    Card(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape     = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            // Header row
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Status dot
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(
                        text     = stat.sourceName,
                        style    = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
                Row {
                    IconButton(onClick = onReload, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Reload", modifier = Modifier.size(18.dp))
                    }
                    if (stat.circuitOpen || stat.disabled) {
                        Button(
                            onClick = onReset,
                            modifier = Modifier.height(32.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer,
                                contentColor   = MaterialTheme.colorScheme.error
                            )
                        ) { Text("Reset", style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Circuit open banner
            if (stat.circuitOpen || stat.disabled) {
                Surface(
                    color  = MaterialTheme.colorScheme.errorContainer,
                    shape  = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null,
                            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        Text(
                            "  Circuit open — extension disabled after repeated errors",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // Stats grid
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatCell(label = "Total calls",  value = stat.callCount.toString())
                StatCell(label = "Errors",       value = stat.errorCount.toString())
                StatCell(label = "Consecutive",  value = stat.consecutiveErrors.toString())
                StatCell(
                    label = "Success rate",
                    value = "${(stat.successRate * 100).toInt()}%",
                    color = when {
                        stat.successRate < 0.5f -> MaterialTheme.colorScheme.error
                        stat.successRate < 0.8f -> Color(0xFFFFA000)
                        else                    -> Color(0xFF4CAF50)
                    }
                )
            }

            // Success rate bar
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress    = { stat.successRate },
                modifier    = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color       = statusColor,
                trackColor  = MaterialTheme.colorScheme.surfaceVariant
            )

            // Package name footer
            Text(
                text     = stat.packageName,
                style    = MaterialTheme.typography.labelSmall,
                color    = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun StatCell(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text  = value,
            style = MaterialTheme.typography.titleSmall,
            color = color
        )
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    }
}
