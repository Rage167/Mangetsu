package com.mangetsu.app.ui.extensions

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mangetsu.app.ui.components.EmptyState
import com.mangetsu.app.ui.components.ShimmerBox
import com.mangetsu.app.ui.components.StatusBadge
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtensionsScreen(
    onHealthClick: () -> Unit = {},
    onReposClick:  () -> Unit = {},
    vm: ExtensionsViewModel = hiltViewModel()
) {
    val state        by vm.uiState.collectAsStateWithLifecycle()
    val snackbarHost  = remember { SnackbarHostState() }

    LaunchedEffect(state.snackMessage) {
        state.snackMessage?.let { snackbarHost.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHost, modifier = Modifier.navigationBarsPadding()) },
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Extensions", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(),
                actions = {
                    IconButton(onClick = onReposClick) {
                        Icon(Icons.Filled.List, "Repositories")
                    }
                    IconButton(onClick = onHealthClick) {
                        Icon(Icons.Filled.HealthAndSafety, "Extension health")
                    }
                    IconButton(onClick = { vm.refresh() }, enabled = !state.isLoading) {
                        if (state.isLoading) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Refresh, "Refresh")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {

            // Tab row
            val tabs = listOf(
                "Installed" to state.installed.size,
                "Available" to state.available.size,
                "Updates"   to state.updates.size
            )

            PrimaryTabRow(selectedTabIndex = state.selectedTab) {
                tabs.forEachIndexed { index, (label, count) ->
                    Tab(
                        selected = state.selectedTab == index,
                        onClick  = { vm.selectTab(index) },
                        text     = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(label)
                                if (count > 0) {
                                    Spacer(Modifier.width(4.dp))
                                    Box(
                                        Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (state.selectedTab == index)
                                                    MaterialTheme.colorScheme.primary
                                                else
                                                    MaterialTheme.colorScheme.surfaceVariant
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            count.toString(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (state.selectedTab == index)
                                                MaterialTheme.colorScheme.onPrimary
                                            else
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
            }

            AnimatedContent(
                targetState = state.selectedTab,
                modifier    = Modifier.fillMaxSize(),
                label       = "extTab"
            ) { tab ->
                when (tab) {
                    0 -> ExtensionList(
                        extensions   = state.installed,
                        isLoading    = state.isLoading,
                        emptyTitle   = "No extensions installed",
                        emptySubtitle = "Browse the Available tab to install extensions",
                        primaryAction  = null,
                        onAction       = {}
                    )
                    1 -> ExtensionList(
                        extensions    = state.available,
                        isLoading     = state.isLoading,
                        emptyTitle    = "No extensions available",
                        emptySubtitle = "Add a repository to browse extensions",
                        primaryAction = "Add Repository",
                        onAction      = onReposClick
                    )
                    2 -> {
                        if (state.updates.isEmpty() && !state.isLoading) {
                            EmptyState(
                                icon     = Icons.Filled.SystemUpdate,
                                title    = "All up to date",
                                subtitle = "No extension updates available"
                            )
                        } else {
                            Column {
                                if (state.updates.isNotEmpty()) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(onClick = vm::updateAll) {
                                            Icon(Icons.Filled.SystemUpdate, null, Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Update all (${state.updates.size})")
                                        }
                                    }
                                }
                                ExtensionList(
                                    extensions    = state.updates,
                                    isLoading     = state.isLoading,
                                    emptyTitle    = "No updates",
                                    emptySubtitle = "All extensions are up to date",
                                    primaryAction  = null,
                                    onAction       = {}
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExtensionList(
    extensions:    List<Extension>,
    isLoading:     Boolean,
    emptyTitle:    String,
    emptySubtitle: String,
    primaryAction: String?,
    onAction:      () -> Unit
) {
    if (isLoading) {
        LazyColumn(Modifier.fillMaxSize()) {
            items(8) { ExtensionRowShimmer() }
        }
        return
    }

    if (extensions.isEmpty()) {
        EmptyState(
            icon      = Icons.Filled.Extension,
            title     = emptyTitle,
            subtitle  = emptySubtitle,
            action    = primaryAction,
            onAction  = onAction
        )
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        items(extensions, key = { it.packageName }) { ext ->
            ExtensionRow(extension = ext, onInstall = {})
        }
    }
}

@Composable
private fun ExtensionRow(extension: Extension, onInstall: () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Icon
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                if (extension.iconUrl != null) {
                    AsyncImage(
                        model              = extension.iconUrl,
                        contentDescription = null,
                        contentScale       = ContentScale.Crop,
                        modifier           = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        Icons.Filled.Extension, null,
                        modifier = Modifier.padding(10.dp).fillMaxSize(),
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }

            // Name + meta
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        extension.name,
                        style    = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (extension.isNsfw) {
                        Spacer(Modifier.width(6.dp))
                        StatusBadge("18+", MaterialTheme.colorScheme.error)
                    }
                }
                Text(
                    "${extension.lang.uppercase()} · v${extension.versionName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            // Action
            when (extension.status) {
                ExtensionStatus.INSTALLED -> StatusBadge(
                    "Installed", MaterialTheme.colorScheme.primary
                )
                ExtensionStatus.UPDATE_AVAILABLE -> OutlinedButton(
                    onClick      = onInstall,
                    modifier     = Modifier.height(32.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Filled.SystemUpdate, null, Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Update", style = MaterialTheme.typography.labelMedium)
                }
                ExtensionStatus.AVAILABLE, ExtensionStatus.ERROR -> Button(
                    onClick      = onInstall,
                    modifier     = Modifier.height(32.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Filled.Download, null, Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Install", style = MaterialTheme.typography.labelMedium)
                }
                ExtensionStatus.INSTALLING -> CircularProgressIndicator(
                    Modifier.size(24.dp), strokeWidth = 2.dp
                )
            }
        }
    }
}

@Composable
private fun ExtensionRowShimmer() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ShimmerBox(Modifier.size(44.dp), RoundedCornerShape(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShimmerBox(Modifier.fillMaxWidth(0.5f).height(14.dp))
            ShimmerBox(Modifier.fillMaxWidth(0.3f).height(11.dp))
        }
        ShimmerBox(Modifier.width(70.dp).height(32.dp), RoundedCornerShape(50))
    }
}
