package com.mangetsu.app.ui.extensions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.data.extension.registry.ExtensionRegistry
import com.mangetsu.data.extension.repo.RepoManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ExtensionsUiState(
    val installed:    List<Extension>  = emptyList(),
    val available:    List<Extension>  = emptyList(),
    val updates:      List<Extension>  = emptyList(),
    val selectedTab:  Int              = 0,
    val isLoading:    Boolean          = false,
    val snackMessage: String?          = null
)

@HiltViewModel
class ExtensionsViewModel @Inject constructor(
    private val registry:    ExtensionRegistry,
    private val repoManager: RepoManager
) : ViewModel() {

    private val _extra = MutableStateFlow(ExtensionsUiState())

    val uiState: StateFlow<ExtensionsUiState> = combine(
        registry.state.map { regState ->
            regState.active.map { loaded ->
                Extension(
                    packageName = loaded.packageName,
                    name        = loaded.sourceName,
                    versionName = loaded.versionName,
                    versionCode = 0,
                    lang        = "en",
                    apkUrl      = "",
                    sourceId    = loaded.sourceId,
                    status      = if (loaded.isCircuitOpen) ExtensionStatus.ERROR
                                  else ExtensionStatus.INSTALLED
                )
            }
        },
        repoManager.state,
        _extra
    ) { installed, repoState, extra ->
        val installedSourceIds = installed.map { it.sourceId }.toSet()
        val available = repoState.extensions.filter { repo ->
            repo.status == ExtensionStatus.AVAILABLE &&
                repo.sourceId !in installedSourceIds
        }
        val updates = repoState.extensions.filter { it.status == ExtensionStatus.UPDATE_AVAILABLE }

        extra.copy(
            installed = installed,
            available = available,
            updates   = updates,
            isLoading = repoState.isRefreshing
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ExtensionsUiState(isLoading = true))

    fun selectTab(index: Int) = _extra.update { it.copy(selectedTab = index) }

    fun refresh() {
        viewModelScope.launch { repoManager.refreshAll(forceRefresh = true) }
    }

    fun updateAll() {
        viewModelScope.launch { repoManager.updateAll() }
    }

    fun clearSnack() = _extra.update { it.copy(snackMessage = null) }
}
