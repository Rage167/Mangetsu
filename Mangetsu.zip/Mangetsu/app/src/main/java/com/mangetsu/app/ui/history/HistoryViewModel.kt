package com.mangetsu.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.core.model.History
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.toDomain
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

data class HistoryGroup(
    val dateLabel: String,
    val entries:   List<History>
)

data class HistoryUiState(
    val groups:      List<HistoryGroup> = emptyList(),
    val query:       String             = "",
    val totalCount:  Int                = 0,
    val isLoading:   Boolean            = true,
    val snackMessage: String?           = null
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val db: MangetsuDatabase
) : ViewModel() {

    private val _query   = MutableStateFlow("")
    private val _extra   = MutableStateFlow(HistoryUiState())

    val uiState: StateFlow<HistoryUiState> = combine(
        _query.debounce(200).flatMapLatest { q ->
            if (q.isBlank()) db.historyDao().getHistory()
            else             db.historyDao().searchHistory(q)
        }.map { entities -> entities.map { it.toDomain() } },
        _extra
    ) { history, extra ->
        extra.copy(
            groups     = groupByDate(history),
            totalCount = history.size,
            isLoading  = false,
            query      = _query.value
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryUiState())

    fun onSearchQuery(q: String) = _query.update { q }

    fun removeEntry(historyId: Long) {
        viewModelScope.launch {
            db.historyDao().deleteById(historyId)
            _extra.update { it.copy(snackMessage = "Entry removed") }
        }
    }

    fun clearMangaHistory(mangaId: Long) {
        viewModelScope.launch {
            db.historyDao().deleteByMangaId(mangaId)
            _extra.update { it.copy(snackMessage = "Manga history cleared") }
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            db.historyDao().clearAll()
            _extra.update { it.copy(snackMessage = "History cleared") }
        }
    }

    fun clearSnack() = _extra.update { it.copy(snackMessage = null) }

    private fun groupByDate(history: List<History>): List<HistoryGroup> {
        val today     = todayLabel()
        val yesterday = yesterdayLabel()
        val fmt       = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())

        return history
            .groupBy { entry ->
                val date = Date(entry.lastRead)
                when (fmt.format(date)) {
                    today     -> "Today"
                    yesterday -> "Yesterday"
                    else      -> fmt.format(date)
                }
            }
            .map { (label, entries) -> HistoryGroup(label, entries) }
    }

    private fun todayLabel(): String {
        val fmt = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        return fmt.format(Date())
    }

    private fun yesterdayLabel(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        val fmt = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        return fmt.format(cal.time)
    }
}
