package com.mangetsu.app.ui.library

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mangetsu.app.ui.components.EmptyState
import com.mangetsu.app.ui.components.FullScreenLoading
import com.mangetsu.app.ui.components.MangaCover
import com.mangetsu.app.ui.components.MangaCoverShimmer
import com.mangetsu.app.ui.components.PullRefreshContainer
import com.mangetsu.app.ui.theme.Spacing
import com.mangetsu.app.ui.theme.extended
import com.mangetsu.core.model.Category
import com.mangetsu.core.model.LibrarySortMode
import com.mangetsu.core.model.Manga
import com.mangetsu.core.model.UpdateCheckState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    onMangaClick: (Manga) -> Unit,
    vm: LibraryViewModel = hiltViewModel()
) {
    val state        by vm.uiState.collectAsStateWithLifecycle()
    val snackbarState = remember { SnackbarHostState() }
    var showSearch   by rememberSaveable { mutableStateOf(false) }
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(rememberTopAppBarState())

    LaunchedEffect(state.snackMessage) {
        state.snackMessage?.let { snackbarState.showSnackbar(it); vm.clearSnack() }
    }

    // Dialogs
    if (state.categoryDialogOpen) {
        CategoryDialog(
            name        = state.newCategoryName,
            isEditing   = state.editingCategory != null,
            onNameChange = vm::onCategoryNameInput,
            onConfirm   = vm::confirmCategory,
            onDismiss   = vm::dismissCategoryDialog
        )
    }

    if (state.sortSheetOpen) {
        SortSheet(
            current    = state.filter.sortMode,
            ascending  = state.filter.sortAscending,
            showUnread = state.filter.showUnreadOnly,
            onSort     = vm::setSortMode,
            onToggleDir = vm::toggleSortDirection,
            onToggleUnread = vm::toggleUnreadFilter,
            onDismiss  = vm::closeSortSheet
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarState, modifier = Modifier.navigationBarsPadding()) },
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                TopAppBar(
                    scrollBehavior = scrollBehavior,
                    colors         = TopAppBarDefaults.topAppBarColors(
                        scrolledContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    title = {
                        if (showSearch) {
                            OutlinedTextField(
                                value         = state.filter.searchQuery,
                                onValueChange = vm::onSearchQuery,
                                placeholder   = { Text("Search library…") },
                                singleLine    = true,
                                shape         = RoundedCornerShape(50),
                                modifier      = Modifier.fillMaxWidth()
                            )
                        } else {
                            Column {
                                Text("Library", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold)
                                AnimatedContent(
                                    "${state.totalCount} series",
                                    label = "libCount"
                                ) { label ->
                                    Text(label, style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSearch = !showSearch; if (!showSearch) vm.onSearchQuery("") }) {
                            Icon(Icons.Filled.Search, "Search")
                        }
                        IconButton(onClick = vm::openSortSheet) {
                            BadgedBox(badge = {
                                if (state.filter.showUnreadOnly) Badge()
                            }) { Icon(Icons.Filled.Sort, "Sort") }
                        }
                        BadgedBox(badge = {
                            if (state.updates.isNotEmpty())
                                Badge { Text(state.updates.size.toString()) }
                        }) {
                            IconButton(
                                onClick  = { vm.checkForUpdates(true) },
                                enabled  = state.updateStatus.state != UpdateCheckState.RUNNING
                            ) {
                                if (state.updateStatus.state == UpdateCheckState.RUNNING) {
                                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Filled.Refresh, "Update")
                                }
                            }
                        }
                        IconButton(onClick = vm::openCreateCategory) {
                            Icon(Icons.Filled.Add, "Add category")
                        }
                    }
                )

                // Update progress
                AnimatedVisibility(
                    visible = state.updateStatus.state == UpdateCheckState.RUNNING,
                    enter   = expandVertically() + fadeIn(),
                    exit    = shrinkVertically() + fadeOut()
                ) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        LinearProgressIndicator(
                            progress    = { state.updateStatus.progress },
                            modifier    = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                            trackColor  = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Text(
                            "Checking ${state.updateStatus.currentTitle}…",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            modifier = Modifier.padding(top = 2.dp),
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Category chips
                AnimatedVisibility(state.categories.isNotEmpty()) {
                    LazyRow(
                        contentPadding       = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item(key = "all") {
                            key("all") {
                                FilterChip(
                                    selected = state.selectedCategoryId == null,
                                    onClick  = { vm.selectCategory(null) },
                                    label    = { Text("All (${state.totalCount})") },
                                    colors   = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor    = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor        = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedLeadingIconColor  = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                        }
                        items(state.categories, key = { "cat_${it.id}" }) { cat ->
                            FilterChip(
                                selected      = state.selectedCategoryId == cat.id,
                                onClick       = { vm.selectCategory(if (state.selectedCategoryId == cat.id) null else cat.id) },
                                label         = { Text(cat.name) },
                                trailingIcon  = if (state.selectedCategoryId == cat.id) ({
                                    Icon(Icons.Filled.CheckCircle, null, modifier = Modifier.size(16.dp))
                                }) else null,
                                colors        = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor   = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor       = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        PullRefreshContainer(
            isRefreshing = state.updateStatus.state == UpdateCheckState.RUNNING,
            onRefresh    = { vm.checkForUpdates(true) },
            modifier     = Modifier.padding(padding)
        ) {
            when {
                state.isLoading -> LibraryGrid(
                    isLoading = true,
                    manga     = emptyList(),
                    onMangaClick = {},
                    onFavorite   = {},
                    scrollBehavior = scrollBehavior
                )
                state.manga.isEmpty() -> EmptyState(
                    icon     = Icons.Filled.CollectionsBookmark,
                    title    = if (state.filter.searchQuery.isNotBlank()) "No results" else "Library is empty",
                    subtitle = if (state.filter.searchQuery.isNotBlank())
                        "Try a different search term"
                    else
                        "Browse sources and add manga to your library",
                    action   = if (state.filter.searchQuery.isNotBlank()) "Clear search" else null,
                    onAction = { vm.onSearchQuery("") }
                )
                else -> LibraryGrid(
                    isLoading      = false,
                    manga          = state.manga,
                    onMangaClick   = onMangaClick,
                    onFavorite     = vm::toggleFavorite,
                    scrollBehavior = scrollBehavior
                )
            }
        }
    }
}

@Composable
private fun LibraryGrid(
    isLoading:     Boolean,
    manga:         List<Manga>,
    onMangaClick:  (Manga) -> Unit,
    onFavorite:    (Manga) -> Unit,
    scrollBehavior: TopAppBarScrollBehavior? = null
) {
    val modifier = if (scrollBehavior != null)
        Modifier.fillMaxSize().nestedScroll(scrollBehavior.nestedScrollConnection)
    else
        Modifier.fillMaxSize()

    LazyVerticalGrid(
        columns               = GridCells.Adaptive(minSize = 100.dp),
        contentPadding        = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        verticalArrangement   = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier              = modifier
    ) {
        if (isLoading) {
            items(12) {
                MangaCoverShimmer(modifier = Modifier.fillMaxWidth())
            }
        } else {
            items(manga, key = { it.id }) { m ->
                MangaGridItem(manga = m, onClick = { onMangaClick(m) }, onFavorite = { onFavorite(m) })
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MangaGridItem(
    manga:      Manga,
    onClick:    () -> Unit,
    onFavorite: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            MangaCover(
                url          = manga.thumbnailUrl,
                title        = manga.title,
                unreadCount  = manga.unreadCount,
                modifier     = Modifier.fillMaxSize()
            )
            // Favourite star
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.35f))
                    .clickable(onClick = onFavorite),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (manga.favorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    null,
                    tint = if (manga.favorite) Color(0xFFFFC107) else Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Text(
            manga.title,
            maxLines  = 2,
            overflow  = TextOverflow.Ellipsis,
            style     = MaterialTheme.typography.labelMedium,
            modifier  = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SortSheet(
    current:        LibrarySortMode,
    ascending:      Boolean,
    showUnread:     Boolean,
    onSort:         (LibrarySortMode) -> Unit,
    onToggleDir:    () -> Unit,
    onToggleUnread: () -> Unit,
    onDismiss:      () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState       = rememberModalBottomSheetState()
    ) {
        Column(Modifier.padding(16.dp).navigationBarsPadding()) {
            Text("Sort & Filter", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))

            Text("Sort by", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 4.dp))

            LibrarySortMode.entries.forEach { mode ->
                Row(
                    Modifier.fillMaxWidth().clickable { onSort(mode) }.padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = current == mode, onClick = { onSort(mode) })
                    Text(mode.label, modifier = Modifier.padding(start = 4.dp),
                        style = MaterialTheme.typography.bodyMedium)
                }
            }

            Spacer(Modifier.height(8.dp))

            Surface(
                onClick = onToggleDir,
                color   = MaterialTheme.colorScheme.surfaceVariant,
                shape   = RoundedCornerShape(12.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Direction", style = MaterialTheme.typography.bodyMedium)
                    Text(if (ascending) "↑ Ascending" else "↓ Descending",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.height(6.dp))
            Surface(
                onClick = onToggleUnread,
                color   = if (showUnread) MaterialTheme.colorScheme.primaryContainer
                          else MaterialTheme.colorScheme.surfaceVariant,
                shape   = RoundedCornerShape(12.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Show unread only", style = MaterialTheme.typography.bodyMedium)
                    Icon(Icons.Filled.FilterList, null, modifier = Modifier.size(18.dp),
                        tint = if (showUnread) MaterialTheme.colorScheme.primary
                               else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun CategoryDialog(
    name:        String,
    isEditing:   Boolean,
    onNameChange: (String) -> Unit,
    onConfirm:   () -> Unit,
    onDismiss:   () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title  = { Text(if (isEditing) "Rename Category" else "New Category") },
        text   = {
            OutlinedTextField(
                value         = name,
                onValueChange = onNameChange,
                label         = { Text("Category name") },
                singleLine    = true,
                shape         = RoundedCornerShape(12.dp),
                modifier      = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = onConfirm, enabled = name.isNotBlank()) {
                Text(if (isEditing) "Rename" else "Create")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

