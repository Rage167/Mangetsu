package com.mangetsu.app.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.core.model.Category
import com.mangetsu.core.model.LibraryFilter
import com.mangetsu.core.model.LibrarySortMode
import com.mangetsu.core.model.LibraryUpdateStatus
import com.mangetsu.core.model.Manga
import com.mangetsu.core.model.MangaUpdate
import com.mangetsu.core.model.UpdateCheckState
import com.mangetsu.data.library.LibraryRepository
import com.mangetsu.data.updates.LibraryUpdateService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LibraryUiState(
    val manga:              List<Manga>         = emptyList(),
    val categories:         List<Category>      = emptyList(),
    val selectedCategoryId: Long?               = null,
    val filter:             LibraryFilter       = LibraryFilter(),
    val totalCount:         Int                 = 0,
    val unreadCount:        Int                 = 0,
    val isLoading:          Boolean             = true,
    val updateStatus:       LibraryUpdateStatus = LibraryUpdateStatus(),
    val updates:            List<MangaUpdate>   = emptyList(),
    val snackMessage:       String?             = null,
    val categoryDialogOpen: Boolean             = false,
    val newCategoryName:    String              = "",
    val editingCategory:    Category?           = null,
    val sortSheetOpen:      Boolean             = false
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val libraryRepo:   LibraryRepository,
    private val updateService: LibraryUpdateService
) : ViewModel() {

    private val _filter = MutableStateFlow(LibraryFilter())
    private val _extra  = MutableStateFlow(LibraryUiState())

    val uiState: StateFlow<LibraryUiState> = combine(
        _filter.debounce(150).flatMapLatest { filter ->
            libraryRepo.getLibraryManga(filter)
        },
        libraryRepo.getLibraryWithCategories(),
        updateService.status,
        updateService.updates,
        _extra
    ) { manga, libWithCats, updateStatus, updates, extra ->
        extra.copy(
            manga         = manga,
            categories    = libWithCats.categories,
            totalCount    = libWithCats.totalCount,
            unreadCount   = libWithCats.unreadCount,
            updateStatus  = updateStatus,
            updates       = updates,
            isLoading     = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    fun onSearchQuery(q: String) = _filter.update { it.copy(searchQuery = q) }

    fun selectCategory(id: Long?) {
        _filter.update { it.copy(categoryId = id) }
        _extra.update  { it.copy(selectedCategoryId = id) }
    }

    fun setSortMode(mode: LibrarySortMode) = _filter.update { it.copy(sortMode = mode) }
    fun toggleSortDirection()              = _filter.update { it.copy(sortAscending = !it.sortAscending) }
    fun toggleUnreadFilter()               = _filter.update { it.copy(showUnreadOnly = !it.showUnreadOnly) }
    fun openSortSheet()                    = _extra.update { it.copy(sortSheetOpen = true) }
    fun closeSortSheet()                   = _extra.update { it.copy(sortSheetOpen = false) }

    fun removeFromLibrary(mangaId: Long) {
        viewModelScope.launch {
            libraryRepo.removeFromLibrary(mangaId)
            _extra.update { it.copy(snackMessage = "Removed from library") }
        }
    }

    fun toggleFavorite(manga: Manga) {
        viewModelScope.launch { libraryRepo.setFavorite(manga.id, !manga.favorite) }
    }

    fun openCreateCategory() = _extra.update {
        it.copy(categoryDialogOpen = true, newCategoryName = "", editingCategory = null)
    }

    fun openEditCategory(cat: Category) = _extra.update {
        it.copy(categoryDialogOpen = true, newCategoryName = cat.name, editingCategory = cat)
    }

    fun onCategoryNameInput(name: String) = _extra.update { it.copy(newCategoryName = name) }
    fun dismissCategoryDialog()           = _extra.update { it.copy(categoryDialogOpen = false) }

    fun confirmCategory() {
        val name    = _extra.value.newCategoryName.trim()
        val editing = _extra.value.editingCategory
        if (name.isBlank()) return
        viewModelScope.launch {
            if (editing != null) {
                libraryRepo.renameCategory(editing.id, name)
                _extra.update { it.copy(snackMessage = "Category renamed", categoryDialogOpen = false) }
            } else {
                libraryRepo.createCategory(name)
                _extra.update { it.copy(snackMessage = "Category '$name' created", categoryDialogOpen = false) }
            }
        }
    }

    fun deleteCategory(categoryId: Long) {
        viewModelScope.launch {
            libraryRepo.deleteCategory(categoryId)
            if (_extra.value.selectedCategoryId == categoryId) selectCategory(null)
            _extra.update { it.copy(snackMessage = "Category deleted") }
        }
    }

    fun reorderCategories(orderedIds: List<Long>) {
        viewModelScope.launch { libraryRepo.reorderCategories(orderedIds) }
    }

    fun setMangaCategories(mangaId: Long, categoryIds: List<Long>) {
        viewModelScope.launch { libraryRepo.setMangaCategories(mangaId, categoryIds) }
    }

    fun checkForUpdates(force: Boolean = false) {
        if (uiState.value.updateStatus.state == UpdateCheckState.RUNNING) return
        viewModelScope.launch { updateService.checkAll(force) }
    }

    fun clearUpdates() = updateService.clearUpdates()
    fun clearSnack()   = _extra.update { it.copy(snackMessage = null) }
}
