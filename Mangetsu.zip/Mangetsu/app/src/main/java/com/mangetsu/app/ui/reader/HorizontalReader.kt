// imports added by fix
package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HorizontalReader(
    pages:         List<ReaderPage>,
    initialPage:   Int,
    settings:      ReaderSettings,
    imageLoader:   coil.ImageLoader,
    onPageChange:  (Int) -> Unit,
    onResolve:     (Int) -> Unit,
    onTapCenter:   () -> Unit,
    onSuccess:     (Int) -> Unit,
    onError:       (Int, String) -> Unit
) {
    if (pages.isEmpty()) return

    val clampedInitial = initialPage.coerceIn(0, pages.lastIndex)

    // RTL: reverse the page order visually
    val isRtl = settings.readingMode == ReadingMode.HORIZONTAL_RTL
    val displayPages = if (isRtl) pages.reversed() else pages

    val pagerState: PagerState = rememberPagerState(initialPage = clampedInitial) {
        displayPages.size
    }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { displayIndex ->
            val actualIndex = if (isRtl) displayPages.lastIndex - displayIndex else displayIndex
            onPageChange(actualIndex)
        }
    }

    // Sync external page changes (e.g. from slider seek)
    LaunchedEffect(initialPage) {
        val targetDisplay = if (isRtl) displayPages.lastIndex - initialPage else initialPage
        if (pagerState.currentPage != targetDisplay) {
            pagerState.animateScrollToPage(targetDisplay)
        }
    }

    HorizontalPager(
        state    = pagerState,
        modifier = Modifier.fillMaxSize(),
        key      = { displayPages[it].index }
    ) { displayIndex ->
        val page = displayPages[displayIndex]
        val actualIndex = if (isRtl) displayPages.lastIndex - displayIndex else displayIndex

        ZoomablePageLayout(
            modifier    = Modifier.fillMaxSize(),
            maxScale    = settings.maxScaleFactor,
            onTapLeft   = {
                if (isRtl) onPageChange((actualIndex + 1).coerceAtMost(pages.lastIndex))
                else        onPageChange((actualIndex - 1).coerceAtLeast(0))
            },
            onTapRight  = {
                if (isRtl) onPageChange((actualIndex - 1).coerceAtLeast(0))
                else        onPageChange((actualIndex + 1).coerceAtMost(pages.lastIndex))
            },
            onTapCenter = onTapCenter
        ) {
            PageImageStateful(
                page         = page,
                imageLoader  = imageLoader,
                contentScale = ContentScale.Fit,
                cropBorders  = settings.cropBorders,
                onNeedResolve = { onResolve(actualIndex) },
                onSuccess    = { onSuccess(actualIndex) },
                onError      = { msg -> onError(actualIndex, msg) }
            )
        }
    }
}
