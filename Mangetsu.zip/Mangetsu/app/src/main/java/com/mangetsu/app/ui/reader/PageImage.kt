package com.mangetsu.app.ui.reader

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Size

/**
 * Renders a single manga page using Coil's [AsyncImage].
 * Handles loading spinner, retry on error, and lazy URL resolution.
 */
@Composable
fun PageImage(
    page:          ReaderPage,
    imageLoader:   ImageLoader,
    modifier:      Modifier         = Modifier.fillMaxSize(),
    contentScale:  ContentScale     = ContentScale.Fit,
    cropBorders:   Boolean          = false,
    onNeedResolve: () -> Unit       = {},
    onSuccess:     () -> Unit       = {},
    onError:       (String) -> Unit = {}
) {
    val context = LocalContext.current
    var retryKey by remember { mutableIntStateOf(0) }

    // Trigger lazy URL resolution if not yet resolved
    LaunchedEffect(page.url) {
        if (!page.isResolved) onNeedResolve()
    }

    val effectiveUrl = page.effectiveUrl

    // Still waiting for URL resolution
    if (effectiveUrl == null) {
        Box(modifier, contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
        }
        return
    }

    val effectiveScale = if (cropBorders) ContentScale.Crop else contentScale

    val request = remember(effectiveUrl, retryKey) {
        ImageRequest.Builder(context)
            .data(effectiveUrl)
            .size(Size.ORIGINAL)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .networkCachePolicy(CachePolicy.ENABLED)
            .crossfade(true)
            .listener(
                onSuccess = { _, _ -> onSuccess() },
                onError   = { _, result ->
                    onError(result.throwable.message ?: "Load error on page ${page.index + 1}")
                }
            )
            .build()
    }

    AsyncImage(
        model              = request,
        imageLoader        = imageLoader,
        contentDescription = "Page ${page.index + 1}",
        contentScale       = effectiveScale,
        filterQuality      = FilterQuality.High,
        modifier           = modifier,
        placeholder        = placeholderPainter(),
        error              = errorContent(
            pageIndex = page.index,
            onRetry   = { retryKey++; onNeedResolve() }
        )
    )
}

@Composable
private fun placeholderPainter() = null  // Coil shows nothing while loading — we overlay spinner below

// Because AsyncImage doesn't expose loading/error slots like SubcomposeAsyncImage,
// we use a wrapper with explicit state tracking
@Composable
fun PageImageStateful(
    page:          ReaderPage,
    imageLoader:   ImageLoader,
    modifier:      Modifier         = Modifier.fillMaxSize(),
    contentScale:  ContentScale     = ContentScale.Fit,
    cropBorders:   Boolean          = false,
    onNeedResolve: () -> Unit       = {},
    onSuccess:     () -> Unit       = {},
    onError:       (String) -> Unit = {}
) {
    val context  = LocalContext.current
    var retryKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(page.url) {
        if (!page.isResolved) onNeedResolve()
    }

    val effectiveUrl   = page.effectiveUrl
    val effectiveScale = if (cropBorders) ContentScale.Crop else contentScale

    Box(modifier, contentAlignment = Alignment.Center) {
        if (effectiveUrl == null) {
            // URL not yet resolved
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
            return@Box
        }

        val request = remember(effectiveUrl, retryKey) {
            ImageRequest.Builder(context)
                .data(effectiveUrl)
                .size(Size.ORIGINAL)
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .crossfade(true)
                .build()
        }

        val state = coil.compose.rememberAsyncImagePainter(
            model       = request,
            imageLoader = imageLoader
        )

        when (val s = state.state) {
            is coil.compose.AsyncImagePainter.State.Loading -> {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
            }
            is coil.compose.AsyncImagePainter.State.Error -> {
                LaunchedEffect(s) {
                    onError(s.result?.throwable?.message ?: "Page ${page.index + 1} failed")
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.BrokenImage, null,
                        tint = Color.White.copy(alpha = 0.4f), modifier = Modifier.size(40.dp))
                    Text("Page ${page.index + 1} failed",
                        color = Color.White.copy(alpha = 0.5f),
                        style = MaterialTheme.typography.labelSmall)
                    IconButton(onClick = { retryKey++; onNeedResolve() }) {
                        Icon(Icons.Filled.Refresh, "Retry", tint = Color.White.copy(alpha = 0.7f))
                    }
                }
            }
            is coil.compose.AsyncImagePainter.State.Success -> {
                LaunchedEffect(Unit) { onSuccess() }
                androidx.compose.foundation.Image(
                    painter            = state,
                    contentDescription = "Page ${page.index + 1}",
                    contentScale       = effectiveScale,
                    modifier           = Modifier.fillMaxSize()
                )
            }
            else -> {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
            }
        }
    }
}

@Composable
private fun errorContent(
    pageIndex: Int,
    onRetry:   () -> Unit
): androidx.compose.ui.graphics.painter.Painter? = null // handled by PageImageStateful
