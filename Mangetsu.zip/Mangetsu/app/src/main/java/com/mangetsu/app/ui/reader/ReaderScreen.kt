// imports added by fix
package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings

import android.app.Activity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.mangetsu.data.extension.engine.ErrorKind

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    mangaId:   Long,
    chapterId: Long,
    onBack:    () -> Unit,
    vm: ReaderViewModel = hiltViewModel()
) {
    val state   by vm.uiState.collectAsStateWithLifecycle()
    val context  = LocalContext.current
    val view     = LocalView.current

    // Build a session-scoped Coil ImageLoader with large caches
    val imageLoader = remember {
        ImageLoader.Builder(context)
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizePercent(0.30)   // 30% of available memory
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(context.cacheDir.resolve("reader_images"))
                    .maxSizeBytes(512L * 1024 * 1024)
                    .build()
            }
            .crossfade(true)
            .allowHardware(true)
            .allowRgb565(true)
            .build()
    }

    LaunchedEffect(mangaId, chapterId) { vm.load(mangaId, chapterId) }

    // Immersive mode + keep screen on
    DisposableEffect(state.settings.keepScreenOn) {
        val window = (context as? Activity)?.window ?: return@DisposableEffect onDispose {}
        if (state.settings.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, view)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        onDispose {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    if (state.showSettings) {
        ReaderSettingsSheet(
            settings  = state.settings,
            onUpdate  = vm::updateSettings,
            onDismiss = vm::dismissSettings
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when {
            state.isLoading           -> ReaderLoading()
            state.error != null       -> ReaderError(state.error!!, state.errorKind, onBack, vm::retry)
            state.pages.isEmpty()     -> ReaderLoading()
            else -> ReaderContent(
                state        = state,
                imageLoader  = imageLoader,
                onPageChange = vm::onPageChange,
                onResolve    = vm::resolvePageUrl,
                onTapCenter  = vm::toggleControls,
                onSuccess    = vm::onPageLoadSuccess,
                onError      = vm::onPageLoadError
            )
        }

        // Controls overlay
        AnimatedVisibility(
            visible = state.showControls && !state.isLoading && state.error == null,
            enter   = fadeIn(),
            exit    = fadeOut()
        ) {
            ReaderOverlay(
                state      = state,
                onBack     = onBack,
                onSettings = vm::toggleSettings,
                onSeek     = vm::goToPage
            )
        }

        // Progress saved toast
        AnimatedVisibility(
            visible  = state.saveProgress is SaveProgressState.Saved,
            enter    = fadeIn(),
            exit     = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp)
        ) {
            Surface(color = Color.Black.copy(alpha = 0.7f), shape = MaterialTheme.shapes.small) {
                Text(
                    "Progress saved",
                    color    = Color.White,
                    style    = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun ReaderContent(
    state:        ReaderUiState,
    imageLoader:  ImageLoader,
    onPageChange: (Int) -> Unit,
    onResolve:    (Int) -> Unit,
    onTapCenter:  () -> Unit,
    onSuccess:    (Int) -> Unit,
    onError:      (Int, String) -> Unit
) {
    when (state.settings.readingMode) {
        ReadingMode.HORIZONTAL_LTR,
        ReadingMode.HORIZONTAL_RTL -> HorizontalReader(
            pages = state.pages, initialPage = state.currentPage,
            settings = state.settings, imageLoader = imageLoader,
            onPageChange = onPageChange, onResolve = onResolve,
            onTapCenter = onTapCenter, onSuccess = onSuccess, onError = onError
        )
        ReadingMode.VERTICAL -> VerticalReader(
            pages = state.pages, initialPage = state.currentPage,
            settings = state.settings, imageLoader = imageLoader,
            onPageChange = onPageChange, onResolve = onResolve,
            onTapCenter = onTapCenter, onSuccess = onSuccess, onError = onError
        )
        ReadingMode.WEBTOON -> WebtoonReader(
            pages = state.pages, initialPage = state.currentPage,
            settings = state.settings, imageLoader = imageLoader,
            onPageChange = onPageChange, onResolve = onResolve,
            onTapCenter = onTapCenter, onSuccess = onSuccess, onError = onError
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReaderOverlay(
    state:      ReaderUiState,
    onBack:     () -> Unit,
    onSettings: () -> Unit,
    onSeek:     (Int) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Surface(color = Color.Black.copy(alpha = 0.7f), modifier = Modifier.fillMaxWidth()) {
            TopAppBar(
                title = {
                    Column {
                        Text(state.mangaTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(state.chapterName,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.65f), maxLines = 1)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                },
                actions = {
                    if (state.settings.showPageNumbers) {
                        Text(
                            state.currentPageDisplay,
                            color    = Color.White,
                            style    = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Filled.Settings, "Settings", tint = Color.White)
                    }
                },
                colors   = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                modifier = Modifier.statusBarsPadding()
            )
        }

        Spacer(Modifier.weight(1f))

        Surface(
            color    = Color.Black.copy(alpha = 0.7f),
            modifier = Modifier.fillMaxWidth().navigationBarsPadding()
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                if (state.totalPages > 1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("1", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Text("${state.totalPages}", color = Color.White,
                            style = MaterialTheme.typography.labelSmall)
                    }
                    Slider(
                        value         = state.currentPage.toFloat(),
                        onValueChange = { onSeek(it.toInt()) },
                        valueRange    = 0f..(state.totalPages - 1).toFloat().coerceAtLeast(1f),
                        steps         = (state.totalPages - 2).coerceAtLeast(0),
                        modifier      = Modifier.fillMaxWidth(),
                        colors        = SliderDefaults.colors(
                            thumbColor         = Color.White,
                            activeTrackColor   = Color.White,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ReaderLoading() {
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        CircularProgressIndicator(color = Color.White)
    }
}

@Composable
private fun ReaderError(
    message:   String,
    errorKind: ErrorKind?,
    onBack:    () -> Unit,
    onRetry:   () -> Unit
) {
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.BrokenImage, null,
                tint = Color.White.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text(
                when (errorKind) {
                    ErrorKind.SOURCE_NOT_FOUND -> "Extension not installed"
                    ErrorKind.TIMEOUT          -> "Request timed out"
                    else                       -> "Failed to load pages"
                },
                color = Color.White, style = MaterialTheme.typography.titleSmall
            )
            Text(message, color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 32.dp, vertical = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onBack) { Text("Go back") }
                Button(onClick = onRetry) {
                    Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(16.dp))
                    Text("Retry")
                }
            }
        }
    }
}
