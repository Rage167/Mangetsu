// imports added by fix
package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.ImportExport
import androidx.compose.material.icons.filled.SwipeLeft
import androidx.compose.material.icons.filled.SwipeRight
import androidx.compose.material.icons.filled.SwipeVertical
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderSettingsSheet(
    settings:  ReaderSettings,
    onUpdate:  (ReaderSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest     = onDismiss,
        sheetState           = sheetState,
        containerColor       = Color(0xFF1C1B1F),
        contentColor         = Color.White,
        shape                = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text("Reader Settings", style = MaterialTheme.typography.titleMedium,
                color = Color.White, modifier = Modifier.padding(bottom = 16.dp))

            // ── Reading Mode ─────────────────────────────────────────────────
            SectionLabel("Reading Mode")
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReadingMode.entries.forEach { mode ->
                    ModeChip(
                        label    = mode.label,
                        icon     = mode.icon(),
                        selected = settings.readingMode == mode,
                        onClick  = { onUpdate(settings.copy(readingMode = mode)) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(Modifier.height(16.dp))

            // ── Brightness ───────────────────────────────────────────────────
            SectionLabel("Brightness")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Brightness4, null, tint = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp))
                Slider(
                    value         = if (settings.brightness < 0f) 0.5f else settings.brightness,
                    onValueChange = { onUpdate(settings.copy(brightness = it)) },
                    valueRange    = 0.05f..1f,
                    modifier      = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text(
                    if (settings.brightness < 0f) "Auto"
                    else "${(settings.brightness * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }
            Row(Modifier.clickable { onUpdate(settings.copy(brightness = -1f)) }) {
                Text("Reset to system brightness",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary)
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(Modifier.height(16.dp))

            // ── Page Spacing ─────────────────────────────────────────────────
            SectionLabel("Page Spacing: ${settings.pageSpacingDp}dp")
            Slider(
                value         = settings.pageSpacingDp.toFloat(),
                onValueChange = { onUpdate(settings.copy(pageSpacingDp = it.toInt())) },
                valueRange    = 0f..32f,
                steps         = 7,
                modifier      = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(Modifier.height(8.dp))

            // ── Toggles ──────────────────────────────────────────────────────
            SettingsToggle(
                label    = "Crop borders",
                subtitle = "Removes white margins around pages",
                icon     = Icons.Filled.CropFree,
                checked  = settings.cropBorders,
                onToggle = { onUpdate(settings.copy(cropBorders = it)) }
            )
            SettingsToggle(
                label    = "Show page numbers",
                icon     = Icons.Filled.FormatAlignCenter,
                checked  = settings.showPageNumbers,
                onToggle = { onUpdate(settings.copy(showPageNumbers = it)) }
            )
            SettingsToggle(
                label    = "Keep screen on",
                icon     = Icons.Filled.ImportExport,
                checked  = settings.keepScreenOn,
                onToggle = { onUpdate(settings.copy(keepScreenOn = it)) }
            )

            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── Sub-composables ───────────────────────────────────────────────────────────

@Composable
private fun SectionLabel(text: String) {
    Text(
        text     = text,
        style    = MaterialTheme.typography.labelMedium,
        color    = Color.White.copy(alpha = 0.5f),
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ModeChip(
    label:    String,
    icon:     ImageVector,
    selected: Boolean,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick    = onClick,
        modifier   = modifier,
        shape      = RoundedCornerShape(8.dp),
        color      = if (selected) MaterialTheme.colorScheme.primary
                     else Color.White.copy(alpha = 0.08f),
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary
                       else Color.White.copy(alpha = 0.7f)
    ) {
        Column(
            Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 2)
        }
    }
}

@Composable
private fun SettingsToggle(
    label:    String,
    subtitle: String?      = null,
    icon:     ImageVector,
    checked:  Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(icon, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                if (subtitle != null) {
                    Text(subtitle, style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.4f))
                }
            }
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

private fun ReadingMode.icon(): ImageVector = when (this) {
    ReadingMode.HORIZONTAL_LTR -> Icons.Filled.SwipeRight
    ReadingMode.HORIZONTAL_RTL -> Icons.Filled.SwipeLeft
    ReadingMode.VERTICAL       -> Icons.Filled.SwipeVertical
    ReadingMode.WEBTOON        -> Icons.Filled.ImportExport
}
