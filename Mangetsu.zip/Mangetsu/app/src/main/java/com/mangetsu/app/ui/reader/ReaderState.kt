package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReaderSettings
import com.mangetsu.core.model.ReadingMode
import com.mangetsu.data.extension.engine.ErrorKind
import com.mangetsu.extensionapi.model.SPage

sealed class PageLoadState {
    data object Idle    : PageLoadState()
    data object Loading : PageLoadState()
    data object Success : PageLoadState()
    data class  Error(val message: String) : PageLoadState()
}

data class ReaderPage(
    val index:      Int,
    val url:        String,
    val imageUrl:   String?,
    val isResolved: Boolean       = imageUrl != null,
    val loadState:  PageLoadState = PageLoadState.Idle
) {
    val effectiveUrl: String? get() = imageUrl ?: url.takeIf { it.startsWith("http") }

    companion object {
        fun fromSPage(p: SPage) = ReaderPage(
            index    = p.index,
            url      = p.url,
            imageUrl = p.imageUrl
        )
    }
}

data class ReaderUiState(
    val pages:        List<ReaderPage> = emptyList(),
    val currentPage:  Int              = 0,
    val totalPages:   Int              = 0,
    val isLoading:    Boolean          = true,
    val error:        String?          = null,
    val errorKind:    ErrorKind?       = null,
    val showControls: Boolean          = true,
    val showSettings: Boolean          = false,
    val mangaTitle:   String           = "",
    val chapterName:  String           = "",
    val settings:     ReaderSettings   = ReaderSettings(),
    val isLastPage:   Boolean          = false,
    val isFirstPage:  Boolean          = true,
    val saveProgress: SaveProgressState = SaveProgressState.Idle
) {
    val progress: Float get() =
        if (totalPages > 1) currentPage.toFloat() / (totalPages - 1) else 0f

    val currentPageDisplay: String get() = "${currentPage + 1} / $totalPages"
}

sealed class SaveProgressState {
    data object Idle   : SaveProgressState()
    data object Saving : SaveProgressState()
    data object Saved  : SaveProgressState()
}
