// imports added by fix
package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.data.reader.ReaderImageLoader
import com.mangetsu.data.reader.ReaderSettingsRepository
import com.mangetsu.domain.repository.ChapterRepository
import com.mangetsu.domain.repository.LibraryRepository
import com.mangetsu.domain.usecase.MarkChapterReadUseCase
import com.mangetsu.domain.usecase.RecordHistoryUseCase
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SPage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val chapterRepository:  ChapterRepository,
    private val libraryRepository:  LibraryRepository,
    private val extRepository:      ExtensionRepositoryImpl,
    private val imageLoader:        ReaderImageLoader,
    private val settingsRepository: ReaderSettingsRepository,
    private val markChapterRead:    MarkChapterReadUseCase,
    private val recordHistory:      RecordHistoryUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReaderUiState())
    val uiState: StateFlow<ReaderUiState> = _uiState

    private var mangaId    = 0L
    private var chapterId  = 0L
    private var sourceId   = 0L
    private var saveJob:   Job? = null
    private var hideControlsJob: Job? = null

    // ── Init ──────────────────────────────────────────────────────────────────

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { settings ->
                _uiState.update { it.copy(settings = settings) }
            }
        }
    }

    // ── Load chapter ──────────────────────────────────────────────────────────

    fun load(mangaId: Long, chapterId: Long) {
        if (this.mangaId == mangaId && this.chapterId == chapterId
            && !_uiState.value.isLoading && _uiState.value.error == null) return

        this.mangaId   = mangaId
        this.chapterId = chapterId

        imageLoader.cancelAllPrefetches()

        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true, error = null, pages = emptyList()) }

            val manga   = libraryRepository.getMangaByIdOrNull(mangaId)
            val chapter = chapterRepository.getChapterById(chapterId)

            if (chapter == null) {
                _uiState.update { it.copy(isLoading = false, error = "Chapter not found.") }
                return@launch
            }

            sourceId = chapter.sourceId
            val sChapter = SChapter(id = chapter.url, name = chapter.name, url = chapter.url, chapterNumber = chapter.chapterNumber)

            when (val result = extRepository.safePageList(chapter.sourceId, sChapter)) {
                is ExtensionResult.Success -> {
                    val pages = result.data.map { ReaderPage.fromSPage(it) }
                    val startPage = chapter.lastPageRead.coerceIn(0, maxOf(0, pages.size - 1))

                    _uiState.update {
                        it.copy(
                            pages        = pages,
                            totalPages   = pages.size,
                            currentPage  = startPage,
                            isLoading    = false,
                            mangaTitle   = manga?.title   ?: "",
                            chapterName  = chapter.name,
                            isFirstPage  = startPage == 0,
                            isLastPage   = startPage >= pages.size - 1
                        )
                    }
                    // Kick off prefetch starting from saved position
                    prefetchAround(startPage)
                    Timber.d("ReaderViewModel: loaded ${pages.size} pages, resuming at $startPage")
                }
                is ExtensionResult.Error -> {
                    _uiState.update {
                        it.copy(isLoading = false, error = result.message, errorKind = result.kind)
                    }
                }
            }
        }
    }

    // ── Page navigation ───────────────────────────────────────────────────────

    fun onPageChange(index: Int) {
        val state = _uiState.value
        if (state.pages.isEmpty() || index == state.currentPage) return

        val clamped = index.coerceIn(0, state.pages.lastIndex)
        _uiState.update {
            it.copy(
                currentPage = clamped,
                isFirstPage = clamped == 0,
                isLastPage  = clamped >= it.totalPages - 1
            )
        }

        // Cancel out-of-window prefetches, then kick new window
        val urls = state.pages.map { it.effectiveUrl }
        imageLoader.cancelOutOfWindowPrefetches(urls, clamped)
        prefetchAround(clamped)

        // Resolve lazy page URLs in lookahead window
        for (i in clamped..(clamped + 3).coerceAtMost(state.pages.lastIndex)) {
            resolvePageUrl(i)
        }

        // Mark read when last page
        if (clamped >= state.totalPages - 1) {
            persistProgress(clamped, read = true)
        }

        scheduleHideControls()
    }

    fun goToPage(index: Int) = onPageChange(index)

    // ── Lazy URL resolution ───────────────────────────────────────────────────

    fun resolvePageUrl(pageIndex: Int) {
        val page = _uiState.value.pages.getOrNull(pageIndex) ?: return
        if (page.isResolved) return

        viewModelScope.launch(Dispatchers.IO) {
            val chapter = chapterRepository.getChapterById(chapterId) ?: return@launch
            val sPage   = SPage(page.index, page.url, page.imageUrl)

            when (val r = extRepository.safePageImageUrl(chapter.sourceId, sPage)) {
                is ExtensionResult.Success -> {
                    updatePage(pageIndex) { it.copy(imageUrl = r.data.imageUrl, isResolved = true) }
                    // Re-trigger prefetch with resolved URLs
                    prefetchAround(_uiState.value.currentPage)
                }
                is ExtensionResult.Error ->
                    Timber.w("resolvePageUrl[$pageIndex] failed: ${r.message}")
            }
        }
    }

    fun onPageLoadSuccess(pageIndex: Int) {
        updatePage(pageIndex) { it.copy(loadState = PageLoadState.Success) }
    }

    fun onPageLoadError(pageIndex: Int, message: String) {
        updatePage(pageIndex) { it.copy(loadState = PageLoadState.Error(message)) }
    }

    // ── Controls ──────────────────────────────────────────────────────────────

    fun toggleControls() {
        _uiState.update { it.copy(showControls = !it.showControls) }
        if (_uiState.value.showControls) scheduleHideControls()
    }

    fun showControls() {
        _uiState.update { it.copy(showControls = true) }
        scheduleHideControls()
    }

    fun toggleSettings() = _uiState.update { it.copy(showSettings = !it.showSettings) }
    fun dismissSettings() = _uiState.update { it.copy(showSettings = false) }

    private fun scheduleHideControls() {
        hideControlsJob?.cancel()
        hideControlsJob = viewModelScope.launch {
            delay(3_000)
            if (!_uiState.value.showSettings) {
                _uiState.update { it.copy(showControls = false) }
            }
        }
    }

    // ── Settings ──────────────────────────────────────────────────────────────

    fun updateSettings(settings: ReaderSettings) {
        _uiState.update { it.copy(settings = settings) }
        viewModelScope.launch { settingsRepository.save(settings) }
    }

    fun setReadingMode(mode: ReadingMode) = updateSettings(_uiState.value.settings.copy(readingMode = mode))
    fun setBrightness(value: Float)       = updateSettings(_uiState.value.settings.copy(brightness = value))
    fun setPageSpacing(dp: Int)           = updateSettings(_uiState.value.settings.copy(pageSpacingDp = dp))
    fun toggleCropBorders()               = updateSettings(_uiState.value.settings.copy(cropBorders = !_uiState.value.settings.cropBorders))

    // ── Retry ─────────────────────────────────────────────────────────────────

    fun retry() {
        val mid = mangaId
        val cid = chapterId
        mangaId   = 0L
        chapterId = 0L
        load(mid, cid)
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private fun prefetchAround(index: Int) {
        val urls = _uiState.value.pages.map { it.effectiveUrl }
        imageLoader.prefetch(urls, index)
    }

    private fun updatePage(index: Int, transform: (ReaderPage) -> ReaderPage) {
        val pages = _uiState.value.pages.toMutableList()
        if (index in pages.indices) {
            pages[index] = transform(pages[index])
            _uiState.update { it.copy(pages = pages) }
        }
    }

    private fun persistProgress(page: Int, read: Boolean = false) {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            _uiState.update { it.copy(saveProgress = SaveProgressState.Saving) }
            if (read) markChapterRead(chapterId, page)
            recordHistory(mangaId, chapterId, page)
            _uiState.update { it.copy(saveProgress = SaveProgressState.Saved) }
            delay(1000)
            _uiState.update { it.copy(saveProgress = SaveProgressState.Idle) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        val page = _uiState.value.currentPage
        if (page > 0) persistProgress(page)
        imageLoader.cancelAllPrefetches()
        val urls = _uiState.value.pages.map { it.effectiveUrl }
        imageLoader.evictChapterFromMemory(urls)
    }
}
