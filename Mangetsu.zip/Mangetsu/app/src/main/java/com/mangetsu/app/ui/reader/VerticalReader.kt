// imports added by fix
package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

@Composable
fun VerticalReader(
    pages:        List<ReaderPage>,
    initialPage:  Int,
    settings:     ReaderSettings,
    imageLoader:  coil.ImageLoader,
    onPageChange: (Int) -> Unit,
    onResolve:    (Int) -> Unit,
    onTapCenter:  () -> Unit,
    onSuccess:    (Int) -> Unit,
    onError:      (Int, String) -> Unit
) {
    if (pages.isEmpty()) return

    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = initialPage.coerceIn(0, pages.lastIndex)
    )

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { index ->
            onPageChange(index)
        }
    }

    LazyColumn(
        state = listState
    ) {
        itemsIndexed(pages, key = { _, page -> page.index }) { index, page ->
            ZoomablePageLayout(
                modifier    = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                maxScale    = settings.maxScaleFactor,
                onTapLeft   = { onPageChange((index - 1).coerceAtLeast(0)) },
                onTapRight  = { onPageChange((index + 1).coerceAtMost(pages.lastIndex)) },
                onTapCenter = onTapCenter
            ) {
                PageImageStateful(
                    page          = page,
                    imageLoader   = imageLoader,
                    modifier      = Modifier.fillMaxWidth().wrapContentHeight(),
                    contentScale  = ContentScale.FillWidth,
                    cropBorders   = settings.cropBorders,
                    onNeedResolve = { onResolve(index) },
                    onSuccess     = { onSuccess(index) },
                    onError       = { msg -> onError(index, msg) }
                )
            }

            if (settings.pageSpacingDp > 0) {
                Spacer(Modifier.height(settings.pageSpacingDp.dp))
            }
        }
    }
}
