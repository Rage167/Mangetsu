// imports added by fix
package com.mangetsu.app.ui.reader

import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale

/**
 * Webtoon (infinite vertical strip) reader.
 *
 * Unlike [VerticalReader], webtoon mode:
 * - Has zero page spacing (pages stitch together seamlessly)
 * - Disables per-page zoom (the whole strip is one continuous surface)
 * - Uses FillWidth scale so each page stretches edge-to-edge
 * - Tap zones are top/bottom rather than left/right
 * - Preloads 5 pages ahead (longer strip = need further lookahead)
 */
@Composable
fun WebtoonReader(
    pages:        List<ReaderPage>,
    initialPage:  Int,
    settings:     ReaderSettings,
    imageLoader:  coil.ImageLoader,
    onPageChange: (Int) -> Unit,
    onResolve:    (Int) -> Unit,
    onTapCenter:  () -> Unit,
    onSuccess:    (Int) -> Unit,
    onError:      (Int, String) -> Unit
) {
    if (pages.isEmpty()) return

    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = initialPage.coerceIn(0, pages.lastIndex)
    )

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { index ->
            onPageChange(index)
            // Resolve URLs up to 5 pages ahead for webtoon
            for (i in index..(index + 5).coerceAtMost(pages.lastIndex)) {
                if (!pages[i].isResolved) onResolve(i)
            }
        }
    }

    LazyColumn(state = listState) {
        itemsIndexed(pages, key = { _, page -> page.index }) { index, page ->
            PageImageStateful(
                page          = page,
                imageLoader   = imageLoader,
                modifier      = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { offset ->
                                // Top/bottom tap zones for webtoon
                                onTapCenter()
                            }
                        )
                    },
                contentScale  = ContentScale.FillWidth,
                cropBorders   = settings.cropBorders,
                onNeedResolve = { onResolve(index) },
                onSuccess     = { onSuccess(index) },
                onError       = { msg -> onError(index, msg) }
            )
            // No spacing in webtoon — strip is seamless
        }
    }
}
