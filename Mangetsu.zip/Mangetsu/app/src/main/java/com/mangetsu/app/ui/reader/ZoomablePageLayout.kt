package com.mangetsu.app.ui.reader

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlin.math.abs

/**
 * Wraps a composable in a gesture-aware layer supporting:
 * - Pinch-to-zoom (min 1x, max [maxScale])
 * - Pan with bounds clamping so content never flies off-screen
 * - Double-tap to toggle between 1x and 2.5x zoom
 * - Tap zones: left 25% = previous, right 25% = next, centre = toggle controls
 * - Spring animation when releasing at scale < 1x (snaps back to fit)
 *
 * @param maxScale         Maximum zoom scale factor.
 * @param onTapLeft        Called when user taps the left tap zone.
 * @param onTapRight       Called when user taps the right tap zone.
 * @param onTapCenter      Called when user taps the centre zone (toggle controls).
 */
@Composable
fun ZoomablePageLayout(
    modifier:     Modifier = Modifier,
    maxScale:     Float    = 5f,
    onTapLeft:    () -> Unit = {},
    onTapRight:   () -> Unit = {},
    onTapCenter:  () -> Unit = {},
    content:      @Composable () -> Unit
) {
    var scale           by remember { mutableFloatStateOf(1f) }
    var offset          by remember { mutableStateOf(Offset.Zero) }
    var containerSize   by remember { mutableStateOf(IntSize.Zero) }
    var isZoomed        by remember { mutableStateOf(false) }

    // Animated spring-back when scale < 1
    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "scale"
    )

    val tapZoneWidth = containerSize.width * 0.25f

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { containerSize = it }
            // Transform gestures: pinch + pan
            .pointerInput(Unit) {
                detectTransformGestures(
                    onGesture = { centroid, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, maxScale)
                        val scaleDelta = newScale / scale
                        scale = newScale
                        isZoomed = newScale > 1.05f

                        // Adjust offset so we zoom toward the pinch centroid
                        val adjustedPan = if (zoom != 1f) {
                            val centroidOffset = centroid - Offset(
                                containerSize.width  / 2f,
                                containerSize.height / 2f
                            )
                            pan + centroidOffset * (1 - scaleDelta)
                        } else pan

                        val newOffset = offset + adjustedPan
                        offset = clampOffset(newOffset, newScale, containerSize)

                        // Snap back if released below 1x
                        if (newScale <= 1f) {
                            scale  = 1f
                            offset = Offset.Zero
                        }
                    }
                )
            }
            // Tap + double-tap
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        if (isZoomed) {
                            // Reset to fit
                            scale  = 1f
                            offset = Offset.Zero
                            isZoomed = false
                        } else {
                            // Zoom to 2.5x toward tap point
                            val targetScale = 2.5f
                            scale = targetScale
                            isZoomed = true
                            val centroidOffset = tapOffset - Offset(
                                containerSize.width  / 2f,
                                containerSize.height / 2f
                            )
                            offset = clampOffset(-centroidOffset * (targetScale - 1f), targetScale, containerSize)
                        }
                    },
                    onTap = { tapOffset ->
                        if (isZoomed) {
                            // While zoomed, taps toggle controls only
                            onTapCenter()
                            return@detectTapGestures
                        }
                        when {
                            tapOffset.x < tapZoneWidth                          -> onTapLeft()
                            tapOffset.x > containerSize.width - tapZoneWidth   -> onTapRight()
                            else                                                -> onTapCenter()
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX       = animatedScale,
                    scaleY       = animatedScale,
                    translationX = offset.x,
                    translationY = offset.y
                ),
            contentAlignment = Alignment.Center
        ) {
            content()
        }
    }
}

private fun clampOffset(offset: Offset, scale: Float, size: IntSize): Offset {
    if (size == IntSize.Zero) return offset
    val maxX = (size.width  * (scale - 1f) / 2f).coerceAtLeast(0f)
    val maxY = (size.height * (scale - 1f) / 2f).coerceAtLeast(0f)
    return Offset(
        x = offset.x.coerceIn(-maxX, maxX),
        y = offset.y.coerceIn(-maxY, maxY)
    )
}
