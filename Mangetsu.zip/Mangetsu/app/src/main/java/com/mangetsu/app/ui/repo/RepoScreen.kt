package com.mangetsu.app.ui.repo

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.data.extension.repo.InstallProgress
import com.mangetsu.data.extension.repo.RepoError

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepoScreen(
    onBack: () -> Unit = {},
    vm: RepoViewModel = hiltViewModel()
) {
    val state           by vm.uiState.collectAsStateWithLifecycle()
    val snackbarState    = remember { SnackbarHostState() }
    var showSearch by remember { mutableStateOf(false) }

    LaunchedEffect(state.snackMessage) {
        state.snackMessage?.let { snackbarState.showSnackbar(it); vm.clearSnack() }
    }

    if (state.addRepoDialogOpen) {
        AddRepoDialog(
            url        = state.repoUrlInput,
            isLoading  = state.addRepoLoading,
            onUrlChange = vm::onRepoUrlInput,
            onConfirm  = vm::confirmAddRepo,
            onDismiss  = vm::dismissAddRepoDialog
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarState) },
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        if (showSearch) {
                            OutlinedTextField(
                                value         = state.searchQuery,
                                onValueChange = vm::onSearchQuery,
                                placeholder   = { Text("Search extensions…") },
                                singleLine    = true,
                                modifier      = Modifier.fillMaxWidth()
                            )
                        } else {
                            Text("Extensions")
                        }
                    },
                    navigationIcon = {
                        if (showSearch) {
                            IconButton(onClick = { showSearch = false; vm.onSearchQuery("") }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close search")
                            }
                        }
                    },
                    actions = {
                        if (!showSearch) {
                            IconButton(onClick = { showSearch = true }) {
                                Icon(Icons.Filled.Search, "Search")
                            }
                        }
                        if (state.updateCount > 0) {
                            BadgedBox(badge = {
                                Badge { Text(state.updateCount.toString()) }
                            }) {
                                IconButton(onClick = { vm.selectTab(RepoTab.UPDATES) }) {
                                    Icon(Icons.Filled.SystemUpdate, "Updates")
                                }
                            }
                        }
                        IconButton(onClick = vm::refresh, enabled = !state.isRefreshing) {
                            if (state.isRefreshing) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.Refresh, "Refresh")
                            }
                        }
                    }
                )

                // Language filter row
                if (state.availableLangs.size > 1 && state.activeTab != RepoTab.REPOS) {
                    LazyRow(
                        modifier            = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = state.selectedLang == null,
                                onClick  = { vm.selectLang(null) },
                                label    = { Text("All") }
                            )
                        }
                        items(state.availableLangs) { lang ->
                            FilterChip(
                                selected = state.selectedLang == lang,
                                onClick  = { vm.selectLang(if (state.selectedLang == lang) null else lang) },
                                label    = { Text(lang.uppercase()) }
                            )
                        }
                    }
                }

                // Tabs
                ScrollableTabRow(selectedTabIndex = state.activeTab.ordinal, edgePadding = 8.dp) {
                    Tab(
                        selected = state.activeTab == RepoTab.EXTENSIONS,
                        onClick  = { vm.selectTab(RepoTab.EXTENSIONS) },
                        text     = { Text("All (${state.extensions.size})") }
                    )
                    Tab(
                        selected = state.activeTab == RepoTab.UPDATES,
                        onClick  = { vm.selectTab(RepoTab.UPDATES) },
                        text     = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Updates")
                                if (state.updateCount > 0) {
                                    Spacer(Modifier.width(4.dp))
                                    Box(
                                        Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary),
                                        Alignment.Center
                                    ) {
                                        Text(
                                            state.updateCount.toString(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimary
                                        )
                                    }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = state.activeTab == RepoTab.REPOS,
                        onClick  = { vm.selectTab(RepoTab.REPOS) },
                        text     = { Text("Repos (${state.repos.size})") }
                    )
                }
            }
        },
        floatingActionButton = {
            when (state.activeTab) {
                RepoTab.REPOS ->
                    FloatingActionButton(onClick = vm::openAddRepoDialog) {
                        Icon(Icons.Filled.Add, "Add repository")
                    }
                RepoTab.UPDATES ->
                    if (state.updateCount > 0) {
                        FloatingActionButton(onClick = vm::updateAll) {
                            Icon(Icons.Filled.SystemUpdate, "Update all")
                        }
                    }
                else -> Unit
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {

            // Repo errors banner
            if (state.errors.isNotEmpty()) {
                RepoeErrorsBanner(state.errors)
            }

            AnimatedContent(targetState = state.activeTab) { tab ->
                when (tab) {
                    RepoTab.EXTENSIONS, RepoTab.UPDATES -> ExtensionsList(
                        extensions      = state.filteredExtensions,
                        installProgress = state.installProgress,
                        onInstall       = vm::install,
                        showUpdateAll   = tab == RepoTab.UPDATES && state.updateCount > 0
                    )
                    RepoTab.REPOS -> ReposList(
                        repos       = state.repos,
                        cacheStats  = state.cacheStats,
                        onAdd       = vm::openAddRepoDialog,
                        onRemove    = vm::removeRepo,
                        onRefresh   = vm::refreshRepo
                    )
                }
            }
        }
    }
}

// ── Extensions list ───────────────────────────────────────────────────────────

@Composable
private fun ExtensionsList(
    extensions:      List<Extension>,
    installProgress: Map<String, InstallProgress>,
    onInstall:       (Extension) -> Unit,
    showUpdateAll:   Boolean
) {
    if (extensions.isEmpty()) {
        EmptyContent(
            icon    = Icons.Filled.Extension,
            title   = "No extensions found",
            subtitle = "Add a repository or adjust filters"
        )
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        items(extensions, key = { it.packageName }) { ext ->
            ExtensionRow(
                extension = ext,
                progress  = installProgress[ext.packageName],
                onInstall = { onInstall(ext) }
            )
        }
    }
}

@Composable
private fun ExtensionRow(
    extension: Extension,
    progress:  InstallProgress?,
    onInstall: () -> Unit
) {
    val isActive = progress?.isActive == true

    Card(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
        shape     = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.animateContentSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Icon
                SubcomposeAsyncImage(
                    model              = extension.iconUrl,
                    contentDescription = null,
                    contentScale       = ContentScale.Crop,
                    modifier           = Modifier.size(42.dp).clip(CircleShape),
                    error              = {
                        Box(Modifier.size(42.dp).clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                            Alignment.Center) {
                            Icon(Icons.Filled.Extension, null, modifier = Modifier.size(22.dp))
                        }
                    }
                )

                Spacer(Modifier.width(10.dp))

                // Name + meta
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            extension.name,
                            style    = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (extension.isNsfw) {
                            Spacer(Modifier.width(4.dp))
                            NsfwBadge()
                        }
                    }
                    Text(
                        "${extension.lang.uppercase()} • v${extension.versionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                    )
                    StatusChip(extension.status)
                }

                Spacer(Modifier.width(8.dp))

                // Action button
                when {
                    isActive -> CircularProgressIndicator(
                        modifier    = Modifier.size(28.dp),
                        strokeWidth = 2.5.dp
                    )
                    extension.status == ExtensionStatus.INSTALLED -> Unit
                    extension.status == ExtensionStatus.UPDATE_AVAILABLE ->
                        Button(onClick = onInstall) {
                            Icon(Icons.Filled.SystemUpdate, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Update")
                        }
                    extension.status == ExtensionStatus.AVAILABLE ->
                        OutlinedButton(onClick = onInstall) {
                            Icon(Icons.Filled.Download, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Install")
                        }
                    else -> Unit
                }
            }

            // Progress bar
            when (progress) {
                is InstallProgress.Downloading -> {
                    if (progress.percent >= 0) {
                        LinearProgressIndicator(
                            progress    = { progress.percent / 100f },
                            modifier    = Modifier.fillMaxWidth().height(3.dp),
                            color       = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(3.dp))
                    }
                }
                is InstallProgress.Retrying -> {
                    Surface(color = MaterialTheme.colorScheme.errorContainer) {
                        Text(
                            "Retrying (${progress.attempt}/${progress.max})…",
                            style    = MaterialTheme.typography.labelSmall,
                            color    = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
                is InstallProgress.Failed -> {
                    Surface(color = MaterialTheme.colorScheme.errorContainer) {
                        Text(
                            "Failed: ${progress.message}",
                            style    = MaterialTheme.typography.labelSmall,
                            color    = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
                else -> Unit
            }
        }
    }
}

// ── Repos list ────────────────────────────────────────────────────────────────

@Composable
private fun ReposList(
    repos:      List<ExtensionRepo>,
    cacheStats: com.mangetsu.data.extension.repo.RepoCacheStats?,
    onAdd:      () -> Unit,
    onRemove:   (Long) -> Unit,
    onRefresh:  (Long) -> Unit
) {
    if (repos.isEmpty()) {
        EmptyContent(
            icon     = Icons.Filled.Add,
            title    = "No repositories",
            subtitle = "Tap + to add a source repository"
        )
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        // Cache stats header
        cacheStats?.let { stats ->
            item {
                Surface(
                    color    = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    shape    = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${stats.repoCount} repos cached",
                            style = MaterialTheme.typography.labelSmall)
                        Text("${stats.totalSizeBytes / 1024} KB",
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        items(repos, key = { it.id }) { repo ->
            RepoRow(repo = repo, onRemove = { onRemove(repo.id) }, onRefresh = { onRefresh(repo.id) })
        }
    }
}

@Composable
private fun RepoRow(
    repo:      ExtensionRepo,
    onRemove:  () -> Unit,
    onRefresh: () -> Unit
) {
    var confirmDelete by remember { mutableStateOf(false) }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title  = { Text("Remove Repository") },
            text   = { Text("Remove '${repo.name}'? Installed extensions from this repo won't be affected.") },
            confirmButton = {
                Button(
                    onClick = { onRemove(); confirmDelete = false },
                    colors  = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
            }
        )
    }

    Card(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
        shape     = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text(repo.name, style = MaterialTheme.typography.titleSmall)
                Text(
                    repo.url,
                    style    = MaterialTheme.typography.bodySmall,
                    color    = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                repo.lastSynced?.let { ts ->
                    val age = System.currentTimeMillis() - ts
                    val label = when {
                        age < 3_600_000  -> "${age / 60_000}m ago"
                        age < 86_400_000 -> "${age / 3_600_000}h ago"
                        else             -> "${age / 86_400_000}d ago"
                    }
                    Text(
                        "Last synced $label",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }
            }
            Row {
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Filled.Refresh, "Refresh repo", modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Filled.Delete, "Remove repo",
                        tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// ── Add Repo Dialog ───────────────────────────────────────────────────────────

@Composable
private fun AddRepoDialog(
    url:        String,
    isLoading:  Boolean,
    onUrlChange: (String) -> Unit,
    onConfirm:  () -> Unit,
    onDismiss:  () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!isLoading) onDismiss() },
        title = { Text("Add Repository") },
        text = {
            Column {
                Text(
                    "Enter the base URL of the repository. The app will look for index.json at that path.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value         = url,
                    onValueChange = onUrlChange,
                    label         = { Text("Repository URL") },
                    placeholder   = { Text("https://example.com/extensions") },
                    singleLine    = true,
                    isError       = url.isNotBlank() && !url.startsWith("http"),
                    supportingText = {
                        if (url.isNotBlank() && !url.startsWith("http"))
                            Text("URL must start with https://", color = MaterialTheme.colorScheme.error)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick  = onConfirm,
                enabled  = url.isNotBlank() && url.startsWith("http") && !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Add")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isLoading) { Text("Cancel") }
        }
    )
}

// ── Errors banner ─────────────────────────────────────────────────────────────

@Composable
private fun RepoeErrorsBanner(errors: List<RepoError>) {
    Surface(
        color    = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null,
                    tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                Text(
                    " ${errors.size} repo(s) failed to refresh",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }
            errors.take(2).forEach { err ->
                Text(
                    "• ${err.repoUrl.take(40)}: ${err.message.take(60)}",
                    style    = MaterialTheme.typography.labelSmall,
                    color    = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
    }
}

// ── Shared small composables ──────────────────────────────────────────────────

@Composable
private fun NsfwBadge() {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(3.dp)
    ) {
        Text(
            "18+",
            style    = MaterialTheme.typography.labelSmall,
            color    = MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
        )
    }
}

@Composable
private fun StatusChip(status: ExtensionStatus) {
    val (label, color) = when (status) {
        ExtensionStatus.INSTALLED        -> "Installed"        to MaterialTheme.colorScheme.primary
        ExtensionStatus.UPDATE_AVAILABLE -> "Update available" to Color(0xFFFFA000)
        ExtensionStatus.AVAILABLE        -> "Available"        to MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
        ExtensionStatus.INSTALLING       -> "Installing…"      to MaterialTheme.colorScheme.tertiary
        ExtensionStatus.ERROR            -> "Error"            to MaterialTheme.colorScheme.error
    }
    Text(label, style = MaterialTheme.typography.labelSmall, color = color)
}

@Composable
private fun EmptyContent(
    icon:     androidx.compose.ui.graphics.vector.ImageVector,
    title:    String,
    subtitle: String
) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f))
            Spacer(Modifier.height(10.dp))
            Text(title,    style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }
    }
}
