package com.mangetsu.app.ui.repo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.data.extension.download.DownloadState
import com.mangetsu.data.extension.repo.AddRepoResult
import com.mangetsu.data.extension.repo.InstallProgress
import com.mangetsu.data.extension.repo.RepoCacheStats
import com.mangetsu.data.extension.repo.RepoError
import com.mangetsu.data.extension.repo.RepoManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── UI state ──────────────────────────────────────────────────────────────────

data class RepoUiState(
    // Tab
    val activeTab:         RepoTab              = RepoTab.EXTENSIONS,

    // Content
    val repos:             List<ExtensionRepo>  = emptyList(),
    val extensions:        List<Extension>      = emptyList(),
    val filteredExtensions: List<Extension>     = emptyList(),

    // Counts
    val updateCount:       Int                  = 0,
    val installedCount:    Int                  = 0,
    val availableCount:    Int                  = 0,

    // Filters
    val searchQuery:       String               = "",
    val selectedLang:      String?              = null,
    val showNsfw:          Boolean              = false,
    val filterStatus:      ExtensionStatus?     = null,

    // Install progress keyed by packageName
    val installProgress:   Map<String, InstallProgress> = emptyMap(),

    // Repo management dialog
    val addRepoDialogOpen: Boolean              = false,
    val repoUrlInput:      String               = "",
    val addRepoLoading:    Boolean              = false,

    // Feedback
    val isRefreshing:      Boolean              = false,
    val errors:            List<RepoError>      = emptyList(),
    val snackMessage:      String?              = null,
    val cacheStats:        RepoCacheStats?      = null,

    // Available language filters derived from extension list
    val availableLangs:    List<String>         = emptyList()
)

enum class RepoTab { EXTENSIONS, UPDATES, REPOS }

// ── ViewModel ─────────────────────────────────────────────────────────────────

@HiltViewModel
class RepoViewModel @Inject constructor(
    private val repoManager: RepoManager
) : ViewModel() {

    private val _extra = MutableStateFlow(RepoUiState())

    val uiState: StateFlow<RepoUiState> = combine(
        repoManager.state,
        repoManager.installProgress,
        _extra
    ) { repoState, progress, extra ->

        val allExtensions = repoState.extensions
        val langs = allExtensions.map { it.lang }.distinct().sorted()

        val filtered = applyFilters(
            extensions   = allExtensions,
            query        = extra.searchQuery,
            lang         = extra.selectedLang,
            showNsfw     = extra.showNsfw,
            filterStatus = extra.filterStatus,
            tab          = extra.activeTab
        )

        extra.copy(
            repos              = repoState.repos,
            extensions         = allExtensions,
            filteredExtensions = filtered,
            updateCount        = repoState.updateCount,
            installedCount     = allExtensions.count { it.status == ExtensionStatus.INSTALLED },
            availableCount     = allExtensions.count { it.status == ExtensionStatus.AVAILABLE },
            installProgress    = progress,
            isRefreshing       = repoState.isRefreshing,
            errors             = repoState.errors,
            cacheStats         = repoState.cacheStats,
            availableLangs     = langs
        )
    }.stateIn(
        scope        = viewModelScope,
        started      = SharingStarted.WhileSubscribed(5_000),
        initialValue = RepoUiState(isRefreshing = true)
    )

    init {
        // Initial load on cold start
        viewModelScope.launch { repoManager.refreshAll(forceRefresh = false) }
    }

    // ── Tab ───────────────────────────────────────────────────────────────────

    fun selectTab(tab: RepoTab) {
        _extra.update { it.copy(activeTab = tab, filterStatus = tab.defaultFilter()) }
    }

    // ── Filters ───────────────────────────────────────────────────────────────

    fun onSearchQuery(query: String) = _extra.update { it.copy(searchQuery = query) }
    fun selectLang(lang: String?)    = _extra.update { it.copy(selectedLang = lang) }
    fun toggleNsfw()                 = _extra.update { it.copy(showNsfw = !it.showNsfw) }
    fun setStatusFilter(s: ExtensionStatus?) = _extra.update { it.copy(filterStatus = s) }

    // ── Refresh ───────────────────────────────────────────────────────────────

    fun refresh() {
        viewModelScope.launch { repoManager.refreshAll(forceRefresh = true) }
    }

    // ── Install / Update ──────────────────────────────────────────────────────

    fun install(extension: Extension) {
        viewModelScope.launch { repoManager.installExtension(extension) }
    }

    fun updateAll() {
        viewModelScope.launch {
            repoManager.updateAll()
            _extra.update { it.copy(snackMessage = "Updating all extensions…") }
        }
    }

    // ── Repo dialog ───────────────────────────────────────────────────────────

    fun openAddRepoDialog() = _extra.update {
        it.copy(addRepoDialogOpen = true, repoUrlInput = "")
    }

    fun dismissAddRepoDialog() = _extra.update { it.copy(addRepoDialogOpen = false) }

    fun onRepoUrlInput(url: String) = _extra.update { it.copy(repoUrlInput = url) }

    fun confirmAddRepo() {
        val url = _extra.value.repoUrlInput.trim()
        if (url.isBlank()) return

        viewModelScope.launch {
            _extra.update { it.copy(addRepoLoading = true, addRepoDialogOpen = false) }

            when (val result = repoManager.addRepo(url)) {
                is AddRepoResult.Success -> _extra.update {
                    it.copy(
                        addRepoLoading = false,
                        snackMessage   = "Added '${result.repo.name}' (${result.entries} extensions)"
                    )
                }
                is AddRepoResult.InvalidUrl -> _extra.update {
                    it.copy(
                        addRepoLoading = false,
                        addRepoDialogOpen = true,
                        snackMessage   = "Invalid URL: ${result.reason}"
                    )
                }
                is AddRepoResult.FetchFailed -> _extra.update {
                    it.copy(
                        addRepoLoading = false,
                        addRepoDialogOpen = true,
                        snackMessage   = "Could not fetch repo: ${result.message}"
                    )
                }
                AddRepoResult.AlreadyExists -> _extra.update {
                    it.copy(
                        addRepoLoading = false,
                        snackMessage   = "Repository already added"
                    )
                }
            }
        }
    }

    fun removeRepo(repoId: Long) {
        viewModelScope.launch {
            repoManager.removeRepo(repoId)
            _extra.update { it.copy(snackMessage = "Repository removed") }
        }
    }

    fun refreshRepo(repoId: Long) {
        viewModelScope.launch { repoManager.refreshSingle(repoId, forceRefresh = true) }
    }

    fun clearSnack() = _extra.update { it.copy(snackMessage = null) }

    // ── Filter logic ──────────────────────────────────────────────────────────

    private fun applyFilters(
        extensions:   List<Extension>,
        query:        String,
        lang:         String?,
        showNsfw:     Boolean,
        filterStatus: ExtensionStatus?,
        tab:          RepoTab
    ): List<Extension> {
        return extensions
            .filter { ext ->
                // Tab filter takes precedence when set
                val tabFilter = tab.defaultFilter()
                tabFilter == null || ext.status == tabFilter
            }
            .filter { ext ->
                filterStatus == null || ext.status == filterStatus
            }
            .filter { ext ->
                !ext.isNsfw || showNsfw
            }
            .filter { ext ->
                lang == null || ext.lang.equals(lang, ignoreCase = true)
            }
            .filter { ext ->
                query.isBlank() ||
                    ext.name.contains(query, ignoreCase = true) ||
                    ext.lang.contains(query, ignoreCase = true) ||
                    ext.packageName.contains(query, ignoreCase = true)
            }
    }

    private fun RepoTab.defaultFilter(): ExtensionStatus? = when (this) {
        RepoTab.UPDATES    -> ExtensionStatus.UPDATE_AVAILABLE
        RepoTab.EXTENSIONS -> null
        RepoTab.REPOS      -> null
    }
}
