package com.mangetsu.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// ── Brand colors ──────────────────────────────────────────────────────────────
object MangetsuColors {
    val Violet900  = Color(0xFF1A0550)
    val Violet800  = Color(0xFF2D0E7C)
    val Violet700  = Color(0xFF3D1AA8)
    val Violet600  = Color(0xFF4B35C4)
    val Violet500  = Color(0xFF6251E8)
    val Violet400  = Color(0xFF8578F0)
    val Violet300  = Color(0xFFA89FF5)
    val Violet200  = Color(0xFFC9C4FA)
    val Violet100  = Color(0xFFE4E1FD)
    val Violet50   = Color(0xFFF3F1FF)
    val Coral500   = Color(0xFFFF5757)
    val Coral400   = Color(0xFFFF7878)
    val Surface0   = Color(0xFF0F0F14)
    val Surface1   = Color(0xFF16161E)
    val Surface2   = Color(0xFF1E1E2A)
    val Surface3   = Color(0xFF252533)
    val Surface4   = Color(0xFF2E2E3D)
    val OnSurface  = Color(0xFFE8E6F0)
    val OnSurface2 = Color(0xFFB0AEBC)
    val OnSurface3 = Color(0xFF7A7888)
    val Success    = Color(0xFF4CAF50)
    val Warning    = Color(0xFFFFC107)
    val Error      = Color(0xFFFF5757)
}

private val DarkColorScheme = darkColorScheme(
    primary            = MangetsuColors.Violet400,
    onPrimary          = MangetsuColors.Violet900,
    primaryContainer   = MangetsuColors.Violet700,
    onPrimaryContainer = MangetsuColors.Violet100,
    secondary          = Color(0xFFCAC4D0),
    onSecondary        = Color(0xFF332D41),
    secondaryContainer = Color(0xFF4A4458),
    onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary           = MangetsuColors.Coral400,
    onTertiary         = Color(0xFF7C2D2D),
    background         = MangetsuColors.Surface0,
    onBackground       = MangetsuColors.OnSurface,
    surface            = MangetsuColors.Surface1,
    onSurface          = MangetsuColors.OnSurface,
    surfaceVariant     = MangetsuColors.Surface3,
    onSurfaceVariant   = MangetsuColors.OnSurface2,
    outline            = MangetsuColors.OnSurface3,
    outlineVariant     = MangetsuColors.Surface4,
    error              = MangetsuColors.Error,
    onError            = Color.White,
    errorContainer     = Color(0xFF4D1515),
    onErrorContainer   = Color(0xFFFFDAD6),
    inverseSurface     = MangetsuColors.OnSurface,
    inverseOnSurface   = MangetsuColors.Surface1,
    inversePrimary     = MangetsuColors.Violet600,
    surfaceTint        = MangetsuColors.Violet400
)

private val LightColorScheme = lightColorScheme(
    primary            = MangetsuColors.Violet600,
    onPrimary          = Color.White,
    primaryContainer   = MangetsuColors.Violet100,
    onPrimaryContainer = MangetsuColors.Violet900,
    secondary          = Color(0xFF625B71),
    onSecondary        = Color.White,
    secondaryContainer = Color(0xFFE8DEF8),
    onSecondaryContainer = Color(0xFF1E192B),
    tertiary           = MangetsuColors.Coral500,
    onTertiary         = Color.White,
    background         = Color(0xFFFBF8FF),
    onBackground       = Color(0xFF1B1B1F),
    surface            = Color(0xFFFBF8FF),
    onSurface          = Color(0xFF1B1B1F),
    surfaceVariant     = Color(0xFFE7E0EC),
    onSurfaceVariant   = Color(0xFF49454F),
    outline            = Color(0xFF79747E),
    outlineVariant     = Color(0xFFCAC4D0),
    error              = Color(0xFFB3261E),
    onError            = Color.White,
    errorContainer     = Color(0xFFF9DEDC),
    onErrorContainer   = Color(0xFF410E0B),
    inverseSurface     = Color(0xFF313033),
    inverseOnSurface   = Color(0xFFF4EFF4),
    inversePrimary     = MangetsuColors.Violet300,
    surfaceTint        = MangetsuColors.Violet600
)

val MangetsuTypography = Typography(
    displayLarge  = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 57.sp, lineHeight = 64.sp, letterSpacing = (-0.25).sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 32.sp, lineHeight = 40.sp),
    headlineMedium= TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 28.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge    = TextStyle(fontWeight = FontWeight.Bold,     fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium   = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.15.sp),
    titleSmall    = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    bodyLarge     = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.5.sp),
    bodyMedium    = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.25.sp),
    bodySmall     = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp),
    labelLarge    = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    labelMedium   = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp),
    labelSmall    = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp),
)

object Spacing {
    val xs   = 4.dp
    val sm   = 8.dp
    val md   = 12.dp
    val lg   = 16.dp
    val xl   = 20.dp
    val xxl  = 24.dp
    val xxxl = 32.dp
}

data class MangetsuExtendedColors(
    val success:     Color,
    val warning:     Color,
    val unreadBadge: Color,
    val coverScrim:  Color,
    val shimmer:     Color,
    val onlineGreen: Color
)

val LocalExtendedColors = staticCompositionLocalOf {
    MangetsuExtendedColors(
        success     = MangetsuColors.Success,
        warning     = MangetsuColors.Warning,
        unreadBadge = MangetsuColors.Violet600,
        coverScrim  = Color.Black.copy(alpha = 0.55f),
        shimmer     = Color.White.copy(alpha = 0.08f),
        onlineGreen = Color(0xFF4CAF50)
    )
}

val MaterialTheme.extended: MangetsuExtendedColors
    @Composable get() = LocalExtendedColors.current

@Composable
fun MangetsuTheme(
    darkTheme:    Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content:      @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        darkTheme -> DarkColorScheme
        else      -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor     = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars     = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalExtendedColors provides MangetsuExtendedColors(
            success     = MangetsuColors.Success,
            warning     = MangetsuColors.Warning,
            unreadBadge = if (darkTheme) MangetsuColors.Violet400 else MangetsuColors.Violet600,
            coverScrim  = Color.Black.copy(alpha = 0.55f),
            shimmer     = if (darkTheme) Color.White.copy(alpha = 0.08f) else Color.Black.copy(0.06f),
            onlineGreen = MangetsuColors.Success
        )
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = MangetsuTypography,
            content     = content
        )
    }
}
