package com.mangetsu.app.ui.updates

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.mangetsu.core.model.LibraryUpdateStatus
import com.mangetsu.core.model.MangaUpdate
import com.mangetsu.core.model.UpdateCheckState
import com.mangetsu.data.updates.LibraryUpdateService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── ViewModel ─────────────────────────────────────────────────────────────────

data class UpdatesUiState(
    val updates:      List<MangaUpdate>   = emptyList(),
    val status:       LibraryUpdateStatus = LibraryUpdateStatus(),
    val isRefreshing: Boolean             = false
)

@HiltViewModel
class UpdatesViewModel @Inject constructor(
    private val updateService: LibraryUpdateService
) : ViewModel() {

    val uiState: StateFlow<UpdatesUiState> = combine(
        updateService.updates,
        updateService.status
    ) { updates, status ->
        UpdatesUiState(
            updates      = updates.sortedByDescending { it.dateFetch },
            status       = status,
            isRefreshing = status.state == UpdateCheckState.RUNNING
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UpdatesUiState())

    fun checkForUpdates() {
        viewModelScope.launch { updateService.checkAll(force = true) }
    }
}

// ── Screen ────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdatesScreen(
    onMangaClick: (Long) -> Unit,
    vm: UpdatesViewModel = hiltViewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Updates") },
            actions = {
                IconButton(
                    onClick  = vm::checkForUpdates,
                    enabled  = !state.isRefreshing
                ) {
                    if (state.isRefreshing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.Refresh, "Check for updates")
                    }
                }
            }
        )

        if (state.isRefreshing) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                LinearProgressIndicator(
                    progress = { state.status.progress },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Checking ${state.status.current}/${state.status.total}…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        if (state.updates.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.NewReleases, null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f))
                    Spacer(Modifier.height(12.dp))
                    Text("No updates yet", style = MaterialTheme.typography.titleMedium)
                    Text("Tap refresh to check your library",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.updates, key = { "${it.mangaId}_${it.chapterName}" }) { update ->
                    UpdateItem(update = update, onClick = { onMangaClick(update.mangaId) })
                }
            }
        }
    }
}

@Composable
private fun UpdateItem(update: MangaUpdate, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model              = update.thumbnailUrl,
                contentDescription = null,
                contentScale       = ContentScale.Crop,
                modifier           = Modifier
                    .size(width = 48.dp, height = 68.dp)
                    .clip(RoundedCornerShape(6.dp))
            )
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(update.mangaTitle,
                    style    = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
                Text(update.chapterName,
                    style    = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color    = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
            // NEW badge
            Card(
                containerColor = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(4.dp)
            ) {
                Text("NEW",
                    style    = MaterialTheme.typography.labelSmall,
                    color    = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
    }
}

// Workaround: Card composable overload for containerColor
@Composable
private fun Card(
    containerColor: androidx.compose.ui.graphics.Color,
    shape: androidx.compose.foundation.shape.RoundedCornerShape,
    content: @Composable () -> Unit
) {
    Surface(color = containerColor, shape = shape, content = content)
}
