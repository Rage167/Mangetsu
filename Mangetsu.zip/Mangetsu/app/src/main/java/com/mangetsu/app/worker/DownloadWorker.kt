package com.mangetsu.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.data.repository.DownloadRepositoryImpl
import com.mangetsu.domain.repository.ChapterRepository
import com.mangetsu.domain.repository.LibraryRepository
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SPage
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import timber.log.Timber
import java.io.File
import java.net.URL

@HiltWorker
class DownloadWorker @AssistedInject constructor(
    @Assisted private val context:    Context,
    @Assisted private val params:     WorkerParameters,
    private val extRepository:        ExtensionRepositoryImpl,
    private val chapterRepository:    ChapterRepository,
    private val libraryRepository:    LibraryRepository
) : CoroutineWorker(context, params) {

    companion object {
        private const val NOTIFICATION_ID      = 1001
        private const val NOTIFICATION_CHANNEL = "mangetsu_download"
    }

    override suspend fun doWork(): Result {
        val mangaId   = inputData.getLong(DownloadRepositoryImpl.KEY_MANGA_ID,   -1L)
        val chapterId = inputData.getLong(DownloadRepositoryImpl.KEY_CHAPTER_ID, -1L)

        if (mangaId < 0 || chapterId < 0) {
            Timber.e("DownloadWorker: invalid IDs manga=$mangaId chapter=$chapterId")
            return Result.failure()
        }

        val manga   = libraryRepository.getMangaByIdOrNull(mangaId)
            ?: return Result.failure()
        val chapter = chapterRepository.getChapterById(chapterId)
            ?: return Result.failure()

        setForeground(buildForegroundInfo(manga.title, chapter.name))

        return try {
            val sChapter = SChapter(
                id            = chapter.url,
                url           = chapter.url,
                name          = chapter.name,
                chapterNumber = chapter.chapterNumber
            )

            val pages = when (val r = extRepository.safePageList(chapter.sourceId, sChapter)) {
                is ExtensionResult.Success -> r.data
                is ExtensionResult.Error   -> {
                    Timber.e("DownloadWorker: safePageList failed: ${r.message}")
                    return Result.retry()
                }
            }

            val outDir = File(context.filesDir, "downloads/$mangaId/$chapterId")
            outDir.mkdirs()

            pages.forEachIndexed { index, page ->
                val sPage = SPage(index = page.index, url = page.url, imageUrl = page.imageUrl)
                val resolvedPage = when (val r = extRepository.safePageImageUrl(chapter.sourceId, sPage)) {
                    is ExtensionResult.Success -> r.data
                    is ExtensionResult.Error   -> {
                        Timber.w("DownloadWorker: failed to resolve page $index: ${r.message}")
                        return@forEachIndexed
                    }
                }

                val imageUrl = resolvedPage.imageUrl ?: resolvedPage.url
                if (imageUrl.isBlank()) return@forEachIndexed

                val outFile = File(outDir, "${index.toString().padStart(4, '0')}.jpg")
                if (!outFile.exists()) {
                    try {
                        URL(imageUrl).openStream().use { input ->
                            outFile.outputStream().use { output -> input.copyTo(output) }
                        }
                    } catch (e: Exception) {
                        Timber.w(e, "DownloadWorker: failed to download page $index")
                    }
                }
            }

            val pageCount = outDir.listFiles()?.count { it.extension == "jpg" } ?: 0
            chapterRepository.updateDownloadStatus(chapterId, downloaded = pageCount > 0, pageCount = pageCount)

            Timber.i("DownloadWorker: ✅ manga=$mangaId chapter=$chapterId pages=$pageCount")
            Result.success()
        } catch (e: Exception) {
            Timber.e(e, "DownloadWorker: unexpected error")
            Result.retry()
        }
    }

    private fun buildForegroundInfo(mangaTitle: String, chapterName: String): ForegroundInfo {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL, "Downloads",
                NotificationManager.IMPORTANCE_LOW
            )
            context.getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(mangaTitle)
            .setContentText(chapterName)
            .setOngoing(true)
            .setSilent(true)
            .build()
        return ForegroundInfo(NOTIFICATION_ID, notification)
    }
}
