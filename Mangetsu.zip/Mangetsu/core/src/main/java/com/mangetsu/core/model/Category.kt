package com.mangetsu.core.model

data class Category(
    val id:           Long    = 0L,
    val name:         String,
    val sortOrder:    Int     = 0,
    val sortMode:     LibrarySortMode = LibrarySortMode.ALPHABETICAL,
    val sortAscending: Boolean = true,
    val isDefault:    Boolean = false,
    val mangaCount:   Int     = 0
)

enum class LibrarySortMode(val label: String) {
    ALPHABETICAL("Title"),
    LAST_READ("Last read"),
    LAST_ADDED("Date added"),
    UNREAD_COUNT("Unread count"),
    TOTAL_CHAPTERS("Total chapters"),
    LAST_UPDATED("Last updated")
}

data class LibraryFilter(
    val categoryId:    Long?   = null,
    val sortMode:      LibrarySortMode = LibrarySortMode.ALPHABETICAL,
    val sortAscending: Boolean = true,
    val searchQuery:   String  = "",
    val showUnreadOnly: Boolean = false,
    val showDownloadedOnly: Boolean = false
)
