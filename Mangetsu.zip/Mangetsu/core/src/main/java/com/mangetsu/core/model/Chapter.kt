package com.mangetsu.core.model

/**
 * Domain model for a manga chapter.
 */
data class Chapter(
    val id: Long = 0L,
    val mangaId: Long,
    val sourceId: Long,
    val url: String,
    val name: String,
    val chapterNumber: Float = -1f,
    val volumeNumber: Float? = null,
    val dateUpload: Long = 0L,
    val scanlator: String? = null,
    val read: Boolean = false,
    val lastPageRead: Int = 0,
    val downloaded: Boolean = false,
    val pageCount: Int = 0,
    val sourceOrder: Int = 0
)
