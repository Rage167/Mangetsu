package com.mangetsu.core.model

/**
 * Domain model representing an extension's state as known by the app.
 */
data class Extension(
    val packageName: String,
    val name: String,
    val versionName: String,
    val versionCode: Int,
    val lang: String,
    val apkUrl: String,
    val iconUrl: String? = null,
    val sourceId: Long,
    val isNsfw: Boolean = false,
    val status: ExtensionStatus = ExtensionStatus.AVAILABLE
)

enum class ExtensionStatus {
    /** Listed in a repo but not installed. */
    AVAILABLE,
    /** Currently being downloaded/installed. */
    INSTALLING,
    /** Installed and active. */
    INSTALLED,
    /** A newer version is available in the repo. */
    UPDATE_AVAILABLE,
    /** Installed but the APK cannot be loaded (class not found, ABI mismatch, etc.). */
    ERROR
}
