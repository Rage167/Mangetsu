package com.mangetsu.core.model

/**
 * Represents a user-added extension repository (analogous to a package manager repo).
 */
data class ExtensionRepo(
    val id: Long = 0L,
    val name: String,
    val url: String,
    val description: String? = null,
    val addedAt: Long = System.currentTimeMillis(),
    val lastSynced: Long? = null
)
