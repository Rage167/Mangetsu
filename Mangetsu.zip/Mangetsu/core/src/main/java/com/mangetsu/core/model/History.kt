package com.mangetsu.core.model

/**
 * Tracks the last time a user read a chapter of a given manga.
 */
data class History(
    val id: Long = 0L,
    val mangaId: Long,
    val chapterId: Long,
    val mangaTitle: String,
    val chapterName: String,
    val thumbnailUrl: String? = null,
    val lastRead: Long = System.currentTimeMillis(),
    val lastPageRead: Int = 0
)

/**
 * Represents a queued or completed chapter download.
 */
data class Download(
    val mangaId: Long,
    val chapterId: Long,
    val mangaTitle: String,
    val chapterName: String,
    val sourceId: Long,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val progress: Int = 0,          // 0–100
    val totalPages: Int = 0,
    val downloadedPages: Int = 0,
    val error: String? = null
)

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    COMPLETED,
    ERROR,
    PAUSED
}
