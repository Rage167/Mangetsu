package com.mangetsu.core.model

import com.mangetsu.extensionapi.model.MangaStatus

/**
 * Domain model representing a manga entry in the user's library or browse results.
 * Decoupled from both the DB entity and the extension SManga.
 */
data class Manga(
    val id:           Long          = 0L,
    val sourceId:     Long,
    val url:          String,
    val title:        String,
    val thumbnailUrl: String?       = null,
    val author:       String?       = null,
    val artist:       String?       = null,
    val description:  String?       = null,
    val genre:        List<String>  = emptyList(),
    val status:       MangaStatus   = MangaStatus.UNKNOWN,
    val inLibrary:    Boolean       = false,
    val favorite:     Boolean       = false,
    val dateAdded:    Long          = 0L,
    val lastUpdated:  Long          = 0L,
    val unreadCount:  Int           = 0,
    val downloadCount: Int          = 0,
    /** True once full details (description, genres, status) have been fetched from source. */
    val initialized:  Boolean       = false
) {
    val genreString: String get() = genre.joinToString(", ")
}
