package com.mangetsu.core.model

data class MangaUpdate(
    val mangaId:       Long,
    val mangaTitle:    String,
    val thumbnailUrl:  String?,
    val chapterId:     Long,
    val chapterName:   String,
    val chapterNumber: Float,
    val dateFetch:     Long,
    val sourceId:      Long
)

data class UpdatesResult(
    val mangaId:      Long,
    val newChapters:  Int,
    val error:        String?    = null
)

enum class UpdateCheckState {
    IDLE,
    RUNNING,
    COMPLETED,
    ERROR
}

data class LibraryUpdateStatus(
    val state:         UpdateCheckState = UpdateCheckState.IDLE,
    val current:       Int              = 0,
    val total:         Int              = 0,
    val newUpdates:    Int              = 0,
    val errors:        List<String>     = emptyList(),
    val currentTitle:  String           = ""
) {
    val progress: Float get() = if (total > 0) current.toFloat() / total else 0f
}
