package com.mangetsu.core.model

enum class ReadingMode(val label: String) {
    HORIZONTAL_LTR("Left to Right"),
    HORIZONTAL_RTL("Right to Left"),
    VERTICAL("Vertical"),
    WEBTOON("Webtoon (continuous)")
}

data class ReaderSettings(
    val readingMode:     ReadingMode = ReadingMode.VERTICAL,
    val brightness:      Float       = -1f,
    val pageSpacingDp:   Int         = 8,
    val scaleToFit:      Boolean     = true,
    val showPageNumbers: Boolean     = true,
    val keepScreenOn:    Boolean     = true,
    val cropBorders:     Boolean     = false,
    val maxScaleFactor:  Float       = 5f
)
