package com.mangetsu.core.model

/**
 * Represents a tracking service (MAL, AniList, Kitsu, MangaUpdates, etc.)
 * All tracker implementations must produce/consume these models.
 */
data class Tracker(
    val id:          String,
    val name:        String,
    val logoUrl:     String?  = null,
    val isLoggedIn:  Boolean  = false,
    val username:    String?  = null
)

data class TrackSearch(
    val remoteId:      Long,
    val trackerId:     String,
    val title:         String,
    val coverUrl:      String?,
    val summary:       String?,
    val score:         Float,
    val status:        TrackStatus,
    val totalChapters: Int,
    val url:           String
)

data class TrackRecord(
    val mangaId:       Long,
    val trackerId:     String,
    val remoteId:      Long,
    val remoteUrl:     String,
    val title:         String,
    val score:         Float        = 0f,
    val status:        TrackStatus  = TrackStatus.READING,
    val chaptersRead:  Int          = 0,
    val totalChapters: Int          = 0,
    val startDate:     Long         = 0L,
    val finishDate:    Long         = 0L,
    val lastSynced:    Long         = 0L
)

enum class TrackStatus(val value: Int, val label: String) {
    READING(1,       "Reading"),
    COMPLETED(2,     "Completed"),
    ON_HOLD(3,       "On Hold"),
    DROPPED(4,       "Dropped"),
    PLAN_TO_READ(5,  "Plan to Read"),
    REREADING(6,     "Re-reading");

    companion object {
        fun fromValue(v: Int) = entries.firstOrNull { it.value == v } ?: READING
    }
}

/** Result of a tracking operation */
sealed class TrackResult<out T> {
    data class Success<T>(val data: T) : TrackResult<T>()
    data class Error(val message: String, val cause: Throwable? = null) : TrackResult<Nothing>()
    data object NotLoggedIn : TrackResult<Nothing>()
}
