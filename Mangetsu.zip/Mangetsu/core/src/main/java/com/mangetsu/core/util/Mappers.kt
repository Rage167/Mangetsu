package com.mangetsu.core.util

import com.mangetsu.core.model.Chapter
import com.mangetsu.core.model.Manga
import com.mangetsu.extensionapi.model.MangaStatus
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga

// ── SManga → Manga ────────────────────────────────────────────────────────────

fun SManga.toDomainManga(sourceId: Long): Manga = Manga(
    sourceId     = sourceId,
    url          = url,
    title        = title,
    thumbnailUrl = thumbnailUrl,
    author       = author,
    artist       = artist,
    description  = description,
    genre        = genre?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList(),
    status       = status,
    initialized  = initialized
)

// ── SChapter → Chapter ────────────────────────────────────────────────────────

fun SChapter.toDomainChapter(mangaId: Long, sourceId: Long, sourceOrder: Int = 0): Chapter =
    Chapter(
        mangaId       = mangaId,
        sourceId      = sourceId,
        url           = url,
        name          = name,
        chapterNumber = chapterNumber,
        volumeNumber  = volumeNumber,
        dateUpload    = dateUpload,
        scanlator     = scanlator,
        sourceOrder   = sourceOrder
    )

// ── Formatting helpers ────────────────────────────────────────────────────────

fun Long.toRelativeTimeString(): String {
    val delta = System.currentTimeMillis() - this
    return when {
        delta < 60_000L           -> "just now"
        delta < 3_600_000L        -> "${delta / 60_000}m ago"
        delta < 86_400_000L       -> "${delta / 3_600_000}h ago"
        delta < 2_592_000_000L    -> "${delta / 86_400_000}d ago"
        else                      -> "${delta / 2_592_000_000L}mo ago"
    }
}

fun MangaStatus.displayName(): String = when (this) {
    MangaStatus.UNKNOWN             -> "Unknown"
    MangaStatus.ONGOING             -> "Ongoing"
    MangaStatus.COMPLETED           -> "Completed"
    MangaStatus.LICENSED            -> "Licensed"
    MangaStatus.PUBLISHING_FINISHED -> "Finished"
    MangaStatus.CANCELLED           -> "Cancelled"
    MangaStatus.ON_HIATUS           -> "On Hiatus"
}
