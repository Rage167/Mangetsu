package com.mangetsu.core.util

/**
 * A discriminated union that encapsulates success or failure of an operation.
 *
 * Usage:
 * ```kotlin
 * when (val result = useCase()) {
 *     is Result.Success -> render(result.data)
 *     is Result.Error   -> showError(result.exception.message)
 *     is Result.Loading -> showSpinner()
 * }
 * ```
 */
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val exception: Throwable, val message: String? = exception.message) : Result<Nothing>()
    data object Loading : Result<Nothing>()

    val isSuccess get() = this is Success
    val isError   get() = this is Error
    val isLoading get() = this is Loading

    fun getOrNull(): T? = (this as? Success)?.data

    fun getOrThrow(): T = when (this) {
        is Success -> data
        is Error   -> throw exception
        is Loading -> error("Result is still Loading")
    }

    fun <R> map(transform: (T) -> R): Result<R> = when (this) {
        is Success -> Success(transform(data))
        is Error   -> this
        is Loading -> this
    }
}

/** Wraps a suspending block in a [Result], catching any [Throwable]. */
suspend fun <T> safeCall(block: suspend () -> T): Result<T> = try {
    Result.Success(block())
} catch (e: Throwable) {
    Result.Error(e)
}
