package com.mangetsu.data.backup

import android.content.Context
import android.net.Uri
import com.mangetsu.core.model.ReaderSettings
import com.mangetsu.core.model.ReadingMode
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.entity.CategoryEntity
import com.mangetsu.data.database.entity.ExtensionRepoEntity
import com.mangetsu.data.database.entity.HistoryEntity
import com.mangetsu.data.database.entity.MangaCategoryEntity
import com.mangetsu.data.database.entity.MangaEntity
import com.mangetsu.data.database.entity.MangaTrackingEntity
import com.mangetsu.data.reader.ReaderSettingsRepository
import com.mangetsu.domain.repository.BackupRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

sealed class BackupResult {
    data class Success(val uri: Uri, val stats: BackupStats) : BackupResult()
    data class Failure(val message: String, val cause: Throwable? = null) : BackupResult()
}

data class BackupStats(
    val mangaCount:    Int,
    val chapterCount:  Int,
    val historyCount:  Int,
    val categoryCount: Int,
    val trackingCount: Int,
    val repoCount:     Int,
    val fileSizeBytes: Long
)

sealed class RestoreResult {
    data class Success(val stats: RestoreStats) : RestoreResult()
    data class ValidationError(val errors: List<String>) : RestoreResult()
    data class Failure(val message: String, val cause: Throwable? = null) : RestoreResult()
}

data class RestoreStats(
    val mangaRestored:    Int,
    val chaptersRestored: Int,
    val historyRestored:  Int,
    val categoriesRestored: Int,
    val trackingRestored: Int,
    val reposRestored:    Int,
    val mode:             RestoreMode
)

enum class RestoreMode { MERGE, OVERWRITE }

@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val db:               MangetsuDatabase,
    private val serializer:       BackupSerializer,
    private val validator:        BackupValidator,
    private val settingsRepo:     ReaderSettingsRepository
) : BackupRepository {

    // ── Create ────────────────────────────────────────────────────────────────

    override suspend fun createBackup(): ByteArray = withContext(Dispatchers.IO) {
        val envelope = buildEnvelope()
        serializer.toJson(envelope)
    }

    /**
     * Creates a backup and writes it directly to [uri] using the Storage Access Framework.
     * Returns [BackupResult.Success] with stats on success.
     */
    suspend fun createBackupToUri(uri: Uri, pretty: Boolean = false): BackupResult =
        withContext(Dispatchers.IO) {
            try {
                val envelope = buildEnvelope()
                val bytes    = if (pretty) serializer.toJsonPretty(envelope)
                               else serializer.toJson(envelope)

                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(bytes)
                } ?: return@withContext BackupResult.Failure("Could not open output stream for $uri")

                val stats = BackupStats(
                    mangaCount    = envelope.manga.size,
                    chapterCount  = envelope.chapters.size,
                    historyCount  = envelope.history.size,
                    categoryCount = envelope.categories.size,
                    trackingCount = envelope.tracking.size,
                    repoCount     = envelope.repos.size,
                    fileSizeBytes = bytes.size.toLong()
                )
                Timber.i("BackupManager: backup written to $uri (${bytes.size} bytes)")
                BackupResult.Success(uri, stats)

            } catch (e: Exception) {
                Timber.e(e, "BackupManager: createBackupToUri failed")
                BackupResult.Failure("Failed to write backup: ${e.message}", e)
            }
        }

    // ── Restore ───────────────────────────────────────────────────────────────

    override suspend fun restoreBackup(data: ByteArray): Unit = withContext(Dispatchers.IO) {
        when (val r = restoreFromBytes(data, RestoreMode.MERGE)) {
            is RestoreResult.Success         -> Unit
            is RestoreResult.ValidationError -> throw IllegalArgumentException(r.errors.joinToString("\n"))
            is RestoreResult.Failure         -> throw Exception(r.message, r.cause)
        }
    }

    /**
     * Reads a backup from [uri] and restores with the given [mode].
     *
     * [RestoreMode.MERGE]      – inserts only records not already present (by url/sourceId key).
     * [RestoreMode.OVERWRITE]  – replaces everything; clears library before importing.
     */
    suspend fun restoreFromUri(uri: Uri, mode: RestoreMode = RestoreMode.MERGE): RestoreResult =
        withContext(Dispatchers.IO) {
            val bytes = try {
                context.contentResolver.openInputStream(uri)?.readBytes()
                    ?: return@withContext RestoreResult.Failure("Could not open $uri for reading")
            } catch (e: Exception) {
                return@withContext RestoreResult.Failure("Failed to read file: ${e.message}", e)
            }

            restoreFromBytes(bytes, mode)
        }

    suspend fun restoreFromBytes(bytes: ByteArray, mode: RestoreMode = RestoreMode.MERGE): RestoreResult =
        withContext(Dispatchers.IO) {
            // 1 ── Parse
            val envelope = when (val r = serializer.fromJson(bytes)) {
                is SerializeResult.Success -> r.envelope
                is SerializeResult.Failure -> return@withContext RestoreResult.Failure(r.reason, r.cause)
            }

            // 2 ── Validate
            when (val v = validator.validate(envelope)) {
                is ValidationResult.Invalid -> return@withContext RestoreResult.ValidationError(v.errors)
                is ValidationResult.Valid   -> Unit
            }

            // 3 ── Apply
            try {
                applyRestore(envelope, mode)
            } catch (e: Exception) {
                Timber.e(e, "BackupManager: applyRestore failed")
                return@withContext RestoreResult.Failure("Restore failed during write: ${e.message}", e)
            }
        }

    // ── Inspect without restoring ─────────────────────────────────────────────

    /**
     * Parses and validates a backup file without writing anything to the database.
     * Use this to show a preview before the user confirms restore.
     */
    suspend fun inspect(uri: Uri): InspectResult = withContext(Dispatchers.IO) {
        val bytes = try {
            context.contentResolver.openInputStream(uri)?.readBytes()
                ?: return@withContext InspectResult.Failure("Could not open file")
        } catch (e: Exception) {
            return@withContext InspectResult.Failure("Failed to read: ${e.message}")
        }

        when (val r = serializer.fromJson(bytes)) {
            is SerializeResult.Failure -> InspectResult.Failure(r.reason)
            is SerializeResult.Success -> {
                val e = r.envelope
                when (val v = validator.validate(e)) {
                    is ValidationResult.Invalid -> InspectResult.Invalid(v.errors, buildPreview(e))
                    is ValidationResult.Valid   -> InspectResult.Valid(buildPreview(e))
                }
            }
        }
    }

    // ── Suggested filename ────────────────────────────────────────────────────

    fun suggestedFilename(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.getDefault())
        return "mangetsu_backup_${fmt.format(Date())}.json"
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private suspend fun buildEnvelope(): BackupEnvelope {
        val mangas         = db.mangaDao().getLibraryMangaSnapshot()
        val mangaIds       = mangas.map { it.id }.toSet()
        val chapters       = mangas.flatMap { db.chapterDao().getChaptersForMangaOnce(it.id) }
        val history        = db.historyDao().getHistorySnapshot()
        val repos          = db.extensionRepoDao().getAllSnapshot()
        val categories     = db.categoryDao().getAllOnce()
        val categoryLinks  = mangaIds.flatMap { mangaId ->
            db.mangaCategoryDao().getCategoryIdsForMangaOnce(mangaId)
                .map { catId -> BackupCategoryLink(mangaId, catId) }
        }
        val tracking       = mangaIds.flatMap { mangaId ->
            db.mangaTrackingDao().getTrackingForMangaOnce(mangaId)
        }
        val readerSettings = settingsRepo.settings.first()

        return BackupEnvelope(
            manga         = mangas.map { it.toBackup() },
            chapters      = chapters.map { it.toBackup() },
            history       = history.map { BackupHistory(it.mangaId, it.chapterId, it.lastRead, it.lastPageRead) },
            repos         = repos.map { BackupRepo(it.name, it.url) },
            categories    = categories.map { it.toBackup() },
            categoryLinks = categoryLinks,
            tracking      = tracking.map { it.toBackup() },
            readerSettings = readerSettings.toBackup()
        )
    }

    private suspend fun applyRestore(envelope: BackupEnvelope, mode: RestoreMode): RestoreResult {
        var mangaRestored    = 0
        var chaptersRestored = 0
        var historyRestored  = 0
        var catsRestored     = 0
        var trackingRestored = 0
        var reposRestored    = 0

        if (mode == RestoreMode.OVERWRITE) {
            // Wipe library manga (chapters, history, category links cascade via FK)
            db.mangaDao().getLibraryMangaSnapshot().forEach { db.mangaDao().deleteById(it.id) }
            db.categoryDao().getAllOnce().forEach { db.categoryDao().deleteById(it.id) }
            db.historyDao().clearAll()
            Timber.d("BackupManager: OVERWRITE mode — library cleared")
        }

        // ── Old-id → new-id maps (needed for linking chapters/history/tracking) ──
        val mangaIdMap    = mutableMapOf<Long, Long>() // backupId → dbId
        val categoryIdMap = mutableMapOf<Long, Long>()

        // Manga
        envelope.manga.forEach { bm ->
            val existing = db.mangaDao().getMangaByUrl(bm.url, bm.sourceId)
            val newId = if (existing != null) {
                if (mode == RestoreMode.MERGE) existing.id   // keep existing
                else { db.mangaDao().upsert(bm.toEntity(existing.id)); existing.id }
            } else {
                db.mangaDao().upsert(bm.toEntity(0L)).also { mangaRestored++ }
            }
            mangaIdMap[bm.id] = newId
        }

        // Chapters
        envelope.chapters.forEach { bc ->
            val newMangaId = mangaIdMap[bc.mangaId] ?: return@forEach
            val existing   = db.chapterDao().getChapterByUrl(bc.url, newMangaId)
            if (existing == null || mode == RestoreMode.OVERWRITE) {
                db.chapterDao().upsert(bc.toEntity(newMangaId))
                chaptersRestored++
            }
        }

        // History
        envelope.history.forEach { bh ->
            val newMangaId = mangaIdMap[bh.mangaId] ?: return@forEach
            val manga      = db.mangaDao().getMangaById(newMangaId) ?: return@forEach
            // Find chapter by searching for matching mangaId + approximate position
            val existing   = db.historyDao().getEntry(newMangaId, bh.chapterId)
            if (existing == null || mode == RestoreMode.OVERWRITE) {
                db.historyDao().upsert(
                    HistoryEntity(
                        mangaId      = newMangaId,
                        chapterId    = bh.chapterId,
                        mangaTitle   = manga.title,
                        chapterName  = "",
                        thumbnailUrl = manga.thumbnailUrl,
                        lastRead     = bh.lastRead,
                        lastPageRead = bh.lastPage
                    )
                )
                historyRestored++
            }
        }

        // Extension repos
        envelope.repos.forEach { br ->
            if (db.extensionRepoDao().getByUrl(br.url) == null) {
                db.extensionRepoDao().insert(ExtensionRepoEntity(name = br.name, url = br.url))
                reposRestored++
            }
        }

        // Categories
        envelope.categories.forEach { bc ->
            val existing = db.categoryDao().getAllOnce().find { it.name == bc.name }
            val newId = existing?.id ?: db.categoryDao().insert(bc.toEntity()).also { catsRestored++ }
            categoryIdMap[bc.id] = newId
        }

        // Category links
        envelope.categoryLinks.forEach { link ->
            val newMangaId = mangaIdMap[link.mangaId]       ?: return@forEach
            val newCatId   = categoryIdMap[link.categoryId] ?: return@forEach
            db.mangaCategoryDao().insert(MangaCategoryEntity(newMangaId, newCatId))
        }

        // Tracking
        envelope.tracking.forEach { bt ->
            val newMangaId = mangaIdMap[bt.mangaId] ?: return@forEach
            val existing   = db.mangaTrackingDao().getTracking(newMangaId, bt.trackerId)
            if (existing == null || mode == RestoreMode.OVERWRITE) {
                db.mangaTrackingDao().upsert(bt.toEntity(newMangaId))
                trackingRestored++
            }
        }

        // Reader settings
        envelope.readerSettings?.let { brs ->
            settingsRepo.save(brs.toReaderSettings())
        }

        Timber.i("BackupManager: restore complete — " +
            "manga=$mangaRestored chapters=$chaptersRestored history=$historyRestored " +
            "cats=$catsRestored tracking=$trackingRestored repos=$reposRestored")

        return RestoreResult.Success(
            RestoreStats(
                mangaRestored     = mangaRestored,
                chaptersRestored  = chaptersRestored,
                historyRestored   = historyRestored,
                categoriesRestored = catsRestored,
                trackingRestored  = trackingRestored,
                reposRestored     = reposRestored,
                mode              = mode
            )
        )
    }

    private fun buildPreview(e: BackupEnvelope) = BackupPreview(
        version       = e.version,
        createdAt     = e.createdAt,
        mangaCount    = e.manga.size,
        chapterCount  = e.chapters.size,
        historyCount  = e.history.size,
        categoryCount = e.categories.size,
        trackingCount = e.tracking.size,
        repoCount     = e.repos.size
    )
}

// ── Inspect result ────────────────────────────────────────────────────────────

sealed class InspectResult {
    data class Valid(val preview: BackupPreview)                          : InspectResult()
    data class Invalid(val errors: List<String>, val preview: BackupPreview) : InspectResult()
    data class Failure(val message: String)                               : InspectResult()
}

data class BackupPreview(
    val version:       Int,
    val createdAt:     Long,
    val mangaCount:    Int,
    val chapterCount:  Int,
    val historyCount:  Int,
    val categoryCount: Int,
    val trackingCount: Int,
    val repoCount:     Int
)

// ── Entity → BackupSchema ─────────────────────────────────────────────────────

private fun MangaEntity.toBackup() = BackupManga(
    id = id, sourceId = sourceId, url = url, title = title,
    thumbnailUrl = thumbnailUrl, author = author, artist = artist,
    description = description, genre = genre, status = status,
    inLibrary = inLibrary, favorite = favorite, dateAdded = dateAdded,
    initialized = initialized
)

private fun BackupManga.toEntity(overrideId: Long = 0L) = MangaEntity(
    id = overrideId, sourceId = sourceId, url = url, title = title,
    thumbnailUrl = thumbnailUrl, author = author, artist = artist,
    description = description, genre = genre, status = status,
    inLibrary = inLibrary, favorite = favorite, dateAdded = dateAdded,
    initialized = initialized
)

private fun com.mangetsu.data.database.entity.ChapterEntity.toBackup() = BackupChapter(
    mangaId = mangaId, sourceId = sourceId, url = url, name = name,
    chapterNumber = chapterNumber, volumeNumber = volumeNumber,
    dateUpload = dateUpload, scanlator = scanlator, read = read,
    lastPageRead = lastPageRead, sourceOrder = sourceOrder
)

private fun BackupChapter.toEntity(newMangaId: Long) =
    com.mangetsu.data.database.entity.ChapterEntity(
        mangaId = newMangaId, sourceId = sourceId, url = url, name = name,
        chapterNumber = chapterNumber, volumeNumber = volumeNumber,
        dateUpload = dateUpload, scanlator = scanlator, read = read,
        lastPageRead = lastPageRead, sourceOrder = sourceOrder
    )

private fun CategoryEntity.toBackup() = BackupCategory(
    id = id, name = name, sortOrder = sortOrder, sortMode = sortMode,
    sortAscending = sortAscending, isDefault = isDefault
)

private fun BackupCategory.toEntity() = CategoryEntity(
    name = name, sortOrder = sortOrder, sortMode = sortMode,
    sortAscending = sortAscending, isDefault = isDefault
)

private fun MangaTrackingEntity.toBackup() = BackupTracking(
    mangaId = mangaId, trackerId = trackerId, remoteId = remoteId,
    remoteUrl = remoteUrl, title = title, score = score, status = status,
    chaptersRead = chaptersRead, totalChapters = totalChapters,
    startDate = startDate, finishDate = finishDate
)

private fun BackupTracking.toEntity(newMangaId: Long) = MangaTrackingEntity(
    mangaId = newMangaId, trackerId = trackerId, remoteId = remoteId,
    remoteUrl = remoteUrl, title = title, score = score, status = status,
    chaptersRead = chaptersRead, totalChapters = totalChapters,
    startDate = startDate, finishDate = finishDate,
    lastSynced = System.currentTimeMillis()
)

private fun ReaderSettings.toBackup() = BackupReaderSettings(
    readingMode = readingMode.name, brightness = brightness,
    pageSpacingDp = pageSpacingDp, scaleToFit = scaleToFit,
    showPageNumbers = showPageNumbers, keepScreenOn = keepScreenOn,
    cropBorders = cropBorders, maxScaleFactor = maxScaleFactor
)

private fun BackupReaderSettings.toReaderSettings() = ReaderSettings(
    readingMode = try { ReadingMode.valueOf(readingMode) } catch (e: Exception) { ReadingMode.VERTICAL },
    brightness = brightness, pageSpacingDp = pageSpacingDp, scaleToFit = scaleToFit,
    showPageNumbers = showPageNumbers, keepScreenOn = keepScreenOn,
    cropBorders = cropBorders, maxScaleFactor = maxScaleFactor
)
