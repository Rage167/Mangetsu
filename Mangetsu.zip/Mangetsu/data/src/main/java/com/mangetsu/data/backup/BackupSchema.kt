package com.mangetsu.data.backup

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Root backup envelope.
 *
 * Version history:
 *  1 – original (manga, chapters, history, repos)
 *  2 – adds categories, categoryLinks, tracking, readerSettings
 */
@JsonClass(generateAdapter = true)
data class BackupEnvelope(
    @Json(name = "version")        val version:        Int                   = CURRENT_VERSION,
    @Json(name = "createdAt")      val createdAt:      Long                  = System.currentTimeMillis(),
    @Json(name = "appVersion")     val appVersion:     String                = "1.0.0",
    @Json(name = "manga")          val manga:          List<BackupManga>     = emptyList(),
    @Json(name = "chapters")       val chapters:       List<BackupChapter>   = emptyList(),
    @Json(name = "history")        val history:        List<BackupHistory>   = emptyList(),
    @Json(name = "repos")          val repos:          List<BackupRepo>      = emptyList(),
    @Json(name = "categories")     val categories:     List<BackupCategory>  = emptyList(),
    @Json(name = "categoryLinks")  val categoryLinks:  List<BackupCategoryLink> = emptyList(),
    @Json(name = "tracking")       val tracking:       List<BackupTracking>  = emptyList(),
    @Json(name = "readerSettings") val readerSettings: BackupReaderSettings? = null
) {
    companion object {
        const val CURRENT_VERSION = 2
        const val MIN_SUPPORTED   = 1
    }
}

// ── Manga ─────────────────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupManga(
    @Json(name = "id")           val id:           Long,
    @Json(name = "sourceId")     val sourceId:     Long,
    @Json(name = "url")          val url:          String,
    @Json(name = "title")        val title:        String,
    @Json(name = "thumbnailUrl") val thumbnailUrl: String?  = null,
    @Json(name = "author")       val author:       String?  = null,
    @Json(name = "artist")       val artist:       String?  = null,
    @Json(name = "description")  val description:  String?  = null,
    @Json(name = "genre")        val genre:        String?  = null,
    @Json(name = "status")       val status:       Int      = 0,
    @Json(name = "inLibrary")    val inLibrary:    Boolean  = true,
    @Json(name = "favorite")     val favorite:     Boolean  = false,
    @Json(name = "dateAdded")    val dateAdded:    Long     = 0L,
    @Json(name = "initialized")  val initialized:  Boolean  = false
)

// ── Chapter ───────────────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupChapter(
    @Json(name = "mangaId")       val mangaId:       Long,
    @Json(name = "sourceId")      val sourceId:      Long,
    @Json(name = "url")           val url:           String,
    @Json(name = "name")          val name:          String,
    @Json(name = "chapterNumber") val chapterNumber: Float   = -1f,
    @Json(name = "volumeNumber")  val volumeNumber:  Float?  = null,
    @Json(name = "dateUpload")    val dateUpload:    Long    = 0L,
    @Json(name = "scanlator")     val scanlator:     String? = null,
    @Json(name = "read")          val read:          Boolean = false,
    @Json(name = "lastPageRead")  val lastPageRead:  Int     = 0,
    @Json(name = "sourceOrder")   val sourceOrder:   Int     = 0
)

// ── History ───────────────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupHistory(
    @Json(name = "mangaId")      val mangaId:     Long,
    @Json(name = "chapterId")    val chapterId:   Long,
    @Json(name = "lastRead")     val lastRead:    Long,
    @Json(name = "lastPage")     val lastPage:    Int
)

// ── Extension repos ───────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupRepo(
    @Json(name = "name") val name: String,
    @Json(name = "url")  val url:  String
)

// ── Categories ────────────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupCategory(
    @Json(name = "id")            val id:           Long,
    @Json(name = "name")          val name:         String,
    @Json(name = "sortOrder")     val sortOrder:    Int     = 0,
    @Json(name = "sortMode")      val sortMode:     String  = "ALPHABETICAL",
    @Json(name = "sortAscending") val sortAscending: Boolean = true,
    @Json(name = "isDefault")     val isDefault:    Boolean = false
)

@JsonClass(generateAdapter = true)
data class BackupCategoryLink(
    @Json(name = "mangaId")    val mangaId:    Long,
    @Json(name = "categoryId") val categoryId: Long
)

// ── Tracking ──────────────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupTracking(
    @Json(name = "mangaId")       val mangaId:       Long,
    @Json(name = "trackerId")     val trackerId:     String,
    @Json(name = "remoteId")      val remoteId:      Long,
    @Json(name = "remoteUrl")     val remoteUrl:     String  = "",
    @Json(name = "title")         val title:         String  = "",
    @Json(name = "score")         val score:         Float   = 0f,
    @Json(name = "status")        val status:        Int     = 1,
    @Json(name = "chaptersRead")  val chaptersRead:  Int     = 0,
    @Json(name = "totalChapters") val totalChapters: Int     = 0,
    @Json(name = "startDate")     val startDate:     Long    = 0L,
    @Json(name = "finishDate")    val finishDate:    Long    = 0L
)

// ── Reader settings ───────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class BackupReaderSettings(
    @Json(name = "readingMode")     val readingMode:     String  = "VERTICAL",
    @Json(name = "brightness")      val brightness:      Float   = -1f,
    @Json(name = "pageSpacingDp")   val pageSpacingDp:   Int     = 8,
    @Json(name = "scaleToFit")      val scaleToFit:      Boolean = true,
    @Json(name = "showPageNumbers") val showPageNumbers:  Boolean = true,
    @Json(name = "keepScreenOn")    val keepScreenOn:    Boolean = true,
    @Json(name = "cropBorders")     val cropBorders:     Boolean = false,
    @Json(name = "maxScaleFactor")  val maxScaleFactor:  Float   = 5f
)
