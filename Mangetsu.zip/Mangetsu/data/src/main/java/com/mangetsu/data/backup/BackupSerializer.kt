package com.mangetsu.data.backup

import com.squareup.moshi.Moshi
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

sealed class SerializeResult {
    data class Success(val envelope: BackupEnvelope) : SerializeResult()
    data class Failure(val reason: String, val cause: Throwable? = null) : SerializeResult()
}

@Singleton
class BackupSerializer @Inject constructor(private val moshi: Moshi) {

    private val adapter by lazy {
        moshi.adapter(BackupEnvelope::class.java).lenient()
    }

    // ── Serialize ─────────────────────────────────────────────────────────────

    fun toJson(envelope: BackupEnvelope): ByteArray {
        return adapter.toJson(envelope).toByteArray(Charsets.UTF_8)
    }

    fun toJsonPretty(envelope: BackupEnvelope): ByteArray {
        return adapter.indent("  ").toJson(envelope).toByteArray(Charsets.UTF_8)
    }

    // ── Deserialize ───────────────────────────────────────────────────────────

    fun fromJson(bytes: ByteArray): SerializeResult {
        if (bytes.isEmpty()) {
            return SerializeResult.Failure("File is empty")
        }

        val json = try {
            String(bytes, Charsets.UTF_8)
        } catch (e: Exception) {
            return SerializeResult.Failure("File is not valid UTF-8: ${e.message}", e)
        }

        if (json.isBlank()) {
            return SerializeResult.Failure("File contains no content")
        }

        if (!json.trimStart().startsWith("{")) {
            return SerializeResult.Failure("File does not appear to be a JSON object")
        }

        val envelope = try {
            adapter.fromJson(json)
        } catch (e: com.squareup.moshi.JsonDataException) {
            Timber.w(e, "BackupSerializer: JSON data error")
            return SerializeResult.Failure("Backup file structure is invalid: ${e.message?.take(200)}", e)
        } catch (e: com.squareup.moshi.JsonEncodingException) {
            Timber.w(e, "BackupSerializer: JSON encoding error")
            return SerializeResult.Failure("Backup file is malformed JSON: ${e.message?.take(200)}", e)
        } catch (e: Exception) {
            Timber.e(e, "BackupSerializer: unexpected parse error")
            return SerializeResult.Failure("Failed to parse backup: ${e.message?.take(200)}", e)
        }

        if (envelope == null) {
            return SerializeResult.Failure("Parsed backup is null")
        }

        // ── Version migration ─────────────────────────────────────────────────
        val migrated = migrate(envelope)

        Timber.d("BackupSerializer: parsed v${envelope.version} → v${migrated.version}: " +
            "${migrated.manga.size} manga, ${migrated.chapters.size} chapters, " +
            "${migrated.history.size} history, ${migrated.categories.size} categories")

        return SerializeResult.Success(migrated)
    }

    // ── Migration ─────────────────────────────────────────────────────────────

    /**
     * Migrates older backup versions to the current schema.
     * Each version step is applied in sequence.
     */
    private fun migrate(envelope: BackupEnvelope): BackupEnvelope {
        var current = envelope

        // v1 → v2: categories, categoryLinks, tracking, readerSettings were added
        // No data migration needed — v1 backups simply have empty lists for these fields,
        // which the current schema already handles as defaults.
        if (current.version < 2) {
            Timber.d("BackupSerializer: migrating v1 → v2 (new fields default to empty)")
            current = current.copy(version = 2)
        }

        return current
    }
}
