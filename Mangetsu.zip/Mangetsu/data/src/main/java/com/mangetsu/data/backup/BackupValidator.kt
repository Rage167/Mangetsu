package com.mangetsu.data.backup

import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

sealed class ValidationResult {
    data class Valid(val envelope: BackupEnvelope) : ValidationResult()
    data class Invalid(val errors: List<String>)   : ValidationResult()

    val isValid: Boolean get() = this is Valid
}

/**
 * Validates a parsed [BackupEnvelope] before any database writes.
 *
 * Rules:
 * - Version must be in [BackupEnvelope.MIN_SUPPORTED]..[BackupEnvelope.CURRENT_VERSION]
 * - createdAt must be a plausible epoch (> year 2020)
 * - Every manga must have non-blank url, title, and positive sourceId
 * - Every chapter must reference a manga id present in the manga list
 * - Chapter urls must be non-blank and chapterNumber ≥ -1
 * - History entries must reference known manga ids
 * - Repo urls must start with http
 * - Category names must be non-blank
 * - CategoryLinks must reference known manga and category ids
 * - Tracking entries must have non-blank trackerId and positive remoteId
 */
@Singleton
class BackupValidator @Inject constructor() {

    fun validate(envelope: BackupEnvelope): ValidationResult {
        val errors = mutableListOf<String>()

        // ── Version ─────────────────────────────────────────────────────────
        if (envelope.version < BackupEnvelope.MIN_SUPPORTED ||
            envelope.version > BackupEnvelope.CURRENT_VERSION
        ) {
            errors += "Unsupported backup version ${envelope.version}. " +
                "Supported: ${BackupEnvelope.MIN_SUPPORTED}–${BackupEnvelope.CURRENT_VERSION}"
        }

        // ── Timestamp ────────────────────────────────────────────────────────
        val year2020 = 1_577_836_800_000L
        if (envelope.createdAt > 0 && envelope.createdAt < year2020) {
            errors += "Suspicious createdAt timestamp: ${envelope.createdAt}"
        }

        // ── Manga ─────────────────────────────────────────────────────────────
        val mangaIds = mutableSetOf<Long>()
        envelope.manga.forEachIndexed { i, m ->
            if (m.url.isBlank())   errors += "manga[$i]: url is blank"
            if (m.title.isBlank()) errors += "manga[$i]: title is blank"
            if (m.sourceId <= 0)   errors += "manga[$i]: invalid sourceId ${m.sourceId}"
            if (m.id > 0) mangaIds += m.id
        }

        // Duplicate url+sourceId check
        val mangaKeys = envelope.manga.map { "${it.sourceId}|${it.url}" }
        val duplicates = mangaKeys.groupBy { it }.filter { it.value.size > 1 }.keys
        if (duplicates.isNotEmpty()) {
            errors += "Duplicate manga entries: ${duplicates.take(3).joinToString()}"
        }

        // ── Chapters ──────────────────────────────────────────────────────────
        val referencedMangaIds = envelope.manga.map { it.id }.toSet()
        envelope.chapters.forEachIndexed { i, c ->
            if (c.url.isBlank())    errors += "chapter[$i]: url is blank"
            if (c.name.isBlank())   errors += "chapter[$i]: name is blank"
            if (c.sourceId <= 0)    errors += "chapter[$i]: invalid sourceId"
            if (c.chapterNumber < -1f) errors += "chapter[$i]: invalid chapterNumber ${c.chapterNumber}"
            if (c.mangaId > 0 && referencedMangaIds.isNotEmpty() && c.mangaId !in referencedMangaIds) {
                errors += "chapter[$i]: mangaId ${c.mangaId} not found in manga list"
            }
        }

        // Duplicate chapter url check
        val chapterUrls = envelope.chapters.groupBy { it.url }
        chapterUrls.filter { it.value.size > 1 }.keys.take(3).forEach { url ->
            errors += "Duplicate chapter url: $url"
        }

        // ── History ───────────────────────────────────────────────────────────
        envelope.history.forEachIndexed { i, h ->
            if (h.lastRead < 0)   errors += "history[$i]: negative lastRead"
            if (h.lastPage < 0)   errors += "history[$i]: negative lastPage"
        }

        // ── Repos ─────────────────────────────────────────────────────────────
        envelope.repos.forEachIndexed { i, r ->
            if (r.url.isBlank())   errors += "repo[$i]: url is blank"
            if (!r.url.startsWith("http")) errors += "repo[$i]: url must start with http"
            if (r.name.isBlank())  errors += "repo[$i]: name is blank"
        }

        // ── Categories ────────────────────────────────────────────────────────
        val categoryIds = mutableSetOf<Long>()
        envelope.categories.forEachIndexed { i, c ->
            if (c.name.isBlank()) errors += "category[$i]: name is blank"
            if (c.id > 0) categoryIds += c.id
        }

        // ── Category links ────────────────────────────────────────────────────
        envelope.categoryLinks.forEachIndexed { i, link ->
            if (link.mangaId <= 0)    errors += "categoryLink[$i]: invalid mangaId"
            if (link.categoryId <= 0) errors += "categoryLink[$i]: invalid categoryId"
        }

        // ── Tracking ──────────────────────────────────────────────────────────
        envelope.tracking.forEachIndexed { i, t ->
            if (t.trackerId.isBlank()) errors += "tracking[$i]: trackerId is blank"
            if (t.remoteId <= 0)       errors += "tracking[$i]: invalid remoteId ${t.remoteId}"
            if (t.mangaId <= 0)        errors += "tracking[$i]: invalid mangaId ${t.mangaId}"
            if (t.score < 0f || t.score > 100f) errors += "tracking[$i]: score ${t.score} out of range"
        }

        // ── Size sanity ───────────────────────────────────────────────────────
        if (envelope.manga.size > 50_000) {
            errors += "manga count ${envelope.manga.size} exceeds maximum (50000)"
        }
        if (envelope.chapters.size > 2_000_000) {
            errors += "chapter count ${envelope.chapters.size} exceeds maximum (2000000)"
        }

        Timber.d("BackupValidator: ${errors.size} error(s) for v${envelope.version} backup")
        return if (errors.isEmpty()) ValidationResult.Valid(envelope)
               else ValidationResult.Invalid(errors)
    }
}
