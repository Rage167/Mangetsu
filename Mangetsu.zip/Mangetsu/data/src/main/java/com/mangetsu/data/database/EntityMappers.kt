package com.mangetsu.data.database

import com.mangetsu.core.model.Chapter
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.core.model.History
import com.mangetsu.core.model.Manga
import com.mangetsu.data.database.entity.ChapterEntity
import com.mangetsu.data.database.entity.ExtensionRepoEntity
import com.mangetsu.data.database.entity.HistoryEntity
import com.mangetsu.data.database.entity.InstalledExtensionEntity
import com.mangetsu.data.database.entity.MangaEntity
import com.mangetsu.extensionapi.model.MangaStatus

// ── MangaEntity ↔ Manga ───────────────────────────────────────────────────────

fun MangaEntity.toDomain(): Manga = Manga(
    id            = id,
    sourceId      = sourceId,
    url           = url,
    title         = title,
    thumbnailUrl  = thumbnailUrl,
    author        = author,
    artist        = artist,
    description   = description,
    genre         = genre?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList(),
    status        = MangaStatus.fromValue(status),
    inLibrary     = inLibrary,
    favorite      = favorite,
    dateAdded     = dateAdded,
    lastUpdated   = lastUpdated,
    initialized   = initialized,
    unreadCount   = unreadCount
)

fun Manga.toEntity(): MangaEntity = MangaEntity(
    id           = id,
    sourceId     = sourceId,
    url          = url,
    title        = title,
    thumbnailUrl = thumbnailUrl,
    author       = author,
    artist       = artist,
    description  = description,
    genre        = genre.joinToString(","),
    status       = status.value,
    inLibrary    = inLibrary,
    favorite     = favorite,
    dateAdded    = dateAdded,
    lastUpdated  = lastUpdated,
    initialized  = initialized,
    unreadCount  = unreadCount
)

// ── ChapterEntity ↔ Chapter ───────────────────────────────────────────────────

fun ChapterEntity.toDomain(): Chapter = Chapter(
    id            = id,
    mangaId       = mangaId,
    sourceId      = sourceId,
    url           = url,
    name          = name,
    chapterNumber = chapterNumber,
    volumeNumber  = volumeNumber,
    dateUpload    = dateUpload,
    scanlator     = scanlator,
    read          = read,
    lastPageRead  = lastPageRead,
    downloaded    = downloaded,
    pageCount     = pageCount,
    sourceOrder   = sourceOrder
)

fun Chapter.toEntity(): ChapterEntity = ChapterEntity(
    id            = id,
    mangaId       = mangaId,
    sourceId      = sourceId,
    url           = url,
    name          = name,
    chapterNumber = chapterNumber,
    volumeNumber  = volumeNumber,
    dateUpload    = dateUpload,
    scanlator     = scanlator,
    read          = read,
    lastPageRead  = lastPageRead,
    downloaded    = downloaded,
    pageCount     = pageCount,
    sourceOrder   = sourceOrder
)

// ── HistoryEntity ↔ History ───────────────────────────────────────────────────

fun HistoryEntity.toDomain(): History = History(
    id           = id,
    mangaId      = mangaId,
    chapterId    = chapterId,
    mangaTitle   = mangaTitle,
    chapterName  = chapterName,
    thumbnailUrl = thumbnailUrl,
    lastRead     = lastRead,
    lastPageRead = lastPageRead
)

// ── ExtensionRepoEntity ↔ ExtensionRepo ───────────────────────────────────────

fun ExtensionRepoEntity.toDomain(): ExtensionRepo = ExtensionRepo(
    id          = id,
    name        = name,
    url         = url,
    description = description,
    addedAt     = addedAt,
    lastSynced  = lastSynced
)

fun ExtensionRepo.toEntity(): ExtensionRepoEntity = ExtensionRepoEntity(
    id          = id,
    name        = name,
    url         = url,
    description = description,
    addedAt     = addedAt,
    lastSynced  = lastSynced
)

// ── InstalledExtensionEntity ↔ Extension ──────────────────────────────────────

fun InstalledExtensionEntity.toDomain(): Extension = Extension(
    packageName = packageName,
    name        = name,
    versionName = versionName,
    versionCode = versionCode,
    lang        = lang,
    apkUrl      = apkUrl,
    iconUrl     = iconUrl,
    sourceId    = sourceId,
    isNsfw      = isNsfw,
    status      = ExtensionStatus.INSTALLED
)

fun Extension.toEntity(): InstalledExtensionEntity = InstalledExtensionEntity(
    packageName = packageName,
    name        = name,
    versionName = versionName,
    versionCode = versionCode,
    lang        = lang,
    apkUrl      = apkUrl,
    iconUrl     = iconUrl,
    sourceId    = sourceId,
    isNsfw      = isNsfw
)
