package com.mangetsu.data.database

import androidx.room.AutoMigration
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.mangetsu.data.database.converter.Converters
import com.mangetsu.data.database.dao.CategoryDao
import com.mangetsu.data.database.dao.ChapterDao
import com.mangetsu.data.database.dao.ExtensionRepoDao
import com.mangetsu.data.database.dao.HistoryDao
import com.mangetsu.data.database.dao.InstalledExtensionDao
import com.mangetsu.data.database.dao.MangaCategoryDao
import com.mangetsu.data.database.dao.MangaDao
import com.mangetsu.data.database.dao.MangaTrackingDao
import com.mangetsu.data.database.dao.TrackerAuthDao
import com.mangetsu.data.database.dao.UpdateCheckDao
import com.mangetsu.data.database.entity.CategoryEntity
import com.mangetsu.data.database.entity.ChapterEntity
import com.mangetsu.data.database.entity.ExtensionRepoEntity
import com.mangetsu.data.database.entity.HistoryEntity
import com.mangetsu.data.database.entity.InstalledExtensionEntity
import com.mangetsu.data.database.entity.MangaCategoryEntity
import com.mangetsu.data.database.entity.MangaEntity
import com.mangetsu.data.database.entity.MangaTrackingEntity
import com.mangetsu.data.database.entity.TrackerAuthEntity
import com.mangetsu.data.database.entity.UpdateCheckEntity

@Database(
    entities = [
        MangaEntity::class,
        ChapterEntity::class,
        HistoryEntity::class,
        ExtensionRepoEntity::class,
        InstalledExtensionEntity::class,
        CategoryEntity::class,
        MangaCategoryEntity::class,
        TrackerAuthEntity::class,
        MangaTrackingEntity::class,
        UpdateCheckEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class MangetsuDatabase : RoomDatabase() {
    abstract fun mangaDao(): MangaDao
    abstract fun chapterDao(): ChapterDao
    abstract fun historyDao(): HistoryDao
    abstract fun extensionRepoDao(): ExtensionRepoDao
    abstract fun installedExtensionDao(): InstalledExtensionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun mangaCategoryDao(): MangaCategoryDao
    abstract fun trackerAuthDao(): TrackerAuthDao
    abstract fun mangaTrackingDao(): MangaTrackingDao
    abstract fun updateCheckDao(): UpdateCheckDao

    companion object {
        const val DATABASE_NAME = "mangetsu.db"
    }
}
