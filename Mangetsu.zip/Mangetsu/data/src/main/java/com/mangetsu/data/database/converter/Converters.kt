package com.mangetsu.data.database.converter

import androidx.room.TypeConverter

class Converters {

    @TypeConverter
    fun fromStringList(value: String?): List<String> =
        value?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()

    @TypeConverter
    fun toStringList(list: List<String>?): String =
        list?.joinToString(",") ?: ""
}
