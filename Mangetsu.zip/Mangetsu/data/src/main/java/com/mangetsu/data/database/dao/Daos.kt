package com.mangetsu.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.mangetsu.data.database.entity.CategoryEntity
import com.mangetsu.data.database.entity.ChapterEntity
import com.mangetsu.data.database.entity.ExtensionRepoEntity
import com.mangetsu.data.database.entity.HistoryEntity
import com.mangetsu.data.database.entity.InstalledExtensionEntity
import com.mangetsu.data.database.entity.MangaCategoryEntity
import com.mangetsu.data.database.entity.MangaEntity
import com.mangetsu.data.database.entity.MangaTrackingEntity
import com.mangetsu.data.database.entity.TrackerAuthEntity
import com.mangetsu.data.database.entity.UpdateCheckEntity
import kotlinx.coroutines.flow.Flow

// ── MangaDao ──────────────────────────────────────────────────────────────────

@Dao
interface MangaDao {

    @Query("SELECT * FROM manga WHERE in_library = 1 ORDER BY title ASC")
    fun getLibraryManga(): Flow<List<MangaEntity>>

    @Query("""
        SELECT m.* FROM manga m
        LEFT JOIN manga_category mc ON m.id = mc.manga_id
        WHERE m.in_library = 1
          AND (:categoryId IS NULL OR mc.category_id = :categoryId)
        ORDER BY
          CASE :sortMode
            WHEN 'ALPHABETICAL'  THEN m.title
            WHEN 'LAST_READ'     THEN CAST(m.last_updated AS TEXT)
            WHEN 'LAST_ADDED'    THEN CAST(m.date_added AS TEXT)
            WHEN 'UNREAD_COUNT'  THEN CAST(m.unread_count AS TEXT)
            WHEN 'TOTAL_CHAPTERS'THEN CAST(m.chapter_count AS TEXT)
            ELSE m.title
          END ASC
    """)
    fun getLibraryMangaSorted(
        categoryId: Long?,
        sortMode:   String
    ): Flow<List<MangaEntity>>

    @Query("""
        SELECT m.* FROM manga m
        LEFT JOIN manga_category mc ON m.id = mc.manga_id
        WHERE m.in_library = 1
          AND (:categoryId IS NULL OR mc.category_id = :categoryId)
        ORDER BY
          CASE :sortMode
            WHEN 'ALPHABETICAL'  THEN m.title
            WHEN 'LAST_READ'     THEN CAST(m.last_updated AS TEXT)
            WHEN 'LAST_ADDED'    THEN CAST(m.date_added AS TEXT)
            WHEN 'UNREAD_COUNT'  THEN CAST(m.unread_count AS TEXT)
            WHEN 'TOTAL_CHAPTERS'THEN CAST(m.chapter_count AS TEXT)
            ELSE m.title
          END DESC
    """)
    fun getLibraryMangaSortedDesc(
        categoryId: Long?,
        sortMode:   String
    ): Flow<List<MangaEntity>>

    @Query("SELECT * FROM manga WHERE id = :id")
    suspend fun getMangaById(id: Long): MangaEntity?

    @Query("SELECT * FROM manga WHERE url = :url AND source_id = :sourceId LIMIT 1")
    suspend fun getMangaByUrl(url: String, sourceId: Long): MangaEntity?

    @Query("SELECT * FROM manga WHERE in_library = 1 AND unread_count > 0 ORDER BY unread_count DESC")
    fun getMangaWithUnread(): Flow<List<MangaEntity>>

    @Query("SELECT COUNT(*) FROM manga WHERE in_library = 1")
    fun getLibraryCount(): Flow<Int>

    @Query("SELECT SUM(unread_count) FROM manga WHERE in_library = 1")
    fun getTotalUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(manga: MangaEntity): Long

    @Update
    suspend fun update(manga: MangaEntity)

    @Query("UPDATE manga SET favorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("UPDATE manga SET in_library = :inLibrary, date_added = :dateAdded WHERE id = :id")
    suspend fun setInLibrary(id: Long, inLibrary: Boolean, dateAdded: Long)

    @Query("UPDATE manga SET unread_count = :count WHERE id = :id")
    suspend fun setUnreadCount(id: Long, count: Int)

    @Query("UPDATE manga SET chapter_count = :count WHERE id = :id")
    suspend fun setChapterCount(id: Long, count: Int)

    @Query("""
        UPDATE manga
        SET unread_count  = (SELECT COUNT(*) FROM chapter WHERE manga_id = :id AND read = 0),
            chapter_count = (SELECT COUNT(*) FROM chapter WHERE manga_id = :id)
        WHERE id = :id
    """)
    suspend fun refreshCounts(id: Long)

    @Query("UPDATE manga SET last_updated = :timestamp WHERE id = :id")
    suspend fun setLastUpdated(id: Long, timestamp: Long)

    @Query("UPDATE manga SET last_chapter_check = :timestamp WHERE id = :id")
    suspend fun setLastChapterCheck(id: Long, timestamp: Long)

    @Query("DELETE FROM manga WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM manga WHERE in_library = 1")
    suspend fun getLibraryMangaSnapshot(): List<MangaEntity>
}

// ── ChapterDao ────────────────────────────────────────────────────────────────

@Dao
interface ChapterDao {

    @Query("SELECT * FROM chapter WHERE manga_id = :mangaId ORDER BY source_order ASC")
    fun getChaptersByMangaId(mangaId: Long): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapter WHERE manga_id = :mangaId ORDER BY source_order ASC")
    suspend fun getChaptersForMangaOnce(mangaId: Long): List<ChapterEntity>

    @Query("SELECT * FROM chapter WHERE manga_id = :mangaId AND read = 0 ORDER BY source_order ASC")
    suspend fun getUnreadChapters(mangaId: Long): List<ChapterEntity>

    @Query("SELECT * FROM chapter WHERE manga_id = :mangaId ORDER BY source_order DESC LIMIT 1")
    suspend fun getLatestChapter(mangaId: Long): ChapterEntity?

    @Query("SELECT * FROM chapter WHERE id = :id")
    suspend fun getChapterById(id: Long): ChapterEntity?

    @Query("SELECT * FROM chapter WHERE url = :url AND manga_id = :mangaId LIMIT 1")
    suspend fun getChapterByUrl(url: String, mangaId: Long): ChapterEntity?

    @Query("SELECT COUNT(*) FROM chapter WHERE manga_id = :mangaId AND read = 0")
    fun getUnreadCount(mangaId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM chapter WHERE manga_id = :mangaId")
    suspend fun getTotalCount(mangaId: Long): Int

    @Query("""
        SELECT * FROM chapter
        WHERE manga_id = :mangaId
          AND date_fetch > :since
        ORDER BY source_order ASC
    """)
    suspend fun getChaptersSince(mangaId: Long, since: Long): List<ChapterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(chapters: List<ChapterEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(chapter: ChapterEntity): Long

    @Query("UPDATE chapter SET read = 1, last_page_read = :lastPage WHERE id = :id")
    suspend fun markRead(id: Long, lastPage: Int)

    @Query("UPDATE chapter SET read = 0, last_page_read = 0 WHERE id = :id")
    suspend fun markUnread(id: Long)

    @Query("UPDATE chapter SET read = 1 WHERE manga_id = :mangaId")
    suspend fun markAllRead(mangaId: Long)

    @Query("UPDATE chapter SET read = 0 WHERE manga_id = :mangaId")
    suspend fun markAllUnread(mangaId: Long)

    @Query("UPDATE chapter SET downloaded = :downloaded, page_count = :pageCount WHERE id = :id")
    suspend fun updateDownload(id: Long, downloaded: Boolean, pageCount: Int)

    @Query("DELETE FROM chapter WHERE manga_id = :mangaId")
    suspend fun deleteByMangaId(mangaId: Long)
}

// ── CategoryDao ───────────────────────────────────────────────────────────────

@Dao
interface CategoryDao {

    @Query("SELECT * FROM category ORDER BY sort_order ASC, name ASC")
    fun getAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM category ORDER BY sort_order ASC")
    suspend fun getAllOnce(): List<CategoryEntity>

    @Query("SELECT * FROM category WHERE id = :id")
    suspend fun getById(id: Long): CategoryEntity?

    @Query("SELECT * FROM category WHERE is_default = 1 LIMIT 1")
    suspend fun getDefault(): CategoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity): Long

    @Update
    suspend fun update(category: CategoryEntity)

    @Query("UPDATE category SET sort_order = :order WHERE id = :id")
    suspend fun updateOrder(id: Long, order: Int)

    @Query("DELETE FROM category WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM manga_category WHERE category_id = :categoryId")
    suspend fun getMangaCount(categoryId: Long): Int
}

// ── MangaCategoryDao ──────────────────────────────────────────────────────────

@Dao
interface MangaCategoryDao {

    @Query("SELECT category_id FROM manga_category WHERE manga_id = :mangaId")
    fun getCategoryIdsForManga(mangaId: Long): Flow<List<Long>>

    @Query("SELECT category_id FROM manga_category WHERE manga_id = :mangaId")
    suspend fun getCategoryIdsForMangaOnce(mangaId: Long): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: MangaCategoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<MangaCategoryEntity>)

    @Query("DELETE FROM manga_category WHERE manga_id = :mangaId")
    suspend fun deleteForManga(mangaId: Long)

    @Query("DELETE FROM manga_category WHERE manga_id = :mangaId AND category_id = :categoryId")
    suspend fun delete(mangaId: Long, categoryId: Long)

    @Transaction
    suspend fun setCategories(mangaId: Long, categoryIds: List<Long>) {
        deleteForManga(mangaId)
        insertAll(categoryIds.map { MangaCategoryEntity(mangaId, it) })
    }
}

// ── HistoryDao ────────────────────────────────────────────────────────────────

@Dao
interface HistoryDao {

    @Query("SELECT * FROM history ORDER BY last_read DESC LIMIT 200")
    fun getHistory(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history ORDER BY last_read DESC LIMIT 200")
    suspend fun getHistorySnapshot(): List<HistoryEntity>

    @Query("""
        SELECT * FROM history
        WHERE manga_title LIKE '%' || :query || '%'
           OR chapter_name LIKE '%' || :query || '%'
        ORDER BY last_read DESC
        LIMIT 200
    """)
    fun searchHistory(query: String): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE manga_id = :mangaId ORDER BY last_read DESC")
    fun getHistoryForManga(mangaId: Long): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE manga_id = :mangaId AND chapter_id = :chapterId LIMIT 1")
    suspend fun getEntry(mangaId: Long, chapterId: Long): HistoryEntity?

    @Query("SELECT * FROM history WHERE manga_id = :mangaId ORDER BY last_read DESC LIMIT 1")
    suspend fun getLastReadForManga(mangaId: Long): HistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(history: HistoryEntity)

    @Query("DELETE FROM history WHERE manga_id = :mangaId")
    suspend fun deleteByMangaId(mangaId: Long)

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM history")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM history")
    fun getCount(): Flow<Int>
}

// ── ExtensionRepoDao ──────────────────────────────────────────────────────────

@Dao
interface ExtensionRepoDao {

    @Query("SELECT * FROM extension_repo ORDER BY added_at ASC")
    fun getAll(): Flow<List<ExtensionRepoEntity>>

    @Query("SELECT * FROM extension_repo ORDER BY added_at ASC")
    suspend fun getAllSnapshot(): List<ExtensionRepoEntity>

    @Query("SELECT * FROM extension_repo WHERE id = :id")
    suspend fun getById(id: Long): ExtensionRepoEntity?

    @Query("SELECT * FROM extension_repo WHERE url = :url LIMIT 1")
    suspend fun getByUrl(url: String): ExtensionRepoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(repo: ExtensionRepoEntity): Long

    @Query("UPDATE extension_repo SET last_synced = :timestamp WHERE id = :id")
    suspend fun updateLastSynced(id: Long, timestamp: Long)

    @Query("DELETE FROM extension_repo WHERE id = :id")
    suspend fun deleteById(id: Long)
}

// ── InstalledExtensionDao ─────────────────────────────────────────────────────

@Dao
interface InstalledExtensionDao {

    @Query("SELECT * FROM installed_extension ORDER BY name ASC")
    fun getAll(): Flow<List<InstalledExtensionEntity>>

    @Query("SELECT * FROM installed_extension WHERE package_name = :packageName LIMIT 1")
    suspend fun getByPackageName(packageName: String): InstalledExtensionEntity?

    @Query("SELECT * FROM installed_extension WHERE source_id = :sourceId LIMIT 1")
    suspend fun getBySourceId(sourceId: Long): InstalledExtensionEntity?

    @Query("SELECT * FROM installed_extension ORDER BY name ASC")
    suspend fun getAllOnce(): List<InstalledExtensionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(ext: InstalledExtensionEntity): Long

    @Query("DELETE FROM installed_extension WHERE package_name = :packageName")
    suspend fun deleteByPackageName(packageName: String)

    @Query("UPDATE installed_extension SET enabled = :enabled WHERE package_name = :packageName")
    suspend fun setEnabled(packageName: String, enabled: Boolean)
}

// ── TrackerAuthDao ────────────────────────────────────────────────────────────

@Dao
interface TrackerAuthDao {

    @Query("SELECT * FROM tracker_auth")
    fun getAll(): Flow<List<TrackerAuthEntity>>

    @Query("SELECT * FROM tracker_auth WHERE tracker_id = :trackerId LIMIT 1")
    suspend fun getByTrackerId(trackerId: String): TrackerAuthEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(auth: TrackerAuthEntity)

    @Query("DELETE FROM tracker_auth WHERE tracker_id = :trackerId")
    suspend fun deleteByTrackerId(trackerId: String)

    @Query("UPDATE tracker_auth SET is_logged_in = 0, access_token = NULL, refresh_token = NULL WHERE tracker_id = :trackerId")
    suspend fun logout(trackerId: String)
}

// ── MangaTrackingDao ──────────────────────────────────────────────────────────

@Dao
interface MangaTrackingDao {

    @Query("SELECT * FROM manga_tracking WHERE manga_id = :mangaId")
    fun getTrackingForManga(mangaId: Long): Flow<List<MangaTrackingEntity>>

    @Query("SELECT * FROM manga_tracking WHERE manga_id = :mangaId")
    suspend fun getTrackingForMangaOnce(mangaId: Long): List<MangaTrackingEntity>

    @Query("SELECT * FROM manga_tracking WHERE manga_id = :mangaId AND tracker_id = :trackerId LIMIT 1")
    suspend fun getTracking(mangaId: Long, trackerId: String): MangaTrackingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(tracking: MangaTrackingEntity)

    @Query("DELETE FROM manga_tracking WHERE manga_id = :mangaId AND tracker_id = :trackerId")
    suspend fun delete(mangaId: Long, trackerId: String)

    @Query("DELETE FROM manga_tracking WHERE manga_id = :mangaId")
    suspend fun deleteForManga(mangaId: Long)

    @Query("UPDATE manga_tracking SET chapters_read = :count, last_synced = :timestamp WHERE manga_id = :mangaId AND tracker_id = :trackerId")
    suspend fun updateProgress(mangaId: Long, trackerId: String, count: Int, timestamp: Long)

    @Query("UPDATE manga_tracking SET score = :score WHERE manga_id = :mangaId AND tracker_id = :trackerId")
    suspend fun updateScore(mangaId: Long, trackerId: String, score: Float)

    @Query("UPDATE manga_tracking SET status = :status WHERE manga_id = :mangaId AND tracker_id = :trackerId")
    suspend fun updateStatus(mangaId: Long, trackerId: String, status: Int)
}

// ── UpdateCheckDao ────────────────────────────────────────────────────────────

@Dao
interface UpdateCheckDao {

    @Query("SELECT * FROM update_check WHERE manga_id = :mangaId LIMIT 1")
    suspend fun getForManga(mangaId: Long): UpdateCheckEntity?

    @Query("SELECT * FROM manga WHERE in_library = 1 AND (last_chapter_check = 0 OR last_chapter_check < :before)")
    suspend fun getMangaDueForUpdate(before: Long): List<MangaEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: UpdateCheckEntity)

    @Query("UPDATE update_check SET last_check = :timestamp, new_chapters_found = :found, error_message = :error WHERE manga_id = :mangaId")
    suspend fun updateResult(mangaId: Long, timestamp: Long, found: Int, error: String?)
}
