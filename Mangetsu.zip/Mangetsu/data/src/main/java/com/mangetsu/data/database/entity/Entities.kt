package com.mangetsu.data.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// ── Manga ─────────────────────────────────────────────────────────────────────

@Entity(tableName = "manga")
data class MangaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "source_id")
    val sourceId: Long,

    val url: String,
    val title: String,

    @ColumnInfo(name = "thumbnail_url")
    val thumbnailUrl: String? = null,

    val author: String? = null,
    val artist: String? = null,
    val description: String? = null,
    val genre: String? = null,
    val status: Int = 0,

    @ColumnInfo(name = "in_library")
    val inLibrary: Boolean = false,

    val favorite: Boolean = false,

    @ColumnInfo(name = "date_added")
    val dateAdded: Long = 0L,

    @ColumnInfo(name = "last_updated")
    val lastUpdated: Long = 0L,

    val initialized: Boolean = false,

    // ── Library category ──────────────────────────────────────────────────────
    @ColumnInfo(name = "category_id")
    val categoryId: Long? = null,

    // ── Update tracking ───────────────────────────────────────────────────────
    @ColumnInfo(name = "last_chapter_check")
    val lastChapterCheck: Long = 0L,

    @ColumnInfo(name = "unread_count")
    val unreadCount: Int = 0,

    @ColumnInfo(name = "chapter_count")
    val chapterCount: Int = 0,

    // ── Tracker links (serialised JSON map: trackerId -> trackingId) ──────────
    @ColumnInfo(name = "tracker_links")
    val trackerLinks: String? = null
)

// ── Chapter ───────────────────────────────────────────────────────────────────

@Entity(
    tableName = "chapter",
    foreignKeys = [
        ForeignKey(
            entity        = MangaEntity::class,
            parentColumns = ["id"],
            childColumns  = ["manga_id"],
            onDelete      = ForeignKey.CASCADE
        )
    ],
    indices = [Index("manga_id"), Index("url", unique = true)]
)
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "manga_id")
    val mangaId: Long,

    @ColumnInfo(name = "source_id")
    val sourceId: Long,

    val url: String,
    val name: String,

    @ColumnInfo(name = "chapter_number")
    val chapterNumber: Float = -1f,

    @ColumnInfo(name = "volume_number")
    val volumeNumber: Float? = null,

    @ColumnInfo(name = "date_upload")
    val dateUpload: Long = 0L,

    val scanlator: String? = null,
    val read: Boolean = false,

    @ColumnInfo(name = "last_page_read")
    val lastPageRead: Int = 0,

    val downloaded: Boolean = false,

    @ColumnInfo(name = "page_count")
    val pageCount: Int = 0,

    @ColumnInfo(name = "source_order")
    val sourceOrder: Int = 0,

    @ColumnInfo(name = "date_fetch")
    val dateFetch: Long = System.currentTimeMillis()
)

// ── Category ──────────────────────────────────────────────────────────────────

@Entity(tableName = "category")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    val name: String,

    @ColumnInfo(name = "sort_order")
    val sortOrder: Int = 0,

    @ColumnInfo(name = "sort_mode")
    val sortMode: String = "ALPHABETICAL",

    @ColumnInfo(name = "sort_ascending")
    val sortAscending: Boolean = true,

    @ColumnInfo(name = "is_default")
    val isDefault: Boolean = false
)

// ── MangaCategory (join table) ────────────────────────────────────────────────

@Entity(
    tableName = "manga_category",
    primaryKeys = ["manga_id", "category_id"],
    foreignKeys = [
        ForeignKey(MangaEntity::class, ["id"], ["manga_id"], onDelete = ForeignKey.CASCADE),
        ForeignKey(CategoryEntity::class, ["id"], ["category_id"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("manga_id"), Index("category_id")]
)
data class MangaCategoryEntity(
    @ColumnInfo(name = "manga_id")
    val mangaId: Long,

    @ColumnInfo(name = "category_id")
    val categoryId: Long
)

// ── History ───────────────────────────────────────────────────────────────────

@Entity(
    tableName = "history",
    foreignKeys = [
        ForeignKey(MangaEntity::class, ["id"], ["manga_id"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("manga_id"), Index("chapter_id")]
)
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "manga_id")
    val mangaId: Long,

    @ColumnInfo(name = "chapter_id")
    val chapterId: Long,

    @ColumnInfo(name = "manga_title")
    val mangaTitle: String,

    @ColumnInfo(name = "chapter_name")
    val chapterName: String,

    @ColumnInfo(name = "thumbnail_url")
    val thumbnailUrl: String? = null,

    @ColumnInfo(name = "last_read")
    val lastRead: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "last_page_read")
    val lastPageRead: Int = 0,

    @ColumnInfo(name = "chapter_number")
    val chapterNumber: Float = -1f
)

// ── ExtensionRepo ─────────────────────────────────────────────────────────────

@Entity(tableName = "extension_repo")
data class ExtensionRepoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    val name: String,
    val url: String,
    val description: String? = null,

    @ColumnInfo(name = "added_at")
    val addedAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "last_synced")
    val lastSynced: Long? = null
)

// ── InstalledExtension ────────────────────────────────────────────────────────

@Entity(tableName = "installed_extension", indices = [Index("package_name", unique = true)])
data class InstalledExtensionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    val name: String,

    @ColumnInfo(name = "version_name")
    val versionName: String,

    @ColumnInfo(name = "version_code")
    val versionCode: Int,

    val lang: String,

    @ColumnInfo(name = "apk_url")
    val apkUrl: String,

    @ColumnInfo(name = "icon_url")
    val iconUrl: String? = null,

    @ColumnInfo(name = "source_id")
    val sourceId: Long,

    @ColumnInfo(name = "is_nsfw")
    val isNsfw: Boolean = false,

    val enabled: Boolean = true
)

// ── TrackerAuth ───────────────────────────────────────────────────────────────

@Entity(tableName = "tracker_auth", indices = [Index("tracker_id", unique = true)])
data class TrackerAuthEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "tracker_id")
    val trackerId: String,

    @ColumnInfo(name = "access_token")
    val accessToken: String? = null,

    @ColumnInfo(name = "refresh_token")
    val refreshToken: String? = null,

    @ColumnInfo(name = "token_expiry")
    val tokenExpiry: Long? = null,

    val username: String? = null,

    @ColumnInfo(name = "is_logged_in")
    val isLoggedIn: Boolean = false
)

// ── MangaTracking ─────────────────────────────────────────────────────────────

@Entity(
    tableName = "manga_tracking",
    primaryKeys = ["manga_id", "tracker_id"],
    foreignKeys = [ForeignKey(MangaEntity::class, ["id"], ["manga_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("manga_id")]
)
data class MangaTrackingEntity(
    @ColumnInfo(name = "manga_id")
    val mangaId: Long,

    @ColumnInfo(name = "tracker_id")
    val trackerId: String,

    @ColumnInfo(name = "remote_id")
    val remoteId: Long,

    @ColumnInfo(name = "remote_url")
    val remoteUrl: String = "",

    val title: String = "",
    val score: Float = 0f,
    val status: Int = 0,

    @ColumnInfo(name = "chapters_read")
    val chaptersRead: Int = 0,

    @ColumnInfo(name = "total_chapters")
    val totalChapters: Int = 0,

    @ColumnInfo(name = "start_date")
    val startDate: Long = 0L,

    @ColumnInfo(name = "finish_date")
    val finishDate: Long = 0L,

    @ColumnInfo(name = "last_synced")
    val lastSynced: Long = 0L
)

// ── UpdateCheck ───────────────────────────────────────────────────────────────

@Entity(tableName = "update_check", indices = [Index("manga_id", unique = true)])
data class UpdateCheckEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "manga_id")
    val mangaId: Long,

    @ColumnInfo(name = "last_check")
    val lastCheck: Long = 0L,

    @ColumnInfo(name = "new_chapters_found")
    val newChaptersFound: Int = 0,

    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null
)
