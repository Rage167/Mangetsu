package com.mangetsu.data.extension

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Handles downloading and installing extension APKs using the [PackageInstaller] API.
 *
 * This is a session-based installation — no root required, no `REQUEST_INSTALL_PACKAGES`
 * permission abuse.  Android will prompt the user to confirm installation.
 */
@Singleton
class ExtensionInstaller @Inject constructor(
    private val context: Context,
    private val okHttpClient: OkHttpClient
) {

    companion object {
        const val INSTALL_ACTION = "com.mangetsu.EXTENSION_INSTALL_RESULT"
    }

    /**
     * Downloads the APK at [apkUrl] and triggers the Android system installer.
     *
     * The caller should observe the `INSTALL_ACTION` broadcast to know the result.
     *
     * @param packageName The expected package name (used to name the temp file).
     * @param apkUrl      Remote URL of the APK to download.
     * @throws IOException if the download fails.
     */
    suspend fun install(packageName: String, apkUrl: String) = withContext(Dispatchers.IO) {
        Timber.d("Downloading extension APK: $apkUrl")

        val apkFile = downloadApk(packageName, apkUrl)
        try {
            installApk(apkFile)
        } finally {
            apkFile.delete()
        }
    }

    /**
     * Requests the system to uninstall the package with [packageName].
     * Android will prompt the user to confirm.
     */
    suspend fun uninstall(packageName: String) = withContext(Dispatchers.IO) {
        val packageInstaller = context.packageManager.packageInstaller
        val intent = Intent(INSTALL_ACTION).apply {
            `package` = context.packageName
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, packageName.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        packageInstaller.uninstall(packageName, pendingIntent.intentSender)
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun downloadApk(packageName: String, url: String): File {
        val request  = Request.Builder().url(url).build()
        val response = okHttpClient.newCall(request).execute()

        if (!response.isSuccessful) {
            throw IOException("Download failed: HTTP ${response.code} for $url")
        }

        val file = File(context.cacheDir, "ext_$packageName.apk")
        response.body!!.byteStream().use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return file
    }

    private fun installApk(apkFile: File) {
        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            .apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
                }
            }

        val sessionId = packageInstaller.createSession(params)
        val session   = packageInstaller.openSession(sessionId)

        session.use { s ->
            apkFile.inputStream().use { input ->
                s.openWrite("extension.apk", 0, apkFile.length()).use { output ->
                    input.copyTo(output)
                    s.fsync(output)
                }
            }

            val intent = Intent(INSTALL_ACTION).apply {
                `package` = context.packageName
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, sessionId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            s.commit(pendingIntent.intentSender)
        }
    }
}
