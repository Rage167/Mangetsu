package com.mangetsu.data.extension

import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.toDomain
import com.mangetsu.data.database.toEntity
import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.data.extension.engine.SafeExtensionCaller
import com.mangetsu.data.extension.lifecycle.ExtensionLifecycleManager
import com.mangetsu.data.extension.registry.ExtensionRegistry
import com.mangetsu.domain.repository.ExtensionRepository
import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga
import com.mangetsu.extensionapi.model.SPage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * UPDATED ExtensionRepositoryImpl
 *
 * Replaces the original shallow wrapper.  Now delegates all source management to:
 *  - [ExtensionLifecycleManager] — install / uninstall / update lifecycle
 *  - [ExtensionRegistry]         — in-memory source registry
 *  - [SafeExtensionCaller]       — isolated, timeout-protected call execution
 *  - [RepoFetcher]               — remote repository index fetching
 *  - [ExtensionInstaller]        — APK download + PackageInstaller
 */
@Singleton
class ExtensionRepositoryImpl @Inject constructor(
    private val db:               MangetsuDatabase,
    private val lifecycleManager: ExtensionLifecycleManager,
    private val registry:         ExtensionRegistry,
    private val caller:           SafeExtensionCaller,
    private val installer:        ExtensionInstaller,
    private val repoFetcher:      RepoFetcher
) : ExtensionRepository {

    /** Available extensions fetched from all user-added repos. */
    private val _available = MutableStateFlow<List<Extension>>(emptyList())

    // ── Initialisation ────────────────────────────────────────────────────────

    /**
     * Must be called once at app start (from [MangetsuApp]).
     * Performs the full installed-package scan and populates the registry.
     */
    suspend fun init() {
        Timber.d("ExtensionRepositoryImpl: init — scanning installed extensions")
        lifecycleManager.scanAndLoadAll()
        Timber.d("ExtensionRepositoryImpl: init complete — " +
            "${registry.getAllExtensions().size} extension(s) loaded")
    }

    // ── ExtensionRepository interface ─────────────────────────────────────────

    override fun getInstalledExtensions(): Flow<List<Extension>> =
        registry.state.map { snap ->
            snap.all.map { loaded ->
                Extension(
                    packageName = loaded.packageName,
                    name        = loaded.sourceName,
                    versionName = loaded.versionName,
                    versionCode = loaded.versionCode,
                    lang        = loaded.lang,
                    apkUrl      = "",   // not relevant for installed extensions
                    sourceId    = loaded.sourceId,
                    isNsfw      = loaded.isNsfw,
                    status      = when {
                        loaded.disabled || loaded.isCircuitOpen -> ExtensionStatus.ERROR
                        else                                    -> ExtensionStatus.INSTALLED
                    }
                )
            }
        }

    override fun getAvailableExtensions(): Flow<List<Extension>> = _available.asStateFlow()

    override suspend fun refreshAvailableExtensions() {
        // Re-fetch all repos from the DB and merge results
        withContext(Dispatchers.IO) {
            val repos = db.extensionRepoDao().getAllOnce()
            val all   = repos.flatMap { repo ->
                try {
                    repoFetcher.fetchExtensions(repo.url)
                } catch (e: Exception) {
                    Timber.e(e, "refreshAvailableExtensions: failed to fetch ${repo.url}")
                    emptyList()
                }
            }
            _available.value = deduplicateByPackage(all)
        }
    }

    fun updateAvailable(extensions: List<Extension>) {
        _available.value = deduplicateByPackage(_available.value + extensions)
    }

    override suspend fun installExtension(extension: Extension) {
        installer.install(extension.packageName, extension.apkUrl)
        // Actual loading is triggered by PackageEventReceiver → onPackageInstalled
    }

    override suspend fun uninstallExtension(packageName: String) {
        installer.uninstall(packageName)
        // Actual unloading is triggered by PackageEventReceiver → onPackageRemoved
        // Eagerly unregister from the DB too
        db.installedExtensionDao().deleteByPackageName(packageName)
    }

    override fun getSourceForId(sourceId: Long): MangaSource? =
        registry.getSourceById(sourceId)

    override fun getAllSources(): List<MangaSource> = registry.getAllSources()

    // ── Safe source call helpers (used by BrowseRepositoryImpl) ──────────────

    suspend fun safePopular(sourceId: Long, page: Int): ExtensionResult<MangasPage> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchPopularManga(ext, page)
    }

    suspend fun safeLatest(sourceId: Long, page: Int): ExtensionResult<MangasPage> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchLatestUpdates(ext, page)
    }

    suspend fun safeSearch(
        sourceId: Long,
        page:     Int,
        query:    String,
        filters:  FilterList
    ): ExtensionResult<MangasPage> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchSearchManga(ext, page, query, filters)
    }

    suspend fun safeMangaDetails(sourceId: Long, manga: SManga): ExtensionResult<SManga> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchMangaDetails(ext, manga)
    }

    suspend fun safeChapterList(sourceId: Long, manga: SManga): ExtensionResult<List<SChapter>> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchChapterList(ext, manga)
    }

    suspend fun safePageList(sourceId: Long, chapter: SChapter): ExtensionResult<List<SPage>> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchPageList(ext, chapter)
    }

    suspend fun safePageImageUrl(sourceId: Long, page: SPage): ExtensionResult<SPage> {
        val ext = registry.getExtensionBySourceId(sourceId)
            ?: return sourceNotFound(sourceId)
        return caller.fetchPageImageUrl(ext, page)
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun <T> sourceNotFound(sourceId: Long): ExtensionResult<T> =
        ExtensionResult.Error(
            kind    = com.mangetsu.data.extension.engine.ErrorKind.SOURCE_NOT_FOUND,
            message = "Source $sourceId is not loaded. Is the extension installed?"
        )

    private fun deduplicateByPackage(list: List<Extension>): List<Extension> =
        list.distinctBy { it.packageName }

    private suspend fun com.mangetsu.data.database.dao.ExtensionRepoDao.getAllOnce(): List<com.mangetsu.data.database.entity.ExtensionRepoEntity> =
        kotlinx.coroutines.flow.first(getAll())

    private suspend fun <T> kotlinx.coroutines.flow.Flow<T>.first(): T =
        kotlinx.coroutines.flow.first(this) { true }
}
