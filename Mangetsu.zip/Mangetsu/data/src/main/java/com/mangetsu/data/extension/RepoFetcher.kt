package com.mangetsu.data.extension

import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fetches the JSON extension index from a repository URL and maps it to
 * a list of [Extension] domain objects.
 *
 * ## Expected JSON format
 * ```json
 * [
 *   {
 *     "name":        "Example Source",
 *     "package":     "com.example.source",
 *     "apkUrl":      "https://example.com/source.apk",
 *     "version":     "1.0.0",
 *     "versionCode": 1,
 *     "lang":        "en",
 *     "sourceId":    1234567890,
 *     "iconUrl":     "https://example.com/icon.png",
 *     "nsfw":        false
 *   }
 * ]
 * ```
 */
@Singleton
class RepoFetcher @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val moshi: Moshi
) {

    private val adapter by lazy {
        moshi.adapter<List<ExtensionIndexEntry>>(
            com.squareup.moshi.Types.newParameterizedType(
                List::class.java, ExtensionIndexEntry::class.java
            )
        )
    }

    /**
     * Fetches and parses the repository index at [url].
     *
     * @param url  URL of the JSON index file.
     * @return List of [Extension] objects with status [ExtensionStatus.AVAILABLE].
     * @throws Exception if the fetch or parse fails.
     */
    fun fetchExtensions(url: String): List<Extension> {
        val request  = Request.Builder().url(normaliseIndexUrl(url)).build()
        val response = okHttpClient.newCall(request).execute()

        if (!response.isSuccessful) {
            throw Exception("Repo fetch failed: HTTP ${response.code} for $url")
        }

        val body    = response.body?.string() ?: throw Exception("Empty response body for $url")
        val entries = adapter.fromJson(body) ?: throw Exception("Failed to parse repo JSON for $url")

        Timber.d("Fetched ${entries.size} extensions from $url")

        return entries.mapNotNull { it.toDomain() }
    }

    /**
     * Performs a lightweight HEAD request to check that [url] is reachable
     * and returns a 2xx response.
     */
    fun validateUrl(url: String): Boolean = try {
        val request = Request.Builder()
            .url(normaliseIndexUrl(url))
            .head()
            .build()
        val response = okHttpClient.newCall(request).execute()
        response.isSuccessful
    } catch (e: Exception) {
        Timber.w(e, "Repo URL validation failed: $url")
        false
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** If the user entered a bare domain, append the standard index filename. */
    private fun normaliseIndexUrl(url: String): String {
        val trimmed = url.trimEnd('/')
        return if (trimmed.endsWith(".json")) trimmed else "$trimmed/index.json"
    }
}

// ── JSON model ────────────────────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class ExtensionIndexEntry(
    @Json(name = "name")        val name: String,
    @Json(name = "package")     val packageName: String,
    @Json(name = "apkUrl")      val apkUrl: String,
    @Json(name = "version")     val version: String,
    @Json(name = "versionCode") val versionCode: Int = 1,
    @Json(name = "lang")        val lang: String = "en",
    @Json(name = "sourceId")    val sourceId: Long,
    @Json(name = "iconUrl")     val iconUrl: String? = null,
    @Json(name = "nsfw")        val nsfw: Boolean = false
) {
    fun toDomain(): Extension? {
        if (name.isBlank() || packageName.isBlank() || apkUrl.isBlank()) return null
        return Extension(
            packageName = packageName,
            name        = name,
            versionName = version,
            versionCode = versionCode,
            lang        = lang,
            apkUrl      = apkUrl,
            iconUrl     = iconUrl,
            sourceId    = sourceId,
            isNsfw      = nsfw,
            status      = ExtensionStatus.AVAILABLE
        )
    }
}
