package com.mangetsu.data.extension.download

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages APK downloads for extensions with:
 * - Per-download progress as StateFlow
 * - Resume support via HTTP Range requests
 * - Exponential-backoff retry (up to [MAX_RETRIES] attempts)
 * - Cancellation via coroutine cancellation
 * - Concurrent download tracking
 */
@Singleton
class ApkDownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient
) {
    companion object {
        private const val DOWNLOAD_DIR  = "ext_downloads"
        private const val BUFFER_SIZE   = 8 * 1024        // 8 KB
        private const val MAX_RETRIES   = 3
        private const val BASE_DELAY_MS = 2_000L
        /** Minimum bytes to keep a partial file and attempt resume. */
        private const val MIN_RESUME_SIZE = 64 * 1024L    // 64 KB
    }

    // ── State ─────────────────────────────────────────────────────────────────

    private val _downloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val downloads: Flow<Map<String, DownloadState>> = _downloads.asStateFlow()

    fun getDownloadState(packageName: String): DownloadState? =
        _downloads.value[packageName]

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Downloads the APK at [apkUrl] for [packageName].
     *
     * Attempts up to [MAX_RETRIES] times with exponential backoff on failure.
     * Supports HTTP Range resume if a partial file exists from a prior attempt.
     *
     * @return The completed [File] on success.
     * @throws ApkDownloadException if all retries are exhausted.
     */
    suspend fun download(packageName: String, apkUrl: String): File {
        setState(packageName, DownloadState.Queued(packageName))

        var attempt = 0
        var lastError: Exception = IOException("Unknown error")

        while (attempt < MAX_RETRIES) {
            attempt++
            try {
                val file = attemptDownload(packageName, apkUrl, attempt)
                setState(packageName, DownloadState.Completed(packageName, file.absolutePath))
                Timber.i("ApkDownloadManager: ✅ $packageName downloaded (attempt $attempt)")
                return file
            } catch (e: CancellationException) {
                setState(packageName, DownloadState.Cancelled(packageName))
                throw e
            } catch (e: Exception) {
                lastError = e
                Timber.w(e, "ApkDownloadManager: attempt $attempt/$MAX_RETRIES failed for $packageName")

                if (attempt < MAX_RETRIES) {
                    val delayMs = BASE_DELAY_MS * (1L shl (attempt - 1))  // 2s, 4s, 8s
                    setState(packageName, DownloadState.Retrying(packageName, attempt, MAX_RETRIES, delayMs))
                    kotlinx.coroutines.delay(delayMs)
                }
            }
        }

        setState(packageName, DownloadState.Failed(packageName, lastError.message ?: "Download failed"))
        throw ApkDownloadException("Failed after $MAX_RETRIES attempts for $packageName", lastError)
    }

    /**
     * Cancels an in-progress download by deleting the partial file and
     * updating state. The coroutine cancellation itself is handled by the caller.
     */
    fun cancel(packageName: String) {
        partialFileFor(packageName).delete()
        setState(packageName, DownloadState.Cancelled(packageName))
        Timber.d("ApkDownloadManager: cancelled $packageName")
    }

    /** Removes the completed APK file and clears download state. */
    fun cleanup(packageName: String) {
        partialFileFor(packageName).delete()
        completedFileFor(packageName).delete()
        _downloads.update { it - packageName }
        Timber.d("ApkDownloadManager: cleaned up $packageName")
    }

    // ── Private ───────────────────────────────────────────────────────────────

    private suspend fun attemptDownload(
        packageName: String,
        apkUrl:      String,
        attempt:     Int
    ): File = withContext(Dispatchers.IO) {

        val partialFile   = partialFileFor(packageName)
        val completedFile = completedFileFor(packageName)
        val existingBytes = if (partialFile.exists() && partialFile.length() >= MIN_RESUME_SIZE)
            partialFile.length() else 0L

        // Build request — add Range header if we have a partial file to resume
        val request = Request.Builder()
            .url(apkUrl)
            .apply { if (existingBytes > 0) addHeader("Range", "bytes=$existingBytes-") }
            .build()

        Timber.d("ApkDownloadManager: starting download $packageName attempt=$attempt " +
            "resume=${existingBytes}b url=$apkUrl")

        setState(packageName, DownloadState.Downloading(
            packageName   = packageName,
            progress      = 0,
            downloadedBytes = existingBytes,
            totalBytes    = -1L
        ))

        val response = okHttpClient.newCall(request).execute()

        if (!response.isSuccessful && response.code != 206 /* Partial Content */) {
            throw IOException("HTTP ${response.code} from $apkUrl")
        }

        val body          = response.body ?: throw IOException("Empty response body")
        val contentLength = body.contentLength()
        val totalBytes    = if (existingBytes > 0 && contentLength > 0)
            existingBytes + contentLength else contentLength
        val isResume      = response.code == 206

        var downloadedBytes = existingBytes

        // Write to partial file — append if resuming, overwrite if fresh
        RandomAccessFile(partialFile, "rw").use { raf ->
            if (isResume) raf.seek(existingBytes) else raf.setLength(0)

            val buffer = ByteArray(BUFFER_SIZE)
            body.byteStream().use { stream ->
                var read: Int
                while (stream.read(buffer).also { read = it } != -1) {
                    raf.write(buffer, 0, read)
                    downloadedBytes += read
                    val progress = if (totalBytes > 0)
                        ((downloadedBytes * 100) / totalBytes).toInt() else -1
                    setState(packageName, DownloadState.Downloading(
                        packageName     = packageName,
                        progress        = progress,
                        downloadedBytes = downloadedBytes,
                        totalBytes      = totalBytes
                    ))
                }
            }
        }

        // Atomic rename: partial → completed
        partialFile.renameTo(completedFile)
        completedFile
    }

    private fun setState(packageName: String, state: DownloadState) {
        _downloads.update { it + (packageName to state) }
    }

    private fun downloadDir(): File =
        File(context.filesDir, DOWNLOAD_DIR).also { it.mkdirs() }

    private fun partialFileFor(packageName: String) =
        File(downloadDir(), "$packageName.apk.part")

    private fun completedFileFor(packageName: String) =
        File(downloadDir(), "$packageName.apk")
}

// ── Download state ────────────────────────────────────────────────────────────

sealed class DownloadState {
    abstract val packageName: String

    data class Queued(override val packageName: String) : DownloadState()

    data class Downloading(
        override val packageName: String,
        val progress:             Int,    // 0-100, or -1 if content-length unknown
        val downloadedBytes:      Long,
        val totalBytes:           Long
    ) : DownloadState() {
        val isIndeterminate: Boolean get() = progress < 0
        val progressFloat:   Float   get() = progress.coerceIn(0, 100) / 100f
    }

    data class Retrying(
        override val packageName: String,
        val attempt:              Int,
        val maxAttempts:          Int,
        val delayMs:              Long
    ) : DownloadState()

    data class Completed(
        override val packageName: String,
        val apkPath:              String
    ) : DownloadState()

    data class Failed(
        override val packageName: String,
        val message:              String
    ) : DownloadState()

    data class Cancelled(override val packageName: String) : DownloadState()
}

class ApkDownloadException(message: String, cause: Throwable? = null) :
    IOException(message, cause)
