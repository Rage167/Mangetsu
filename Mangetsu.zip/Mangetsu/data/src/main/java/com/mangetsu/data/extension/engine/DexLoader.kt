package com.mangetsu.data.extension.engine

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.mangetsu.data.extension.security.ApkValidator
import com.mangetsu.extensionapi.MangaSource
import dalvik.system.DexClassLoader
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Loads [MangaSource] instances from extension APKs using [DexClassLoader].
 *
 * ## Why DexClassLoader instead of PathClassLoader?
 * [PathClassLoader] cannot accept an optimised-dex output directory parameter —
 * it always uses the system's default location, which on Android 8+ is read-only
 * for app-installed paths. [DexClassLoader] lets us specify a writable output
 * directory inside our private app data, which is required for runtime DEX
 * optimisation (`dex2oat` / `odex` generation) on all API levels.
 *
 * Each extension gets **its own** [DexClassLoader] instance.  The host's class
 * loader is set as the **parent**, so extensions share the `extension-api` types
 * (MangaSource, SManga, etc.) without duplication, but their own classes remain
 * isolated from each other.
 */
@Singleton
class DexLoader @Inject constructor(
    private val context: Context,
    private val validator: ApkValidator
) {

    companion object {
        private const val MANIFEST_SOURCE_CLASS = "mangetsu.extension.source.class"
        private const val MANIFEST_SOURCE_ID    = "mangetsu.extension.id"
        private const val MANIFEST_LANG         = "mangetsu.extension.lang"
        private const val MANIFEST_VERSION_CODE = "mangetsu.extension.version.code"
        private const val MANIFEST_NSFW         = "mangetsu.extension.nsfw"
        /** Sub-directory inside filesDir for optimised DEX output, one per extension. */
        private const val DEX_OUTPUT_BASE       = "ext_odex"
    }

    /**
     * Loads a single extension APK and returns a fully populated [LoadedExtension].
     *
     * All errors are caught and mapped to [ExtensionResult.Error] — this method
     * never throws.
     *
     * @param apkPath     Absolute path to the APK file (from [PackageInfo.applicationInfo.sourceDir]).
     * @param packageName Package name of the extension.
     */
    fun load(apkPath: String, packageName: String): ExtensionResult<LoadedExtension> {
        Timber.d("DexLoader: loading $packageName from $apkPath")

        // 1 ── Security validation ─────────────────────────────────────────────
        val validation = validator.validate(apkPath, packageName)
        if (!validation.valid) {
            return ExtensionResult.Error(
                kind           = ErrorKind.INVALID_APK,
                message        = validation.reason,
                sourcePackage  = packageName
            )
        }

        // 2 ── Read manifest meta-data ─────────────────────────────────────────
        val meta = readManifestMeta(apkPath, packageName)
            ?: return ExtensionResult.Error(
                kind          = ErrorKind.INVALID_APK,
                message       = "Cannot parse manifest meta-data for $packageName",
                sourcePackage = packageName
            )

        val sourceClassName = meta.sourceClass ?: return ExtensionResult.Error(
            kind          = ErrorKind.INVALID_APK,
            message       = "Missing '$MANIFEST_SOURCE_CLASS' in manifest for $packageName",
            sourcePackage = packageName
        )

        // 3 ── Create isolated optimised-dex output dir ────────────────────────
        val odexDir = File(context.filesDir, "$DEX_OUTPUT_BASE/$packageName")
            .also { it.mkdirs() }

        // 4 ── Build the DexClassLoader ────────────────────────────────────────
        val classLoader = try {
            DexClassLoader(
                apkPath,
                odexDir.absolutePath,
                null,                       // librarySearchPath — extensions don't ship .so files
                context.classLoader         // parent: shares extension-api, Kotlin stdlib, coroutines
            )
        } catch (e: Exception) {
            Timber.e(e, "DexLoader: DexClassLoader constructor failed for $packageName")
            return ExtensionResult.Error(
                kind          = ErrorKind.DEX_LOAD_FAILURE,
                message       = "DexClassLoader failed: ${e.message}",
                cause         = e,
                sourcePackage = packageName
            )
        }

        // 5 ── Resolve and instantiate the MangaSource class ──────────────────
        val sourceClass = try {
            classLoader.loadClass(sourceClassName)
        } catch (e: ClassNotFoundException) {
            Timber.e(e, "DexLoader: class not found '$sourceClassName' in $packageName")
            return ExtensionResult.Error(
                kind          = ErrorKind.CLASS_NOT_FOUND,
                message       = "Class '$sourceClassName' not found in DEX of $packageName",
                cause         = e,
                sourcePackage = packageName
            )
        } catch (e: Exception) {
            Timber.e(e, "DexLoader: loadClass threw for $packageName")
            return ExtensionResult.Error(
                kind          = ErrorKind.DEX_LOAD_FAILURE,
                message       = "loadClass failed: ${e.message}",
                cause         = e,
                sourcePackage = packageName
            )
        }

        // 6 ── Type check ──────────────────────────────────────────────────────
        if (!MangaSource::class.java.isAssignableFrom(sourceClass)) {
            return ExtensionResult.Error(
                kind          = ErrorKind.WRONG_TYPE,
                message       = "'$sourceClassName' does not implement MangaSource",
                sourcePackage = packageName
            )
        }

        // 7 ── Instantiate (no-arg constructor required) ───────────────────────
        val instance = try {
            sourceClass.getDeclaredConstructor().newInstance() as MangaSource
        } catch (e: Exception) {
            Timber.e(e, "DexLoader: instantiation failed for $sourceClassName")
            return ExtensionResult.Error(
                kind          = ErrorKind.SOURCE_EXCEPTION,
                message       = "Constructor of '$sourceClassName' threw: ${e.message}",
                cause         = e,
                sourcePackage = packageName
            )
        }

        val loaded = LoadedExtension(
            packageName  = packageName,
            source       = instance,
            classLoader  = classLoader,
            apkPath      = apkPath,
            versionCode  = meta.versionCode,
            versionName  = meta.versionName,
            lang         = meta.lang,
            isNsfw       = meta.isNsfw
        )

        Timber.i("DexLoader: ✅ loaded '${instance.name}' (id=${instance.id}) from $packageName")
        return ExtensionResult.Success(loaded)
    }

    /**
     * Cleans up the optimised-dex output directory for a package that is being
     * uninstalled. The classloader itself will be GC-ed once the registry drops
     * its reference.
     */
    fun cleanupOdex(packageName: String) {
        val odexDir = File(context.filesDir, "$DEX_OUTPUT_BASE/$packageName")
        if (odexDir.exists()) {
            val deleted = odexDir.deleteRecursively()
            Timber.d("DexLoader: cleaned up odex for $packageName (deleted=$deleted)")
        }
    }

    // ── Manifest reader ───────────────────────────────────────────────────────

    private data class ManifestMeta(
        val sourceClass: String?,
        val versionCode: Int,
        val versionName: String,
        val lang:        String,
        val isNsfw:      Boolean
    )

    private fun readManifestMeta(apkPath: String, packageName: String): ManifestMeta? {
        return try {
            val pm    = context.packageManager
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                PackageManager.GET_META_DATA
            else
                @Suppress("DEPRECATION") PackageManager.GET_META_DATA

            val info  = pm.getPackageArchiveInfo(apkPath, flags) ?: return null
            info.applicationInfo?.sourceDir = apkPath   // required for getPackageArchiveInfo
            val meta  = info.applicationInfo?.metaData

            ManifestMeta(
                sourceClass = meta?.getString(MANIFEST_SOURCE_CLASS),
                versionCode = info.versionCode,
                versionName = info.versionName ?: "1.0",
                lang        = meta?.getString(MANIFEST_LANG) ?: "en",
                isNsfw      = meta?.getBoolean(MANIFEST_NSFW, false) ?: false
            )
        } catch (e: Exception) {
            Timber.e(e, "DexLoader: failed to read manifest meta for $packageName")
            null
        }
    }
}
