package com.mangetsu.data.extension.engine

/**
 * Typed result of any call into an extension.
 *
 * All public entry-points in [SafeExtensionCaller] return this type so that
 * a crash or misbehaviour inside an extension APK **never** propagates up into
 * the host app's coroutine hierarchy.
 */
sealed class ExtensionResult<out T> {

    data class Success<T>(val data: T) : ExtensionResult<T>()

    data class Error(
        val kind:      ErrorKind,
        val message:   String,
        val cause:     Throwable? = null,
        /** Package name of the offending extension, if known. */
        val sourcePackage: String? = null
    ) : ExtensionResult<Nothing>()

    // ── Convenience accessors ─────────────────────────────────────────────────

    val isSuccess: Boolean get() = this is Success
    val isError:   Boolean get() = this is Error

    fun getOrNull(): T? = (this as? Success)?.data

    fun getOrThrow(): T = when (this) {
        is Success -> data
        is Error   -> throw ExtensionException(message, cause)
    }

    fun <R> map(transform: (T) -> R): ExtensionResult<R> = when (this) {
        is Success -> Success(transform(data))
        is Error   -> this
    }
}

enum class ErrorKind {
    /** The source threw an exception during the call. */
    SOURCE_EXCEPTION,
    /** Extension APK failed signature / integrity validation. */
    INVALID_APK,
    /** DEX could not be loaded (bad format, ABI mismatch, etc.). */
    DEX_LOAD_FAILURE,
    /** Declared source class was not found in the DEX. */
    CLASS_NOT_FOUND,
    /** Class was found but doesn't implement [com.mangetsu.extensionapi.MangaSource]. */
    WRONG_TYPE,
    /** Source was called but is no longer registered (uninstalled mid-session). */
    SOURCE_NOT_FOUND,
    /** The call timed out. */
    TIMEOUT,
    /** Unknown / unclassified error. */
    UNKNOWN
}

class ExtensionException(message: String, cause: Throwable? = null) :
    RuntimeException(message, cause)
