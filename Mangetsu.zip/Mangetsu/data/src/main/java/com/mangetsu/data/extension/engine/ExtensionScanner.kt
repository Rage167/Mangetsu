package com.mangetsu.data.extension.engine

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Scans installed packages for extension APKs by looking for the
 * `mangetsu.extension = true` meta-data marker.
 *
 * Returns a list of [ExtensionCandidate] objects — one per detected extension.
 * The caller ([ExtensionLifecycleManager]) then decides whether to load each one.
 */
@Singleton
class ExtensionScanner @Inject constructor(
    private val context: Context
) {

    companion object {
        private const val EXTENSION_MARKER = "mangetsu.extension"
    }

    /**
     * A package detected as a potential extension, before DEX loading.
     */
    data class ExtensionCandidate(
        val packageName: String,
        val apkPath:     String,
        val versionCode: Int,
        val versionName: String
    )

    /**
     * Returns all currently installed packages that declare the extension marker.
     *
     * This method is synchronous and may take a few hundred ms on devices with
     * many installed apps.  Always call it from a background dispatcher.
     */
    fun scanInstalledExtensions(): List<ExtensionCandidate> {
        val pm       = context.packageManager
        val packages = getInstalledPackages(pm)
        val found    = mutableListOf<ExtensionCandidate>()

        for (info in packages) {
            val appInfo = info.applicationInfo ?: continue
            val meta    = appInfo.metaData      ?: continue

            if (!meta.getBoolean(EXTENSION_MARKER, false)) continue

            val apkPath = appInfo.sourceDir
            if (apkPath.isNullOrBlank()) {
                Timber.w("ExtensionScanner: ${info.packageName} has empty sourceDir — skipping")
                continue
            }

            found += ExtensionCandidate(
                packageName = info.packageName,
                apkPath     = apkPath,
                versionCode = getVersionCode(info),
                versionName = info.versionName ?: "?"
            )

            Timber.d("ExtensionScanner: found candidate ${info.packageName} v${info.versionName}")
        }

        Timber.i("ExtensionScanner: scan complete — found ${found.size} candidate(s)")
        return found
    }

    /**
     * Returns whether a specific package is still installed and carries the marker.
     * Used after an install broadcast to verify before loading.
     */
    fun isExtensionInstalled(packageName: String): Boolean {
        return try {
            val pm   = context.packageManager
            val info = pm.getPackageInfo(packageName, metaDataFlags())
            info.applicationInfo?.metaData?.getBoolean(EXTENSION_MARKER, false) == true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            Timber.e(e, "ExtensionScanner: error checking $packageName")
            false
        }
    }

    /**
     * Returns the [ExtensionCandidate] for a specific package, or null if
     * it is not installed / not an extension.
     */
    fun getCandidateForPackage(packageName: String): ExtensionCandidate? {
        return try {
            val pm      = context.packageManager
            val info    = pm.getPackageInfo(packageName, metaDataFlags())
            val appInfo = info.applicationInfo ?: return null
            val meta    = appInfo.metaData      ?: return null

            if (!meta.getBoolean(EXTENSION_MARKER, false)) return null

            ExtensionCandidate(
                packageName = info.packageName,
                apkPath     = appInfo.sourceDir ?: return null,
                versionCode = getVersionCode(info),
                versionName = info.versionName ?: "?"
            )
        } catch (e: Exception) {
            null
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    @Suppress("DEPRECATION")
    private fun getInstalledPackages(pm: PackageManager): List<PackageInfo> {
        val flags = metaDataFlags()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            pm.getInstalledPackages(flags)
        }
    }

    private fun metaDataFlags(): Int = PackageManager.GET_META_DATA

    @Suppress("DEPRECATION")
    private fun getVersionCode(info: PackageInfo): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            info.longVersionCode.toInt()
        else
            info.versionCode
    }
}
