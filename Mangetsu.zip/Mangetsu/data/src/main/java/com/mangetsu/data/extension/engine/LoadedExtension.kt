package com.mangetsu.data.extension.engine

import com.mangetsu.extensionapi.MangaSource
import dalvik.system.DexClassLoader

/**
 * Represents a fully loaded extension held in the [ExtensionRegistry].
 *
 * @param packageName     Android package name of the extension APK.
 * @param source          The live [MangaSource] instance loaded from the DEX.
 * @param classLoader     The [DexClassLoader] that owns the extension's classes.
 *                        Kept here so we can release it on uninstall.
 * @param apkPath         Absolute path to the installed APK on disk.
 * @param versionCode     Extension's `versionCode` from the manifest.
 * @param versionName     Extension's `versionName` string.
 * @param lang            ISO-639-1 language code.
 * @param isNsfw          Whether the source carries adult content.
 * @param loadedAt        Epoch millis when the extension was loaded this session.
 * @param callCount       Total successful calls made to this source this session.
 * @param errorCount      Total errors returned by this source this session.
 * @param consecutiveErrors Current run of back-to-back errors (reset on success).
 *                          Used by the circuit-breaker logic in [SafeExtensionCaller].
 */
data class LoadedExtension(
    val packageName:       String,
    val source:            MangaSource,
    val classLoader:       DexClassLoader,
    val apkPath:           String,
    val versionCode:       Int,
    val versionName:       String,
    val lang:              String,
    val isNsfw:            Boolean       = false,
    val loadedAt:          Long          = System.currentTimeMillis(),
    val callCount:         Long          = 0L,
    val errorCount:        Long          = 0L,
    val consecutiveErrors: Int           = 0,
    val disabled:          Boolean       = false
) {
    val sourceId: Long get() = source.id
    val sourceName: String  get() = source.name

    /** True if the circuit-breaker has tripped for this extension. */
    val isCircuitOpen: Boolean get() = consecutiveErrors >= CIRCUIT_BREAKER_THRESHOLD

    companion object {
        /**
         * Number of consecutive errors before a source is automatically disabled
         * for the remainder of the session to protect app stability.
         */
        const val CIRCUIT_BREAKER_THRESHOLD = 5
    }
}
