package com.mangetsu.data.extension.engine

import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.SourceException
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga
import com.mangetsu.extensionapi.model.SPage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * # SafeExtensionCaller
 *
 * The single point of contact between the host app and any extension's
 * [MangaSource] implementation.
 *
 * ## Guarantees
 *
 * 1. **Error isolation** — a `Throwable` thrown inside an extension can never
 *    propagate into the host's coroutine hierarchy.  Every call is wrapped in
 *    `runCatching`, mapped to an [ExtensionResult], and logged.
 *
 * 2. **Dispatcher enforcement** — all calls run on [Dispatchers.IO] regardless
 *    of what dispatcher the caller is on.  Extensions must never be assumed
 *    to be Main-safe.
 *
 * 3. **Timeout protection** — each call is bounded by [CALL_TIMEOUT_MS].  A
 *    stalled extension cannot block the UI indefinitely.
 *
 * 4. **Circuit breaker** — after [LoadedExtension.CIRCUIT_BREAKER_THRESHOLD]
 *    consecutive errors, the extension is marked `disabled` for the session.
 *    The registry is notified via [onCircuitTripped] so it can update its state.
 *
 * 5. **Structured concurrency** — [CancellationException] is never swallowed;
 *    it is always re-thrown so Kotlin's coroutine cancellation works correctly.
 *
 * ## Usage
 *
 * ```kotlin
 * val result = caller.fetchPopularManga(loadedExt, page = 1)
 * when (result) {
 *     is ExtensionResult.Success -> render(result.data)
 *     is ExtensionResult.Error   -> showError(result.message)
 * }
 * ```
 */
@Singleton
class SafeExtensionCaller @Inject constructor() {

    companion object {
        /** Hard wall-clock timeout per extension call. */
        const val CALL_TIMEOUT_MS = 30_000L
    }

    // Callback invoked when a circuit trips — registry uses this to mark the ext disabled
    var onCircuitTripped: ((packageName: String) -> Unit)? = null
    // Callback invoked on every result — registry uses this to update counters
    var onCallResult: ((packageName: String, success: Boolean) -> Unit)? = null

    // ── Public API mirrors MangaSource ────────────────────────────────────────

    suspend fun fetchPopularManga(ext: LoadedExtension, page: Int): ExtensionResult<MangasPage> =
        call(ext, "fetchPopularManga") { it.fetchPopularManga(page) }

    suspend fun fetchLatestUpdates(ext: LoadedExtension, page: Int): ExtensionResult<MangasPage> =
        call(ext, "fetchLatestUpdates") { it.fetchLatestUpdates(page) }

    suspend fun fetchSearchManga(
        ext:     LoadedExtension,
        page:    Int,
        query:   String,
        filters: FilterList = FilterList()
    ): ExtensionResult<MangasPage> =
        call(ext, "fetchSearchManga") { it.fetchSearchManga(page, query, filters) }

    suspend fun fetchMangaDetails(ext: LoadedExtension, manga: SManga): ExtensionResult<SManga> =
        call(ext, "fetchMangaDetails") { it.fetchMangaDetails(manga) }

    suspend fun fetchChapterList(ext: LoadedExtension, manga: SManga): ExtensionResult<List<SChapter>> =
        call(ext, "fetchChapterList") { it.fetchChapterList(manga) }

    suspend fun fetchPageList(ext: LoadedExtension, chapter: SChapter): ExtensionResult<List<SPage>> =
        call(ext, "fetchPageList") { it.fetchPageList(chapter) }

    suspend fun fetchPageImageUrl(ext: LoadedExtension, page: SPage): ExtensionResult<SPage> =
        call(ext, "fetchPageImageUrl") { it.fetchPageImageUrl(page) }

    // ── Core dispatcher ───────────────────────────────────────────────────────

    /**
     * Executes [block] against [ext]'s [MangaSource] with full safety wrapping.
     */
    private suspend fun <T> call(
        ext:       LoadedExtension,
        method:    String,
        block:     suspend (MangaSource) -> T
    ): ExtensionResult<T> {

        // Circuit breaker — refuse calls to consistently broken extensions
        if (ext.isCircuitOpen) {
            Timber.w("SafeExtensionCaller: circuit OPEN for ${ext.packageName}, refusing $method")
            return ExtensionResult.Error(
                kind          = ErrorKind.SOURCE_EXCEPTION,
                message       = "${ext.sourceName} has been temporarily disabled after repeated errors.",
                sourcePackage = ext.packageName
            )
        }

        return withContext(Dispatchers.IO) {
            try {
                val result = withTimeout(CALL_TIMEOUT_MS) {
                    block(ext.source)
                }
                onCallResult?.invoke(ext.packageName, true)
                ExtensionResult.Success(result)

            } catch (e: CancellationException) {
                // NEVER swallow — propagate so structured concurrency works
                throw e

            } catch (e: TimeoutCancellationException) {
                Timber.w("SafeExtensionCaller: TIMEOUT in ${ext.packageName}.$method (${CALL_TIMEOUT_MS}ms)")
                recordError(ext.packageName)
                ExtensionResult.Error(
                    kind          = ErrorKind.TIMEOUT,
                    message       = "${ext.sourceName}.$method timed out after ${CALL_TIMEOUT_MS / 1000}s",
                    cause         = e,
                    sourcePackage = ext.packageName
                )

            } catch (e: SourceException) {
                // Extension explicitly signalled a user-facing error
                Timber.d("SafeExtensionCaller: SourceException in ${ext.packageName}.$method — ${e.message}")
                recordError(ext.packageName)
                ExtensionResult.Error(
                    kind          = ErrorKind.SOURCE_EXCEPTION,
                    message       = e.message ?: "Source error in $method",
                    cause         = e,
                    sourcePackage = ext.packageName
                )

            } catch (e: OutOfMemoryError) {
                // OOM inside an extension — log and isolate
                Timber.e("SafeExtensionCaller: OOM in ${ext.packageName}.$method")
                recordError(ext.packageName)
                ExtensionResult.Error(
                    kind          = ErrorKind.SOURCE_EXCEPTION,
                    message       = "Extension ran out of memory during $method",
                    cause         = RuntimeException("OOM wrapped", e),
                    sourcePackage = ext.packageName
                )

            } catch (e: Throwable) {
                Timber.e(e, "SafeExtensionCaller: unhandled throwable in ${ext.packageName}.$method")
                recordError(ext.packageName)
                ExtensionResult.Error(
                    kind          = ErrorKind.SOURCE_EXCEPTION,
                    message       = "${ext.sourceName} threw during $method: ${e.message}",
                    cause         = e,
                    sourcePackage = ext.packageName
                )
            }
        }
    }

    private fun recordError(packageName: String) {
        onCallResult?.invoke(packageName, false)
    }
}
