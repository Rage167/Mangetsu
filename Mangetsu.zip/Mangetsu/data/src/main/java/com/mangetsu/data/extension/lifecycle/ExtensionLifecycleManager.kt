package com.mangetsu.data.extension.lifecycle

import com.mangetsu.data.extension.engine.DexLoader
import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.data.extension.engine.ExtensionScanner
import com.mangetsu.data.extension.engine.LoadedExtension
import com.mangetsu.data.extension.registry.ExtensionRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * # ExtensionLifecycleManager
 *
 * Orchestrates the full lifecycle of extensions:
 *
 * ```
 * BOOT       → scanAndLoadAll()
 * INSTALL    → onPackageInstalled(packageName)
 * UNINSTALL  → onPackageRemoved(packageName)
 * UPDATE     → onPackageUpdated(packageName)   [= unload + reload]
 * ```
 *
 * ## Supervision
 * Uses a [SupervisorJob] so that a failure loading *one* extension does not
 * cancel the loading of the rest.  Each load is an independent child job.
 *
 * ## Events
 * Callers can observe [events] (a [SharedFlow]) to react to lifecycle changes
 * without polling.
 */
@Singleton
class ExtensionLifecycleManager @Inject constructor(
    private val scanner:  ExtensionScanner,
    private val loader:   DexLoader,
    private val registry: ExtensionRegistry
) {

    // Dedicated scope so loading survives the calling ViewModel's scope
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ── Events ────────────────────────────────────────────────────────────────

    sealed class LifecycleEvent {
        data class Loaded(val ext: LoadedExtension)         : LifecycleEvent()
        data class LoadFailed(val packageName: String,
                              val reason: String)           : LifecycleEvent()
        data class Unloaded(val packageName: String)        : LifecycleEvent()
        data class Updated(val ext: LoadedExtension)        : LifecycleEvent()
        data object ScanComplete                            : LifecycleEvent()
    }

    private val _events = MutableSharedFlow<LifecycleEvent>(extraBufferCapacity = 32)
    val events: SharedFlow<LifecycleEvent> = _events.asSharedFlow()

    // ── Boot: scan and load everything ────────────────────────────────────────

    /**
     * Scans all installed packages for extension APKs and loads them concurrently.
     * Should be called once from [MangetsuApp.onCreate] on a background dispatcher.
     *
     * Individual load failures are isolated — one broken extension does not
     * prevent the others from loading.
     */
    suspend fun scanAndLoadAll() = withContext(Dispatchers.IO) {
        registry.initialise()

        val candidates = scanner.scanInstalledExtensions()
        Timber.i("LifecycleManager: scanning ${candidates.size} candidate(s)…")

        // Launch each load as a supervised child — failures are independent
        val jobs = candidates.map { candidate ->
            scope.launch {
                loadSingle(candidate.packageName, candidate.apkPath)
            }
        }
        jobs.forEach { it.join() }

        _events.emit(LifecycleEvent.ScanComplete)
        Timber.i("LifecycleManager: scan complete — ${registry.getAllExtensions().size} loaded")
    }

    // ── Runtime events from PackageReceiver ───────────────────────────────────

    /**
     * Called when Android reports a new package has been installed.
     * Validates + loads the extension if it carries the extension marker.
     */
    fun onPackageInstalled(packageName: String) {
        scope.launch {
            Timber.d("LifecycleManager: package installed — $packageName")
            val candidate = scanner.getCandidateForPackage(packageName) ?: run {
                Timber.d("LifecycleManager: $packageName is not an extension — ignoring")
                return@launch
            }
            loadSingle(candidate.packageName, candidate.apkPath)
        }
    }

    /**
     * Called when Android reports a package has been removed.
     * Unregisters the extension and cleans up its optimised DEX.
     */
    fun onPackageRemoved(packageName: String) {
        scope.launch {
            Timber.d("LifecycleManager: package removed — $packageName")
            unloadSingle(packageName)
        }
    }

    /**
     * Called when Android reports a package has been updated.
     * Performs an atomic unload → reload so the registry is never empty
     * for this source during the swap.
     */
    fun onPackageUpdated(packageName: String) {
        scope.launch {
            Timber.d("LifecycleManager: package updated — $packageName")
            // Unload old version first
            registry.unregister(packageName)
            loader.cleanupOdex(packageName)

            // Re-scan to get the new APK path (it may have changed)
            val candidate = scanner.getCandidateForPackage(packageName) ?: run {
                Timber.w("LifecycleManager: updated package $packageName no longer an extension")
                _events.emit(LifecycleEvent.Unloaded(packageName))
                return@launch
            }
            loadSingle(candidate.packageName, candidate.apkPath)
            Timber.i("LifecycleManager: reloaded $packageName after update")
        }
    }

    /**
     * Forces a reload of a specific extension without waiting for a system event.
     * Useful after the user manually taps "Reload" in Settings.
     */
    suspend fun forceReload(packageName: String): ExtensionResult<LoadedExtension> {
        registry.unregister(packageName)
        loader.cleanupOdex(packageName)

        val candidate = scanner.getCandidateForPackage(packageName)
            ?: return ExtensionResult.Error(
                kind    = com.mangetsu.data.extension.engine.ErrorKind.SOURCE_NOT_FOUND,
                message = "$packageName is not installed or not an extension"
            )

        return loadSingleReturning(candidate.packageName, candidate.apkPath)
    }

    /**
     * Resets the circuit breaker for a specific extension and attempts to reload it.
     */
    suspend fun resetAndReload(packageName: String): ExtensionResult<LoadedExtension> {
        registry.resetCircuit(packageName)
        return forceReload(packageName)
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private suspend fun loadSingle(packageName: String, apkPath: String) {
        when (val result = loader.load(apkPath, packageName)) {
            is ExtensionResult.Success -> {
                registry.register(result.data)
                _events.emit(LifecycleEvent.Loaded(result.data))
            }
            is ExtensionResult.Error -> {
                Timber.e("LifecycleManager: failed to load $packageName — ${result.message}")
                _events.emit(LifecycleEvent.LoadFailed(packageName, result.message))
            }
        }
    }

    private suspend fun loadSingleReturning(
        packageName: String,
        apkPath:     String
    ): ExtensionResult<LoadedExtension> {
        return when (val result = loader.load(apkPath, packageName)) {
            is ExtensionResult.Success -> {
                registry.register(result.data)
                _events.emit(LifecycleEvent.Loaded(result.data))
                result
            }
            is ExtensionResult.Error -> {
                _events.emit(LifecycleEvent.LoadFailed(packageName, result.message))
                result
            }
        }
    }

    private suspend fun unloadSingle(packageName: String) {
        registry.unregister(packageName)
        loader.cleanupOdex(packageName)
        _events.emit(LifecycleEvent.Unloaded(packageName))
    }
}
