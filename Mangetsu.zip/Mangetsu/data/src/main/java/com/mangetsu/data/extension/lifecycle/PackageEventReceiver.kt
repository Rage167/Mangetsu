package com.mangetsu.data.extension.lifecycle

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import javax.inject.Inject

/**
 * Listens for Android package-manager broadcasts and forwards them to
 * [ExtensionLifecycleManager] so extensions are loaded/unloaded automatically.
 *
 * ## Registered dynamically (not in manifest)
 * Package-replace and package-add intents with `data` scheme must be registered
 * dynamically since Android 8 deprecated manifest-declared receivers for these
 * implicit broadcasts.
 *
 * Register this receiver in [MangetsuApp.onCreate] via [register].
 */
@AndroidEntryPoint
class PackageEventReceiver : BroadcastReceiver() {

    @Inject
    lateinit var lifecycleManager: ExtensionLifecycleManager

    override fun onReceive(context: Context, intent: Intent) {
        val packageName = intent.data?.schemeSpecificPart ?: run {
            Timber.w("PackageEventReceiver: received intent with null data — $intent")
            return
        }

        Timber.d("PackageEventReceiver: ${intent.action} → $packageName")

        when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED -> {
                // ACTION_PACKAGE_ADDED fires for both fresh installs AND updates on older APIs
                val replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
                if (replacing) {
                    lifecycleManager.onPackageUpdated(packageName)
                } else {
                    lifecycleManager.onPackageInstalled(packageName)
                }
            }
            Intent.ACTION_PACKAGE_REPLACED -> {
                // Fired specifically for updates on API 21+
                lifecycleManager.onPackageUpdated(packageName)
            }
            Intent.ACTION_PACKAGE_REMOVED -> {
                val replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
                if (!replacing) {
                    // Only a real removal — not an update step
                    lifecycleManager.onPackageRemoved(packageName)
                }
            }
            else -> Timber.d("PackageEventReceiver: unhandled action ${intent.action}")
        }
    }

    companion object {

        /**
         * Builds the correct [IntentFilter] for package lifecycle events.
         * The `data` scheme filter is required for package intents.
         */
        fun buildIntentFilter(): IntentFilter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }

        /**
         * Registers [receiver] with [context] using the correct flags for the
         * running API level.
         */
        fun register(receiver: PackageEventReceiver, context: Context) {
            val filter = buildIntentFilter()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
            Timber.d("PackageEventReceiver: registered")
        }
    }
}
