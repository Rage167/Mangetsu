package com.mangetsu.data.extension.registry

import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.data.extension.engine.LoadedExtension
import com.mangetsu.data.extension.engine.SafeExtensionCaller
import com.mangetsu.extensionapi.MangaSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * # ExtensionRegistry
 *
 * The single authoritative source of truth for all loaded extensions in the
 * current process lifetime.
 *
 * ## Thread safety
 * All mutating operations use a [Mutex] so they are safe to call from any
 * coroutine.  Read operations on the snapshot maps are lock-free (copy-on-write
 * via immutable maps inside a [MutableStateFlow]).
 *
 * ## Data model
 * Two indices are maintained for O(1) lookups:
 * - `byPackage`  :  packageName → [LoadedExtension]
 * - `bySourceId` :  sourceId    → [LoadedExtension]
 *
 * ## Circuit-breaker integration
 * [SafeExtensionCaller] notifies the registry of every call result via callbacks
 * set during [initialise].  The registry increments/resets counters and
 * flips `disabled = true` when the threshold is crossed.
 */
@Singleton
class ExtensionRegistry @Inject constructor(
    private val caller: SafeExtensionCaller
) {

    // ── Internal state ────────────────────────────────────────────────────────

    private val mutex = Mutex()

    data class RegistrySnapshot(
        val byPackage:  Map<String, LoadedExtension> = emptyMap(),
        val bySourceId: Map<Long,   LoadedExtension> = emptyMap()
    ) {
        val all: List<LoadedExtension> get() = byPackage.values.toList()
        val active: List<LoadedExtension> get() = all.filter { !it.disabled && !it.isCircuitOpen }
    }

    private val _state = MutableStateFlow(RegistrySnapshot())

    /** Observable snapshot — UI layers can collect this to react to installs. */
    val state: StateFlow<RegistrySnapshot> = _state.asStateFlow()

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Wire up the [SafeExtensionCaller] callbacks.  Call once at app startup,
     * before any extensions are registered.
     */
    fun initialise() {
        caller.onCallResult = { packageName, success ->
            updateCounters(packageName, success)
        }
        caller.onCircuitTripped = { packageName ->
            Timber.w("Registry: circuit tripped for $packageName")
        }
    }

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Adds a successfully loaded extension to both indices.
     * If an extension with the same package is already registered it is replaced
     * (covers the hot-reload / update path).
     */
    suspend fun register(ext: LoadedExtension) = mutex.withLock {
        Timber.d("Registry: registering ${ext.packageName} (sourceId=${ext.sourceId})")
        _state.update { snap ->
            snap.copy(
                byPackage  = snap.byPackage  + (ext.packageName to ext),
                bySourceId = snap.bySourceId + (ext.sourceId    to ext)
            )
        }
    }

    /**
     * Removes an extension from both indices.
     * Safe to call even if the extension is not currently registered.
     */
    suspend fun unregister(packageName: String) = mutex.withLock {
        val ext = _state.value.byPackage[packageName] ?: return@withLock
        Timber.d("Registry: unregistering ${ext.packageName}")
        _state.update { snap ->
            snap.copy(
                byPackage  = snap.byPackage  - ext.packageName,
                bySourceId = snap.bySourceId - ext.sourceId
            )
        }
    }

    // ── Queries (lock-free, reads from snapshot) ──────────────────────────────

    /** All registered extensions, including disabled ones. */
    fun getAllExtensions(): List<LoadedExtension> = _state.value.all

    /** Only extensions whose circuit is closed (active and healthy). */
    fun getActiveExtensions(): List<LoadedExtension> = _state.value.active

    /** All [MangaSource] instances, one per active extension. */
    fun getAllSources(): List<MangaSource> = getActiveExtensions().map { it.source }

    /**
     * Returns the [MangaSource] for the given [sourceId], or null if
     * not registered or if the extension's circuit is open.
     */
    fun getSourceById(sourceId: Long): MangaSource? =
        _state.value.bySourceId[sourceId]
            ?.takeIf { !it.disabled && !it.isCircuitOpen }
            ?.source

    /** Returns the full [LoadedExtension] record by package name. */
    fun getExtensionByPackage(packageName: String): LoadedExtension? =
        _state.value.byPackage[packageName]

    /** Returns the full [LoadedExtension] record by source ID. */
    fun getExtensionBySourceId(sourceId: Long): LoadedExtension? =
        _state.value.bySourceId[sourceId]

    /** Returns true if [packageName] is currently registered and active. */
    fun isLoaded(packageName: String): Boolean =
        _state.value.byPackage[packageName]?.let { !it.disabled } ?: false

    // ── Stats & circuit-breaker ───────────────────────────────────────────────

    /** Returns per-extension call statistics for the Settings / debug screen. */
    fun getStats(): List<ExtensionStats> = _state.value.all.map { ext ->
        ExtensionStats(
            packageName        = ext.packageName,
            sourceName         = ext.sourceName,
            callCount          = ext.callCount,
            errorCount         = ext.errorCount,
            consecutiveErrors  = ext.consecutiveErrors,
            circuitOpen        = ext.isCircuitOpen,
            disabled           = ext.disabled,
            loadedAt           = ext.loadedAt
        )
    }

    /**
     * Manually re-enable a disabled / circuit-open extension.
     * The caller is responsible for deciding if this is safe.
     */
    suspend fun resetCircuit(packageName: String) = mutex.withLock {
        updateExtension(packageName) { it.copy(consecutiveErrors = 0, disabled = false) }
        Timber.i("Registry: circuit manually reset for $packageName")
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private fun updateCounters(packageName: String, success: Boolean) {
        val snap = _state.value
        val ext  = snap.byPackage[packageName] ?: return

        val updated = if (success) {
            ext.copy(
                callCount         = ext.callCount + 1,
                consecutiveErrors = 0
            )
        } else {
            val newConsecutive = ext.consecutiveErrors + 1
            val tripped        = newConsecutive >= LoadedExtension.CIRCUIT_BREAKER_THRESHOLD
            if (tripped) {
                Timber.e("Registry: ⚡ circuit tripped for ${ext.packageName} after $newConsecutive consecutive errors")
                caller.onCircuitTripped?.invoke(packageName)
            }
            ext.copy(
                callCount         = ext.callCount + 1,
                errorCount        = ext.errorCount + 1,
                consecutiveErrors = newConsecutive,
                disabled          = tripped
            )
        }

        _state.value = snap.copy(
            byPackage  = snap.byPackage  + (packageName   to updated),
            bySourceId = snap.bySourceId + (updated.sourceId to updated)
        )
    }

    private fun updateExtension(packageName: String, transform: (LoadedExtension) -> LoadedExtension) {
        val snap = _state.value
        val ext  = snap.byPackage[packageName] ?: return
        val updated = transform(ext)
        _state.value = snap.copy(
            byPackage  = snap.byPackage  + (packageName      to updated),
            bySourceId = snap.bySourceId + (updated.sourceId to updated)
        )
    }
}

// ── Public stats model ────────────────────────────────────────────────────────

data class ExtensionStats(
    val packageName:       String,
    val sourceName:        String,
    val callCount:         Long,
    val errorCount:        Long,
    val consecutiveErrors: Int,
    val circuitOpen:       Boolean,
    val disabled:          Boolean,
    val loadedAt:          Long
) {
    val successRate: Float
        get() = if (callCount == 0L) 1f else (callCount - errorCount).toFloat() / callCount
}
