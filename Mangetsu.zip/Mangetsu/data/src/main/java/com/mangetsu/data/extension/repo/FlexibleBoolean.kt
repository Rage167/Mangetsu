package com.mangetsu.data.extension.repo

import com.squareup.moshi.JsonQualifier

/**
 * Moshi [JsonQualifier] that opts a [Boolean?] field into [FlexibleBooleanAdapter].
 *
 * Applying this qualifier to a field means the adapter will accept:
 *   - JSON booleans (`true`/`false`)
 *   - Integers (`0`/`1`)
 *   - Floating-point numbers (`0.0`/`1.0`)
 *   - Strings (`"true"`, `"false"`, `"1"`, `"0"`, `"yes"`, `"no"`)
 *   - `null`
 *
 * Using a qualifier (rather than registering globally) ensures this tolerant
 * parsing applies **only** to annotated fields, leaving all other [Boolean]
 * fields in the app with strict, standard parsing.
 *
 * Usage:
 * ```kotlin
 * @Json(name = "nsfw") @FlexibleBoolean val isNsfw: Boolean?
 * ```
 */
@Retention(AnnotationRetention.RUNTIME)
@JsonQualifier
annotation class FlexibleBoolean
