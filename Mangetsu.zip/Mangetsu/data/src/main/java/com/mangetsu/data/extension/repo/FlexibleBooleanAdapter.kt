package com.mangetsu.data.extension.repo

import com.squareup.moshi.FromJson
import com.squareup.moshi.JsonDataException
import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import com.squareup.moshi.ToJson
import timber.log.Timber

/**
 * Moshi adapter for [Boolean?] fields annotated with [@FlexibleBoolean][FlexibleBoolean].
 *
 * Scoped via a [@JsonQualifier][com.squareup.moshi.JsonQualifier] so it only
 * activates for explicitly opted-in fields, leaving all other Boolean parsing
 * in the app unaffected.
 *
 * Handled input types:
 *
 * | JSON token  | Value(s)                    | Result         |
 * |-------------|-----------------------------|----------------|
 * | Boolean     | `true` / `false`            | as-is          |
 * | Number      | `0` / `1` / `0.0` / `1.0`  | 0 → false, ≠0 → true |
 * | String      | `"true"/"1"/"yes"`          | true           |
 * | String      | `"false"/"0"/"no"`          | false          |
 * | String      | anything else               | false + warning|
 * | null        | —                           | null           |
 * | other token | —                           | null + warning |
 *
 * Register this adapter **before** [KotlinJsonAdapterFactory][com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory]:
 * ```kotlin
 * Moshi.Builder()
 *     .add(FlexibleBooleanAdapter())
 *     .addLast(KotlinJsonAdapterFactory())
 *     .build()
 * ```
 */
class FlexibleBooleanAdapter {

    @FromJson
    @FlexibleBoolean
    fun fromJson(reader: JsonReader): Boolean? {
        return when (val token = reader.peek()) {

            JsonReader.Token.BOOLEAN -> reader.nextBoolean()

            JsonReader.Token.NUMBER -> {
                // Use nextDouble() rather than nextInt() so values like 1.0 / 0.0
                // (valid JSON that some repo generators emit) don't throw.
                val raw = try {
                    reader.nextDouble()
                } catch (e: JsonDataException) {
                    Timber.w("FlexibleBooleanAdapter: could not read number as double — defaulting to false")
                    reader.skipValue()
                    return false
                }
                // IEEE 754: NaN != 0.0 is TRUE, which would silently mark safe
                // extensions as NSFW. Treat NaN as false explicitly.
                if (raw.isNaN()) {
                    Timber.w("FlexibleBooleanAdapter: NaN for @FlexibleBoolean field — defaulting to false")
                    return false
                }
                val result = raw != 0.0
                if (raw != 0.0 && raw != 1.0) {
                    Timber.w("FlexibleBooleanAdapter: unexpected numeric boolean $raw — treating as $result")
                }
                result
            }

            JsonReader.Token.NULL -> {
                reader.nextNull<Unit>()
                null
            }

            JsonReader.Token.STRING -> {
                val s = reader.nextString().trim().lowercase()
                when (s) {
                    "true",  "1", "yes" -> true
                    "false", "0", "no"  -> false
                    else -> {
                        Timber.w("FlexibleBooleanAdapter: unrecognised string boolean \"$s\" — defaulting to false")
                        false
                    }
                }
            }

            else -> {
                Timber.w("FlexibleBooleanAdapter: unexpected token $token for @FlexibleBoolean field — defaulting to null")
                reader.skipValue()
                null
            }
        }
    }

    @ToJson
    fun toJson(writer: JsonWriter, @FlexibleBoolean value: Boolean?) {
        if (value == null) writer.nullValue() else writer.value(value)
    }
}
