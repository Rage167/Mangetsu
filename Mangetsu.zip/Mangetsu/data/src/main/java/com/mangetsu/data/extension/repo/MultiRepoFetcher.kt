package com.mangetsu.data.extension.repo

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fetches index JSON from multiple repository URLs concurrently.
 *
 * **Features**
 * - Parallel fetching — all repos fetched concurrently via coroutines
 * - Per-repo isolation — one failure never blocks or crashes others
 * - TTL-aware caching — returns cached data when fresh, hits network otherwise
 * - Offline fallback — returns stale cache when network is unavailable
 * - Deterministic dedup — same package across repos → highest versionCode wins;
 *   ties broken by repo order (earlier-added repo takes precedence)
 * - Response body always closed — no OkHttp connection leaks
 * - Safe URL normalisation — handles bare base URLs and direct .json links
 * - Redirect-following HEAD probe — works with CDNs and GitHub raw links
 */
@Singleton
class MultiRepoFetcher @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val cache:        RepoCache,
    private val parser:       RepoIndexParser
) {
    companion object {
        private const val USER_AGENT = "Mangetsu/1.0 (Android; repo-fetcher)"

        /**
         * Index file names tried in order when the user provides a bare base URL.
         * Tachiyomi/Keiyoushi uses `index.min.json`; Mangetsu-native repos use `index.json`.
         */
        private val INDEX_CANDIDATES = listOf("index.min.json", "index.json")

        /** Maximum response body size accepted (bytes). Guards against oversized payloads. */
        private const val MAX_BODY_BYTES = 10 * 1024 * 1024 // 10 MB
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Fetches all [repoUrls] concurrently and returns a merged, deduplicated result.
     */
    suspend fun fetchAll(
        repoUrls:     List<String>,
        forceRefresh: Boolean = false
    ): MultiRepoResult = withContext(Dispatchers.IO) {
        if (repoUrls.isEmpty()) {
            return@withContext MultiRepoResult(perRepo = emptyList(), merged = emptyList())
        }

        val perRepo: List<RepoFetchResult> = repoUrls
            .map { url -> async { fetchSingle(url.trim(), forceRefresh) } }
            .awaitAll()

        val successes = perRepo.filterIsInstance<RepoFetchResult.Success>()
        val merged    = mergeAndDeduplicate(successes)

        val failCount = perRepo.count { it is RepoFetchResult.Failure }
        if (failCount > 0) {
            val reasons = perRepo
                .filterIsInstance<RepoFetchResult.Failure>()
                .joinToString { "${it.repoUrl.substringAfterLast('/').take(30)}: ${it.message.take(60)}" }
            Timber.w("MultiRepoFetcher: %d/%d repos failed — %s", failCount, perRepo.size, reasons)
        }

        Timber.i(
            "MultiRepoFetcher: %d/%d repos OK, %d unique extensions after dedup",
            successes.size, perRepo.size, merged.size
        )

        MultiRepoResult(perRepo = perRepo, merged = merged)
    }

    /**
     * Fetches a single repo. Serves from fresh cache when available.
     * On any network/parse failure the stale cache is returned as offline fallback.
     */
    suspend fun fetchSingle(
        repoUrl:      String,
        forceRefresh: Boolean = false
    ): RepoFetchResult = withContext(Dispatchers.IO) {
        val normUrl = normaliseUrl(repoUrl)

        // 1 — Serve from fresh cache (single atomic read — eliminates TOCTOU race
        //     that existed between the old isFresh() + get() double-read pattern).
        if (!forceRefresh) {
            val fresh = cache.getFreshOrNull(repoUrl)
            if (fresh != null) {
                Timber.d("MultiRepoFetcher: cache HIT for %s (%d entries)", repoUrl, fresh.size)
                return@withContext RepoFetchResult.Success(repoUrl, fresh)
            }
        }

        // 2 — Attempt network fetch
        val networkResult = tryFetchFromNetwork(repoUrl, normUrl)

        // 3 — Offline fallback: stale cache on any failure
        if (networkResult is RepoFetchResult.Failure) {
            val stale = cache.get(repoUrl)
            if (!stale.isNullOrEmpty()) {
                Timber.w(
                    "MultiRepoFetcher: network failed for %s (%s) — offline fallback, " +
                        "stale cache %s old, %d entries",
                    repoUrl, networkResult.message, ageDescription(repoUrl), stale.size
                )
                return@withContext RepoFetchResult.Success(repoUrl, stale)
            }
        }

        networkResult
    }

    /**
     * Checks whether [url] resolves to a reachable index file.
     *
     * - Direct `.json` URL  → probed as-is.
     * - Bare base URL       → [INDEX_CANDIDATES] probed in order; first HTTP-2xx wins.
     */
    suspend fun validateUrl(url: String): UrlValidationResult = withContext(Dispatchers.IO) {
        val trimmed = url.trim().trimEnd('/')

        if (trimmed.endsWith(".json", ignoreCase = true)) {
            return@withContext probeUrl(trimmed)
        }

        for (candidate in INDEX_CANDIDATES) {
            val probe = "$trimmed/$candidate"
            val result = probeUrl(probe)
            if (result is UrlValidationResult.Valid) {
                Timber.d("MultiRepoFetcher: validated %s → %s", url, probe)
                return@withContext result
            }
        }

        UrlValidationResult.Invalid(
            "No index file found at $trimmed (tried: ${INDEX_CANDIDATES.joinToString()})"
        )
    }

    // ── Network ───────────────────────────────────────────────────────────────

    private fun tryFetchFromNetwork(repoUrl: String, indexUrl: String): RepoFetchResult {
        return try {
            val request = Request.Builder()
                .url(indexUrl)
                .header("Accept",        "application/json, */*")
                .header("Cache-Control", "no-cache")
                .header("User-Agent",    USER_AGENT)
                .build()

            val response = okHttpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                response.close()
                return RepoFetchResult.Failure(
                    repoUrl = repoUrl,
                    reason  = FailureReason.HTTP_ERROR,
                    message = "HTTP ${response.code} from $indexUrl"
                )
            }

            // Always use `use {}` so the body is closed even on exception paths.
            val body: String? = response.body?.use { body ->
                // Read via Okio source so we cap ACTUAL bytes consumed, not just the
                // declared Content-Length header (which is -1 for chunked/gzip responses
                // — making the old contentLength() check effectively dead code).
                val source = body.source()
                val buffer = okio.Buffer()
                val bytesRead = source.read(buffer, (MAX_BODY_BYTES + 1).toLong())
                if (bytesRead > MAX_BODY_BYTES) {
                    Timber.w(
                        "MultiRepoFetcher: response from %s exceeds %d bytes — skipping",
                        indexUrl, MAX_BODY_BYTES
                    )
                    return RepoFetchResult.Failure(
                        repoUrl = repoUrl,
                        reason  = FailureReason.MALFORMED_JSON,
                        message = "Response too large (>${MAX_BODY_BYTES} bytes) from $indexUrl"
                    )
                }
                buffer.readString(Charsets.UTF_8)
            }

            if (body.isNullOrBlank()) {
                return RepoFetchResult.Failure(
                    repoUrl = repoUrl,
                    reason  = FailureReason.EMPTY_RESPONSE,
                    message = "Empty response body from $indexUrl"
                )
            }

            when (val parsed = parser.parse(body, repoUrl)) {
                is ParseResult.Success -> {
                    // Log a warning when recovery mode was active so operators
                    // can identify repos with structurally corrupt index files.
                    if (parsed.wasRecovered) {
                        Timber.w(
                            "MultiRepoFetcher: partial recovery for %s — %d entries OK, " +
                            "%d failed. First errors: [%s]",
                            repoUrl, parsed.entries.size, parsed.recoveredEntries,
                            parsed.parseErrors.joinToString(" | ")
                        )
                    } else {
                        Timber.d(
                            "MultiRepoFetcher: fetched %d entries from %s",
                            parsed.entries.size, indexUrl
                        )
                    }
                    cache.put(repoUrl, parsed.entries)
                    RepoFetchResult.Success(repoUrl, parsed.entries)
                }
                is ParseResult.Failure -> {
                    Timber.w(
                        "MultiRepoFetcher: parse failure for %s: %s",
                        repoUrl, parsed.message
                    )
                    RepoFetchResult.Failure(repoUrl = repoUrl, reason = parsed.reason, message = parsed.message)
                }
            }
        } catch (e: SocketTimeoutException) {
            RepoFetchResult.Failure(repoUrl, FailureReason.TIMEOUT,       "Request timed out for $indexUrl")
        } catch (e: UnknownHostException) {
            RepoFetchResult.Failure(repoUrl, FailureReason.NETWORK_ERROR, "Host unreachable: ${e.message}")
        } catch (e: IOException) {
            RepoFetchResult.Failure(repoUrl, FailureReason.NETWORK_ERROR, "I/O error: ${e.message}")
        } catch (e: IllegalArgumentException) {
            // OkHttp throws this for malformed URLs
            RepoFetchResult.Failure(repoUrl, FailureReason.INVALID_URL,   "Malformed URL: $indexUrl — ${e.message}")
        } catch (e: Exception) {
            Timber.e(e, "MultiRepoFetcher: unexpected error fetching %s", indexUrl)
            RepoFetchResult.Failure(repoUrl, FailureReason.NETWORK_ERROR, "Unexpected: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /**
     * Issues a HEAD request to [url] to check reachability.
     * Explicitly closes the response to prevent connection leaks.
     */
    private fun probeUrl(url: String): UrlValidationResult {
        return try {
            val request = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", USER_AGENT)
                .build()
            okHttpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) UrlValidationResult.Valid(url)
                else UrlValidationResult.Invalid("HTTP ${response.code} from $url")
            }
        } catch (e: UnknownHostException) {
            UrlValidationResult.Invalid("Cannot reach host: ${e.message}")
        } catch (e: SocketTimeoutException) {
            UrlValidationResult.Invalid("Connection timed out: $url")
        } catch (e: IllegalArgumentException) {
            UrlValidationResult.Invalid("Malformed URL: $url")
        } catch (e: Exception) {
            UrlValidationResult.Invalid("${e.javaClass.simpleName}: ${e.message ?: "unknown error"}")
        }
    }

    // ── Deduplication ─────────────────────────────────────────────────────────

    /**
     * Merges entries from multiple successful repo fetches into a single list.
     *
     * **Deduplication rule:** same `packageName` → keep entry with highest `versionCode`.
     * **Tie-break:** first repo in [results] order wins (preserves user-defined repo priority).
     *
     * Single-pass O(N total entries) with pre-sized [LinkedHashMap] to minimise allocations.
     */
    private fun mergeAndDeduplicate(results: List<RepoFetchResult.Success>): List<RepoIndexEntry> {
        if (results.isEmpty()) return emptyList()
        if (results.size == 1) return results.first().entries  // fast path

        val estimatedTotal = results.sumOf { it.entries.size }
        val byPackage = LinkedHashMap<String, RepoIndexEntry>(estimatedTotal * 4 / 3 + 1)

        for (result in results) {
            for (entry in result.entries) {
                val existing = byPackage[entry.packageName]
                if (existing == null || entry.versionCode > existing.versionCode) {
                    byPackage[entry.packageName] = entry
                }
                // Equal versionCode: first-seen (earlier repo) wins — no update needed
            }
        }

        // byPackage.values preserves LinkedHashMap insertion order (stable, deterministic).
        // Wrapping in ArrayList avoids the intermediate view copy that toList() creates.
        return ArrayList(byPackage.values)
    }

    // ── URL normalisation ─────────────────────────────────────────────────────

    /**
     * Resolves the index JSON URL from a user-supplied repo URL.
     *
     * - Ends with `.json`  → used as-is (direct index.min.json or index.json link)
     * - Bare base URL      → [INDEX_CANDIDATES] probed in order; first 2xx wins.
     *   Falls back to the first candidate if no probe succeeds (e.g. offline),
     *   mirroring [validateUrl]'s resolution logic so the two never disagree.
     */
    private fun normaliseUrl(url: String): String {
        val trimmed = url.trim().trimEnd('/')
        if (trimmed.endsWith(".json", ignoreCase = true)) return trimmed
        // Mirror validateUrl's candidate-probing so a repo that only serves
        // index.json (not index.min.json) doesn't pass validation then 404 on fetch.
        for (candidate in INDEX_CANDIDATES) {
            val probe = "$trimmed/$candidate"
            if (probeUrl(probe) is UrlValidationResult.Valid) return probe
        }
        return "$trimmed/${INDEX_CANDIDATES.first()}" // best-effort offline fallback
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun ageDescription(repoUrl: String): String {
        val at = cache.lastFetchedAt(repoUrl) ?: return "unknown age"
        val ms = System.currentTimeMillis() - at
        return "${ms / 3_600_000}h${(ms % 3_600_000) / 60_000}m"
    }
}

// ── Result types ──────────────────────────────────────────────────────────────

data class MultiRepoResult(
    val perRepo: List<RepoFetchResult>,
    val merged:  List<RepoIndexEntry>
) {
    val successCount: Int get() = perRepo.count { it is RepoFetchResult.Success }
    val failureCount: Int get() = perRepo.count { it is RepoFetchResult.Failure }
    val failures: List<RepoFetchResult.Failure>
        get() = perRepo.filterIsInstance<RepoFetchResult.Failure>()
}

sealed class UrlValidationResult {
    data class Valid(val normalisedUrl: String) : UrlValidationResult()
    data class Invalid(val reason: String)      : UrlValidationResult()
}
