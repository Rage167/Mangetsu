package com.mangetsu.data.extension.repo

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fetches index.json from multiple repository URLs concurrently.
 *
 * Features:
 * - Parallel fetching via coroutines
 * - Per-repo error isolation (one failure doesn't block others)
 * - TTL-aware caching via [RepoCache]
 * - Strict JSON validation via [RepoIndexParser]
 * - Deduplication: same package from multiple repos → highest versionCode wins
 * - Offline fallback: if network fails, returns stale cache
 */
@Singleton
class MultiRepoFetcher @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val cache:        RepoCache,
    private val parser:       RepoIndexParser
) {
    companion object {
        private const val CONNECT_TIMEOUT_MS = 15_000L
        private const val READ_TIMEOUT_MS    = 20_000L
    }

    /**
     * Fetches all [repoUrls] concurrently.
     *
     * @param repoUrls       List of base repo URLs.
     * @param forceRefresh   If true, bypasses TTL and always hits the network.
     * @return [MultiRepoResult] containing per-repo outcomes and the merged list.
     */
    suspend fun fetchAll(
        repoUrls:     List<String>,
        forceRefresh: Boolean = false
    ): MultiRepoResult = withContext(Dispatchers.IO) {

        if (repoUrls.isEmpty()) {
            return@withContext MultiRepoResult(
                perRepo = emptyList(),
                merged  = emptyList()
            )
        }

        // Fetch all repos in parallel; each async block is independent
        val perRepo: List<RepoFetchResult> = repoUrls
            .map { url ->
                async {
                    fetchSingle(url.trim(), forceRefresh)
                }
            }
            .awaitAll()

        val merged = mergeAndDeduplicate(perRepo.filterIsInstance<RepoFetchResult.Success>())

        Timber.i("MultiRepoFetcher: ${perRepo.count { it is RepoFetchResult.Success }} succeeded, " +
            "${perRepo.count { it is RepoFetchResult.Failure }} failed, " +
            "${merged.size} unique entries after merge")

        MultiRepoResult(perRepo = perRepo, merged = merged)
    }

    /**
     * Fetches a single [repoUrl], using cache if fresh, with offline fallback.
     */
    suspend fun fetchSingle(
        repoUrl:      String,
        forceRefresh: Boolean = false
    ): RepoFetchResult = withContext(Dispatchers.IO) {

        // 1 — Return cache if fresh and not forced
        if (!forceRefresh && cache.isFresh(repoUrl)) {
            val cached = cache.get(repoUrl)
            if (!cached.isNullOrEmpty()) {
                Timber.d("MultiRepoFetcher: cache HIT (fresh) for $repoUrl")
                return@withContext RepoFetchResult.Success(repoUrl, cached)
            }
        }

        // 2 — Try network
        val networkResult = tryFetchFromNetwork(repoUrl)

        // 3 — On network failure, try stale cache as offline fallback
        if (networkResult is RepoFetchResult.Failure) {
            val stale = cache.get(repoUrl)
            if (!stale.isNullOrEmpty()) {
                Timber.w("MultiRepoFetcher: network failed for $repoUrl — using stale cache " +
                    "(age=${ageDescription(repoUrl)})")
                return@withContext RepoFetchResult.Success(repoUrl, stale)
            }
        }

        networkResult
    }

    /**
     * Validates [url] is reachable and returns an HTTP 2xx. Cheap HEAD request.
     */
    suspend fun validateUrl(url: String): UrlValidationResult = withContext(Dispatchers.IO) {
        val normalised = normaliseUrl(url)
        try {
            val request = Request.Builder().url(normalised).head().build()
            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                UrlValidationResult.Valid(normalised)
            } else {
                UrlValidationResult.Invalid("HTTP ${response.code} from $normalised")
            }
        } catch (e: UnknownHostException) {
            UrlValidationResult.Invalid("Cannot reach host: ${e.message}")
        } catch (e: SocketTimeoutException) {
            UrlValidationResult.Invalid("Connection timed out")
        } catch (e: Exception) {
            UrlValidationResult.Invalid(e.message ?: "Unknown network error")
        }
    }

    // ── Private ───────────────────────────────────────────────────────────────

    private fun tryFetchFromNetwork(repoUrl: String): RepoFetchResult {
        val indexUrl = normaliseUrl(repoUrl)
        return try {
            val request = Request.Builder()
                .url(indexUrl)
                .header("Accept", "application/json")
                .header("Cache-Control", "no-cache")
                .build()

            val response = okHttpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                return RepoFetchResult.Failure(
                    repoUrl = repoUrl,
                    reason  = FailureReason.HTTP_ERROR,
                    message = "HTTP ${response.code} from $indexUrl"
                )
            }

            val body = response.body?.string()
            if (body.isNullOrBlank()) {
                return RepoFetchResult.Failure(
                    repoUrl = repoUrl,
                    reason  = FailureReason.EMPTY_RESPONSE,
                    message = "Empty response body from $indexUrl"
                )
            }

            when (val parsed = parser.parse(body, repoUrl)) {
                is ParseResult.Success -> {
                    cache.put(repoUrl, parsed.entries)
                    RepoFetchResult.Success(repoUrl, parsed.entries)
                }
                is ParseResult.Failure -> RepoFetchResult.Failure(
                    repoUrl = repoUrl,
                    reason  = parsed.reason,
                    message = parsed.message
                )
            }
        } catch (e: SocketTimeoutException) {
            RepoFetchResult.Failure(repoUrl, FailureReason.TIMEOUT, "Request timed out")
        } catch (e: UnknownHostException) {
            RepoFetchResult.Failure(repoUrl, FailureReason.NETWORK_ERROR, "Host unreachable: ${e.message}")
        } catch (e: IOException) {
            RepoFetchResult.Failure(repoUrl, FailureReason.NETWORK_ERROR, "Network error: ${e.message}")
        } catch (e: Exception) {
            RepoFetchResult.Failure(repoUrl, FailureReason.NETWORK_ERROR, "Unexpected: ${e.message}")
        }
    }

    /**
     * Merges entries from all successful repos.
     * Deduplication rule: same [packageName] → keep entry with highest [versionCode].
     * If equal, prefer the entry whose repo was added first (preserve order).
     */
    private fun mergeAndDeduplicate(results: List<RepoFetchResult.Success>): List<RepoIndexEntry> {
        val byPackage = linkedMapOf<String, RepoIndexEntry>()

        for (result in results) {
            for (entry in result.entries) {
                val existing = byPackage[entry.packageName]
                if (existing == null || entry.versionCode > existing.versionCode) {
                    byPackage[entry.packageName] = entry
                }
            }
        }

        return byPackage.values.toList()
    }

    /**
     * Resolves the index URL from a user-supplied repo URL.
     *
     * Rules:
     * - Already ends with `.json`   → use as-is (covers direct index.min.json links)
     * - Ends with `/index.min.json` → use as-is
     * - Otherwise                   → append `/index.min.json`
     *                                 (Tachiyomi/Keiyoushi-style base URLs; falls
     *                                  back gracefully via HTTP error handling)
     *
     * Note: Mangetsu-native repos that use `index.json` can be added by pasting
     * their full `.json` URL directly — the "already ends with .json" branch handles them.
     */
    private fun normaliseUrl(url: String): String {
        val trimmed = url.trimEnd('/')
        return when {
            trimmed.endsWith(".json")          -> trimmed
            else                               -> "$trimmed/index.min.json"
        }
    }

    private fun ageDescription(repoUrl: String): String {
        val at = cache.lastFetchedAt(repoUrl) ?: return "unknown"
        val ageMs = System.currentTimeMillis() - at
        return "${ageMs / 3_600_000}h${(ageMs % 3_600_000) / 60_000}m"
    }
}

data class MultiRepoResult(
    val perRepo: List<RepoFetchResult>,
    val merged:  List<RepoIndexEntry>
) {
    val successCount: Int get() = perRepo.count { it is RepoFetchResult.Success }
    val failureCount: Int get() = perRepo.count { it is RepoFetchResult.Failure }
    val failures: List<RepoFetchResult.Failure>
        get() = perRepo.filterIsInstance<RepoFetchResult.Failure>()
}

sealed class UrlValidationResult {
    data class Valid(val normalisedUrl: String) : UrlValidationResult()
    data class Invalid(val reason: String)      : UrlValidationResult()
}
