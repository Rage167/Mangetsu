package com.mangetsu.data.extension.repo

import android.content.Context
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Disk-backed cache for repository index payloads.
 *
 * Each repo URL gets its own JSON file under `<filesDir>/repo_cache/<hash>.json`.
 * A cached entry is considered fresh if it was written within [TTL_MS].
 * Stale entries are still returned as fallback when the network is unavailable
 * (offline-first behaviour).
 */
@Singleton
class RepoCache @Inject constructor(
    @ApplicationContext private val context: Context,
    private val moshi: Moshi
) {
    companion object {
        /** 6-hour TTL — balances freshness vs. battery / data usage. */
        const val TTL_MS = 6 * 60 * 60 * 1000L
        private const val CACHE_DIR = "repo_cache"
    }

    private val adapter by lazy { moshi.adapter(CachedRepo::class.java) }
    private val cacheDir: File
        get() = File(context.filesDir, CACHE_DIR).also { it.mkdirs() }

    // ── Write ─────────────────────────────────────────────────────────────────

    fun put(repoUrl: String, entries: List<RepoIndexEntry>) {
        val cached = CachedRepo(
            repoUrl   = repoUrl,
            fetchedAt = System.currentTimeMillis(),
            entries   = entries.map { it.toCached() }
        )
        try {
            fileFor(repoUrl).writeText(adapter.toJson(cached), Charsets.UTF_8)
            Timber.d("RepoCache: cached ${entries.size} entries for $repoUrl")
        } catch (e: Exception) {
            Timber.e(e, "RepoCache: write failed for $repoUrl")
        }
    }

    // ── Read ──────────────────────────────────────────────────────────────────

    /**
     * Returns the cached entries for [repoUrl] regardless of freshness.
     * Use [isFresh] to decide whether a network refresh is needed.
     */
    fun get(repoUrl: String): List<RepoIndexEntry>? {
        return try {
            val file = fileFor(repoUrl)
            if (!file.exists()) return null
            val cached = adapter.fromJson(file.readText(Charsets.UTF_8)) ?: return null
            cached.entries.map { it.toIndexEntry(repoUrl) }
        } catch (e: Exception) {
            Timber.w(e, "RepoCache: read failed for $repoUrl")
            null
        }
    }

    /** Returns true if the cached data for [repoUrl] is within [TTL_MS]. */
    fun isFresh(repoUrl: String): Boolean {
        return try {
            val file = fileFor(repoUrl)
            if (!file.exists()) return false
            val cached = adapter.fromJson(file.readText(Charsets.UTF_8)) ?: return false
            System.currentTimeMillis() - cached.fetchedAt < TTL_MS
        } catch (e: Exception) {
            false
        }
    }

    /** Returns when the cache for [repoUrl] was last written, or null if absent. */
    fun lastFetchedAt(repoUrl: String): Long? {
        return try {
            val file = fileFor(repoUrl)
            if (!file.exists()) return null
            adapter.fromJson(file.readText(Charsets.UTF_8))?.fetchedAt
        } catch (e: Exception) {
            null
        }
    }

    /** Deletes the cache entry for [repoUrl]. */
    fun evict(repoUrl: String) {
        fileFor(repoUrl).delete()
        Timber.d("RepoCache: evicted $repoUrl")
    }

    /** Deletes all cached entries. */
    fun evictAll() {
        cacheDir.listFiles()?.forEach { it.delete() }
        Timber.d("RepoCache: evicted all entries")
    }

    /** Returns the total size of cached files in bytes. */
    fun totalSizeBytes(): Long = cacheDir.listFiles()?.sumOf { it.length() } ?: 0L

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun fileFor(repoUrl: String): File {
        // Use a stable hash of the URL as the filename
        val hash = repoUrl.hashCode().toUInt().toString(16)
        return File(cacheDir, "$hash.json")
    }
}

// ── Serialisable cache models ─────────────────────────────────────────────────

@JsonClass(generateAdapter = true)
data class CachedRepo(
    @Json(name = "repoUrl")   val repoUrl:   String,
    @Json(name = "fetchedAt") val fetchedAt: Long,
    @Json(name = "entries")   val entries:   List<CachedEntry>
)

@JsonClass(generateAdapter = true)
data class CachedEntry(
    @Json(name = "pkg")     val packageName: String,
    @Json(name = "name")    val name:        String,
    @Json(name = "ver")     val versionName: String,
    @Json(name = "code")    val versionCode: Int,
    @Json(name = "lang")    val lang:        String,
    @Json(name = "apk")     val apkUrl:      String,
    @Json(name = "icon")    val iconUrl:     String?,
    @Json(name = "srcId")   val sourceId:    Long,
    @Json(name = "nsfw")    val isNsfw:      Boolean
)

private fun RepoIndexEntry.toCached() = CachedEntry(
    packageName = packageName, name = name, versionName = versionName,
    versionCode = versionCode, lang = lang, apkUrl = apkUrl,
    iconUrl = iconUrl, sourceId = sourceId, isNsfw = isNsfw
)

private fun CachedEntry.toIndexEntry(repoUrl: String) = RepoIndexEntry(
    packageName = packageName, name = name, versionName = versionName,
    versionCode = versionCode, lang = lang, apkUrl = apkUrl,
    iconUrl = iconUrl, sourceId = sourceId, isNsfw = isNsfw, repoUrl = repoUrl
)
