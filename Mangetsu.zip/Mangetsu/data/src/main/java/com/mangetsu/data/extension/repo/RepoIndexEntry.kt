package com.mangetsu.data.extension.repo

import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus

/**
 * A single entry from a repository's index.json, after validation and parsing.
 * All nullable fields have been coerced to safe defaults at parse time.
 */
data class RepoIndexEntry(
    val packageName: String,
    val name:        String,
    val versionName: String,
    val versionCode: Int,
    val lang:        String,
    val apkUrl:      String,
    val iconUrl:     String?,
    val sourceId:    Long,
    val isNsfw:      Boolean,
    /** The repo URL this entry came from — for attribution and dedup. */
    val repoUrl:     String
) {
    fun toExtension(installedVersionCode: Int? = null): Extension {
        val status = when {
            installedVersionCode == null          -> ExtensionStatus.AVAILABLE
            installedVersionCode < versionCode    -> ExtensionStatus.UPDATE_AVAILABLE
            else                                  -> ExtensionStatus.INSTALLED
        }
        return Extension(
            packageName = packageName,
            name        = name,
            versionName = versionName,
            versionCode = versionCode,
            lang        = lang,
            apkUrl      = apkUrl,
            iconUrl     = iconUrl,
            sourceId    = sourceId,
            isNsfw      = isNsfw,
            status      = status
        )
    }
}

/** Result of fetching and parsing a repo index. */
sealed class RepoFetchResult {
    data class Success(
        val repoUrl: String,
        val entries: List<RepoIndexEntry>,
        val fetchedAt: Long = System.currentTimeMillis()
    ) : RepoFetchResult()

    data class Failure(
        val repoUrl: String,
        val reason:  FailureReason,
        val message: String,
        val cause:   Throwable? = null
    ) : RepoFetchResult()
}

enum class FailureReason {
    NETWORK_ERROR,
    HTTP_ERROR,
    MALFORMED_JSON,
    EMPTY_RESPONSE,
    TIMEOUT,
    INVALID_URL
}
