package com.mangetsu.data.extension.repo

import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus

/**
 * A single validated entry from a repository's index JSON.
 *
 * All fields are non-nullable — invalid/missing data is rejected during
 * parsing and never reaches this model. Instances of this class are
 * always structurally valid.
 */
data class RepoIndexEntry(
    /** Reverse-domain package name, e.g. `eu.kanade.tachiyomi.extension.en.mangadex`. */
    val packageName: String,
    /** Human-readable display name shown in the UI. */
    val name:        String,
    /** Human-readable version string, e.g. `"1.4.73"`. */
    val versionName: String,
    /** Monotonically increasing integer version; used for update detection. */
    val versionCode: Int,
    /** ISO 639-1 language code, or `"all"` for multi-language extensions. */
    val lang:        String,
    /** Fully-qualified HTTPS URL to the APK file. */
    val apkUrl:      String,
    /** Fully-qualified URL to the extension icon, or null if unavailable. */
    val iconUrl:     String?,
    /** Numeric source ID; stable across app sessions. */
    val sourceId:    Long,
    /** True if the source contains adult / NSFW content. */
    val isNsfw:      Boolean,
    /** The repo URL this entry was fetched from — used for attribution and dedup. */
    val repoUrl:     String
) {
    /**
     * Converts this repo entry to an [Extension] with the correct [ExtensionStatus].
     *
     * @param installedVersionCode The currently installed version code, or null if not installed.
     */
    fun toExtension(installedVersionCode: Int? = null): Extension {
        val status = when {
            installedVersionCode == null       -> ExtensionStatus.AVAILABLE
            installedVersionCode < versionCode -> ExtensionStatus.UPDATE_AVAILABLE
            else                               -> ExtensionStatus.INSTALLED
        }
        return Extension(
            packageName = packageName,
            name        = name,
            versionName = versionName,
            versionCode = versionCode,
            lang        = lang,
            apkUrl      = apkUrl,
            iconUrl     = iconUrl,
            sourceId    = sourceId,
            isNsfw      = isNsfw,
            status      = status
        )
    }
}

// ── Fetch result types ────────────────────────────────────────────────────────

sealed class RepoFetchResult {
    data class Success(
        val repoUrl:   String,
        val entries:   List<RepoIndexEntry>,
        val fetchedAt: Long = System.currentTimeMillis()
    ) : RepoFetchResult()

    data class Failure(
        val repoUrl: String,
        val reason:  FailureReason,
        val message: String,
        val cause:   Throwable? = null
    ) : RepoFetchResult()
}

enum class FailureReason {
    NETWORK_ERROR,
    HTTP_ERROR,
    MALFORMED_JSON,
    EMPTY_RESPONSE,
    TIMEOUT,
    INVALID_URL
}
