package com.mangetsu.data.extension.repo

import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonClass
import com.squareup.moshi.JsonReader
import com.squareup.moshi.Moshi
import okio.Buffer
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fault-tolerant, streaming parser for repository index JSON.
 *
 * **Supported schemas**
 *
 * Mangetsu-native:
 * ```json
 * { "package":"...", "apkUrl":"https://...", "versionCode":1, "sourceId":123 }
 * ```
 *
 * Tachiyomi / Keiyoushi (index.min.json):
 * ```json
 * { "pkg":"...", "apk":"filename.apk", "code":1,
 *   "sources":[{"id":123456,"lang":"en","name":"...","baseUrl":"..."}] }
 * ```
 *
 * **Recovery hierarchy**
 *
 * 1. **Streaming parse** (primary) — JsonReader with `isLenient = true`.
 *    Each array entry is isolated in its own try/catch. A corrupt entry is
 *    skipped and the reader is drained back to array scope; parsing continues
 *    with the next entry. Real-world corruptions (unterminated strings, bad
 *    escapes, wrong token types) are handled here without losing the rest of
 *    the repo.
 *
 * 2. **Brace-split fallback** — activated only when the top-level JSON is not
 *    a recognisable array (e.g. truncated payload, wrong content type, or a
 *    response that starts with garbage). Scans the raw string character-by-
 *    character for `{…}` boundaries and tries to parse each chunk individually.
 *    O(n), no regex in the hot loop.
 *
 * **Output guarantee**
 * - At least one valid entry exists → [ParseResult.Success]
 * - Completely unreadable           → [ParseResult.Failure]
 * - Empty / blank response          → [ParseResult.Failure]
 */
@Singleton
class RepoIndexParser @Inject constructor(private val moshi: Moshi) {

    companion object {
        /** Maximum entries accepted from a single repo (DoS guard). */
        private const val MAX_ENTRIES = 5_000

        // FNV-1a 64-bit constants for stable source-ID derivation.
        private const val FNV_OFFSET_BASIS = -3750763034362895579L // 0xcbf29ce484222325
        private const val FNV_PRIME        = 1099511628211L

        /** Matches ISO 639-1 two-to-five-letter codes and Tachiyomi's "all". */
        val LANG_PATTERN = Regex("^[a-z]{2,5}$")

        /**
         * Maximum token-drain iterations when recovering reader state after a
         * per-entry failure. Prevents infinite loops on pathological input.
         */
        private const val MAX_RECOVERY_TOKENS = 256
    }

    /**
     * Lenient single-entry adapter — reused across all parse calls.
     * Moshi adapters are stateless and thread-safe.
     */
    private val entryAdapter: JsonAdapter<RawIndexEntry> by lazy {
        moshi.adapter(RawIndexEntry::class.java).lenient()
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Parses [json] from [repoUrl] with full fault-tolerance.
     * Never throws. Returns [ParseResult.Success] if at least one entry
     * survived; [ParseResult.Failure] only when the payload is completely
     * unreadable.
     */
    fun parse(json: String, repoUrl: String): ParseResult {
        if (json.isBlank()) {
            return ParseResult.Failure(FailureReason.EMPTY_RESPONSE, "Response body is empty")
        }
        return streamingParse(json, repoUrl)
    }

    // ── Primary path: streaming parse ─────────────────────────────────────────

    private fun streamingParse(json: String, repoUrl: String): ParseResult {
        val reader = JsonReader.of(Buffer().writeUtf8(json))
        // Lenient mode: tolerates trailing commas, unquoted values, bad escapes,
        // unterminated strings, and other deviations seen in real-world repos.
        reader.isLenient = true

        // Enter the top-level array. If this fails the document is not recognisably
        // an array — skip straight to the brace-split fallback.
        try {
            reader.beginArray()
        } catch (e: Exception) {
            Timber.w(
                "RepoIndexParser [%s]: beginArray failed (%s) — activating brace-split fallback",
                repoUrl.substringAfterLast('/').take(40),
                e.message?.take(120)
            )
            try { reader.close() } catch (_: Exception) {}
            return fallbackParse(json, repoUrl)
        }

        val baseUrl       = deriveBaseUrl(repoUrl)
        val valid         = ArrayList<RepoIndexEntry>(64)
        // package → (versionCode, indexInValid): O(1) dedup with indexed replace.
        val seenInRepo    = HashMap<String, Pair<Int, Int>>(64)
        val parseErrors   = ArrayList<String>(4)
        var totalSeen     = 0
        var parseFailures = 0

        while (true) {
            // hasNext() itself can throw on a corrupt token at the array boundary.
            val hasNext = try {
                reader.hasNext()
            } catch (e: Exception) {
                Timber.w(
                    "RepoIndexParser [%s]: hasNext() threw — stopping stream early (%s)",
                    repoUrl.substringAfterLast('/').take(40), e.message?.take(80)
                )
                break
            }
            if (!hasNext) break

            if (totalSeen >= MAX_ENTRIES) {
                Timber.w(
                    "RepoIndexParser [%s]: capping at %d entries",
                    repoUrl.substringAfterLast('/').take(40), MAX_ENTRIES
                )
                drainRemaining(reader)
                break
            }

            totalSeen++

            try {
                // fromJson(reader) advances the reader by exactly one array element.
                val raw = entryAdapter.fromJson(reader)

                if (raw == null) {
                    // JSON null literal in the array — count as a soft skip.
                    parseFailures++
                    continue
                }

                when (val result = validate(raw, repoUrl, baseUrl)) {
                    is ValidationResult.Ok -> {
                        val entry = result.entry
                        val seen  = seenInRepo[entry.packageName]
                        when {
                            seen == null -> {
                                seenInRepo[entry.packageName] = entry.versionCode to valid.size
                                valid.add(entry)
                            }
                            entry.versionCode > seen.first -> {
                                // O(1) indexed replace — no linear scan.
                                seenInRepo[entry.packageName] = entry.versionCode to seen.second
                                valid[seen.second] = entry
                            }
                            // Equal or lower versionCode: first-seen repo wins.
                        }
                    }
                    is ValidationResult.Skip -> {
                        // Semantically invalid but parseable — logged separately.
                        if (parseErrors.size < 3) parseErrors.add("validation:${result.reason.take(60)}")
                    }
                }

            } catch (e: Exception) {
                // Per-entry parse failure — recover reader state and continue.
                parseFailures++
                if (parseErrors.size < 3) {
                    parseErrors.add("${e.javaClass.simpleName}: ${e.message?.take(80)}")
                }
                recoverToArrayLevel(reader)
            }
        }

        // Best-effort close — may throw on truly corrupt JSON, which is fine.
        try { reader.endArray() } catch (_: Exception) {}
        try { reader.close()   } catch (_: Exception) {}

        // ── Diagnostics ───────────────────────────────────────────────────────
        val tag = repoUrl.substringAfterLast('/').take(40)
        if (parseFailures > 0) {
            Timber.w(
                "RepoIndexParser [%s]: RECOVERY — %d/%d valid, %d parse failures. " +
                "First errors: [%s]",
                tag, valid.size, totalSeen, parseFailures,
                parseErrors.joinToString(" | ")
            )
        } else {
            Timber.d("RepoIndexParser [%s]: %d/%d entries valid (clean parse)", tag, valid.size, totalSeen)
        }

        return when {
            valid.isNotEmpty() ->
                ParseResult.Success(
                    entries          = valid,
                    recoveredEntries = parseFailures,
                    parseErrors      = parseErrors
                )
            totalSeen > 0 ->
                // Saw entries but none survived validation/parsing.
                ParseResult.Failure(
                    FailureReason.MALFORMED_JSON,
                    "All $totalSeen entries failed parsing/validation from $repoUrl"
                )
            else ->
                ParseResult.Failure(
                    FailureReason.MALFORMED_JSON,
                    "No entries found in response from $repoUrl"
                )
        }
    }

    /**
     * Drains remaining array elements after the [MAX_ENTRIES] cap is hit.
     * Silently ignores errors — we already have what we need.
     */
    private fun drainRemaining(reader: JsonReader) {
        try { while (reader.hasNext()) reader.skipValue() } catch (_: Exception) {}
    }

    /**
     * After a per-entry exception, the [JsonReader] is in an indeterminate
     * position somewhere inside the partially-consumed object. This method
     * drains tokens until the reader is back at array scope, ready to parse
     * the next entry.
     *
     * Key invariant: END_OBJECT is consumed with an explicit [JsonReader.endObject]
     * call, NOT skipValue(). Moshi's skipValue() does not pop its internal scope
     * stack for END_OBJECT (the depth counter goes to -1 and the loop exits
     * without advancing), so calling endObject() directly is the only correct
     * way to close an open object scope.
     *
     * A hard token limit prevents infinite loops on adversarial / pathological input.
     */
    private fun recoverToArrayLevel(reader: JsonReader) {
        repeat(MAX_RECOVERY_TOKENS) {
            val token = try { reader.peek() } catch (_: Exception) { return }
            when (token) {
                // Already back at array scope — stop.
                JsonReader.Token.END_DOCUMENT,
                JsonReader.Token.END_ARRAY    -> return
                // Next valid array entry is ready — stop.
                JsonReader.Token.BEGIN_OBJECT -> return
                // END_OBJECT must be consumed via endObject() to pop scope correctly.
                JsonReader.Token.END_OBJECT   -> {
                    try { reader.endObject() } catch (_: Exception) { return }
                    val next = try { reader.peek() } catch (_: Exception) { return }
                    if (next == JsonReader.Token.BEGIN_OBJECT ||
                        next == JsonReader.Token.END_ARRAY   ||
                        next == JsonReader.Token.END_DOCUMENT) return
                }
                // NAME, scalar values, BEGIN_ARRAY — skip.
                else -> try { reader.skipValue() } catch (_: Exception) { return }
            }
        }
    }

    // ── Fallback path: brace-split ────────────────────────────────────────────

    /**
     * Last-resort parser. Scans [json] character-by-character tracking `{}`
     * depth to extract top-level object substrings, then attempts to parse
     * each individually. O(n), no regex in the hot loop.
     *
     * Activated only when [streamingParse] cannot enter the top-level array
     * (i.e. the payload is not a recognisable JSON array at all).
     *
     * Known limitation: `{` / `}` characters inside malformed unclosed string
     * values can confuse depth tracking. Acceptable for a last-resort path.
     */
    private fun fallbackParse(json: String, repoUrl: String): ParseResult {
        val baseUrl     = deriveBaseUrl(repoUrl)
        val valid       = ArrayList<RepoIndexEntry>(16)
        val seenInRepo  = HashMap<String, Pair<Int, Int>>(16)
        var depth       = 0
        var objStart    = -1
        var chunksFound = 0

        for (i in json.indices) {
            if (valid.size >= MAX_ENTRIES) break
            when (json[i]) {
                '{' -> { if (depth++ == 0) objStart = i }
                '}' -> {
                    if (--depth == 0 && objStart >= 0) {
                        chunksFound++
                        tryParseChunk(
                            chunk      = json.substring(objStart, i + 1),
                            repoUrl    = repoUrl,
                            baseUrl    = baseUrl,
                            valid      = valid,
                            seenInRepo = seenInRepo
                        )
                        objStart = -1
                    }
                }
            }
        }

        Timber.w(
            "RepoIndexParser [%s]: brace-split fallback — scanned %d chunks, recovered %d valid entries",
            repoUrl.substringAfterLast('/').take(40), chunksFound, valid.size
        )

        return if (valid.isNotEmpty()) {
            ParseResult.Success(entries = valid, recoveredEntries = valid.size, parseErrors = emptyList())
        } else {
            ParseResult.Failure(
                reason  = FailureReason.MALFORMED_JSON,
                message = "Brace-split fallback found no valid entries from $repoUrl " +
                          "(scanned $chunksFound chunks)"
            )
        }
    }

    /**
     * Attempts to parse a single `{…}` JSON substring as a [RawIndexEntry].
     * Silently no-ops on any failure — best-effort fallback call site.
     */
    private fun tryParseChunk(
        chunk:      String,
        repoUrl:    String,
        baseUrl:    String,
        valid:      ArrayList<RepoIndexEntry>,
        seenInRepo: HashMap<String, Pair<Int, Int>>
    ) {
        try {
            val chunkReader = JsonReader.of(Buffer().writeUtf8(chunk))
            chunkReader.isLenient = true
            val raw = entryAdapter.fromJson(chunkReader) ?: return
            try { chunkReader.close() } catch (_: Exception) {}

            when (val result = validate(raw, repoUrl, baseUrl)) {
                is ValidationResult.Ok -> {
                    val entry = result.entry
                    val seen  = seenInRepo[entry.packageName]
                    when {
                        seen == null -> {
                            seenInRepo[entry.packageName] = entry.versionCode to valid.size
                            valid.add(entry)
                        }
                        entry.versionCode > seen.first -> {
                            seenInRepo[entry.packageName] = entry.versionCode to seen.second
                            valid[seen.second] = entry
                        }
                    }
                }
                is ValidationResult.Skip -> {} // silent in fallback
            }
        } catch (_: Exception) {
            // Chunk is unrecoverable — skip silently.
        }
    }

    // ── Validation ────────────────────────────────────────────────────────────

    private fun validate(
        raw:     RawIndexEntry,
        repoUrl: String,
        baseUrl: String
    ): ValidationResult {

        fun skip(reason: String): ValidationResult.Skip {
            val label = raw.packageName ?: raw.pkgTachi ?: raw.name ?: "<unknown>"
            return ValidationResult.Skip(label = label, reason = reason)
        }

        // ── 1. Package name ──────────────────────────────────────────────────
        val pkg = (raw.packageName ?: raw.pkgTachi)
            ?.trim()?.takeIf { it.isNotBlank() }
            ?: return skip("missing package name (no 'package' or 'pkg' field)")
        if (!pkg.contains('.')) return skip("invalid package name (no dot separator): $pkg")
        if (pkg.length < 5)     return skip("package name too short: $pkg")

        // ── 2. Display name ──────────────────────────────────────────────────
        val name = raw.name?.trim()?.takeIf { it.isNotBlank() }
            ?: return skip("missing 'name' field for $pkg")

        // ── 3. Version code ──────────────────────────────────────────────────
        val versionCode = (raw.versionCode ?: raw.versionCodeTachi)
            ?: return skip("missing 'versionCode' or 'code' for $pkg")
        if (versionCode <= 0) return skip("versionCode must be > 0 (was $versionCode) for $pkg")

        // ── 4. APK URL ───────────────────────────────────────────────────────
        val apkUrl: String = when {
            !raw.apkUrl.isNullOrBlank() -> {
                val u = raw.apkUrl.trim()
                if (!u.hasHttpsScheme()) return skip("apkUrl must be HTTPS: $u for $pkg")
                u
            }
            !raw.apkFilename.isNullOrBlank() -> {
                val filename = raw.apkFilename.trim().trimStart('/')
                if (filename.isBlank())
                    return skip("blank apk filename for $pkg")
                if (filename.contains("..") || filename.contains('/'))
                    return skip("unsafe apk filename: $filename for $pkg")
                buildUrl(baseUrl, "apk", filename)
            }
            else -> return skip("no 'apkUrl' or 'apk' field for $pkg")
        }

        // ── 5. Source ID ─────────────────────────────────────────────────────
        val rawSourceId = raw.sourceId
            ?: raw.sources?.firstOrNull { (it.id ?: 0L) > 0L }?.id
        val sourceId: Long = if (rawSourceId != null && rawSourceId > 0L) {
            rawSourceId
        } else {
            stableSourceId(pkg).also {
                Timber.d("RepoIndexParser: no sourceId for %s — derived %d", pkg, it)
            }
        }

        // ── 6. Icon URL ──────────────────────────────────────────────────────
        val iconUrl: String? = when {
            !raw.iconUrl.isNullOrBlank() && raw.iconUrl.trim().hasHttpScheme() ->
                raw.iconUrl.trim()
            baseUrl.hasHttpScheme() ->
                buildUrl(baseUrl, "icon", "$pkg.png")
            else -> null
        }

        // ── 7. Language ──────────────────────────────────────────────────────
        val lang = raw.lang?.trim()?.lowercase()
            ?.takeIf { it.matches(LANG_PATTERN) } ?: "all"

        // ── 8. Version name ──────────────────────────────────────────────────
        val versionName = raw.versionName?.trim()?.takeIf { it.isNotBlank() }
            ?: "$versionCode"

        return ValidationResult.Ok(
            RepoIndexEntry(
                packageName = pkg,
                name        = name,
                versionName = versionName,
                versionCode = versionCode,
                lang        = lang,
                apkUrl      = apkUrl,
                iconUrl     = iconUrl,
                sourceId    = sourceId,
                isNsfw      = raw.isNsfw ?: false,
                repoUrl     = repoUrl
            )
        )
    }

    // ── URL helpers ───────────────────────────────────────────────────────────

    private fun deriveBaseUrl(repoUrl: String): String {
        val trimmed = repoUrl.trim().trimEnd('/')
        return if (trimmed.substringAfterLast('/').contains('.'))
            trimmed.substringBeforeLast('/')
        else
            trimmed
    }

    private fun buildUrl(base: String, vararg segments: String): String {
        val cleanBase = base.trimEnd('/')
        val path = segments.joinToString("/") { it.trim('/').trimStart('.') }
        return "$cleanBase/$path"
    }

    private fun String.hasHttpScheme() =
        startsWith("http://", ignoreCase = true) ||
        startsWith("https://", ignoreCase = true)

    private fun String.hasHttpsScheme() =
        startsWith("https://", ignoreCase = true)

    // ── Source ID derivation ──────────────────────────────────────────────────

    private fun stableSourceId(packageName: String): Long {
        var hash = FNV_OFFSET_BASIS
        for (ch in packageName) {
            hash = hash xor ch.code.toLong()
            hash *= FNV_PRIME
        }
        return maxOf(1L, if (hash < 0L) (hash and Long.MAX_VALUE) else hash)
    }
}

// ── Result types ──────────────────────────────────────────────────────────────

sealed class ParseResult {
    /**
     * At least one entry was parsed successfully.
     *
     * @param entries          Validated, deduplicated entries.
     * @param recoveredEntries Count of entries that triggered parse exceptions
     *                         (0 = clean parse, >0 = recovery mode was active).
     * @param parseErrors      First ≤3 exception messages for diagnostics.
     */
    data class Success(
        val entries:          List<RepoIndexEntry>,
        val recoveredEntries: Int          = 0,
        val parseErrors:      List<String> = emptyList()
    ) : ParseResult() {
        /** True if at least one entry required error recovery during parsing. */
        val wasRecovered: Boolean get() = recoveredEntries > 0
    }

    data class Failure(val reason: FailureReason, val message: String) : ParseResult()
}

private sealed class ValidationResult {
    data class Ok(val entry: RepoIndexEntry)                : ValidationResult()
    data class Skip(val label: String, val reason: String) : ValidationResult()
}

// ── Raw JSON models ───────────────────────────────────────────────────────────
//
// All fields nullable — Moshi never crashes on missing or wrong-typed fields.
// Dual-name pairs cover both Mangetsu-native and Tachiyomi/Keiyoushi schemas.

@JsonClass(generateAdapter = true)
data class RawIndexEntry(
    // Shared
    @Json(name = "name")        val name:             String?,
    @Json(name = "lang")        val lang:             String?,
    @Json(name = "version")     val versionName:      String?,
    @Json(name = "iconUrl")     val iconUrl:          String?,
    @Json(name = "sourceId")    val sourceId:         Long?,
    // Mangetsu-native
    @Json(name = "package")     val packageName:      String?,
    @Json(name = "apkUrl")      val apkUrl:           String?,
    @Json(name = "versionCode") val versionCode:      Int?,
    // Tachiyomi / Keiyoushi
    @Json(name = "pkg")         val pkgTachi:         String?,
    @Json(name = "apk")         val apkFilename:      String?,
    @Json(name = "code")        val versionCodeTachi: Int?,
    @Json(name = "sources")     val sources:          List<RawSource>?,
    // Tolerant boolean — see FlexibleBooleanAdapter
    @Json(name = "nsfw") @FlexibleBoolean val isNsfw: Boolean?
)

@JsonClass(generateAdapter = true)
data class RawSource(
    @Json(name = "id")      val id:      Long?,
    @Json(name = "lang")    val lang:    String?,
    @Json(name = "name")    val name:    String?,
    @Json(name = "baseUrl") val baseUrl: String?
)
