package com.mangetsu.data.extension.repo

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Dual-schema, production-grade parser for repository index JSON.
 *
 * **Supported schemas**
 *
 * Mangetsu-native:
 * ```json
 * { "package":"...", "apkUrl":"https://...", "versionCode":1, "sourceId":123 }
 * ```
 *
 * Tachiyomi / Keiyoushi (index.min.json):
 * ```json
 * { "pkg":"...", "apk":"filename.apk", "code":1,
 *   "sources":[{"id":123456,"lang":"en","name":"...","baseUrl":"..."}] }
 * ```
 *
 * **Resilience guarantees**
 * - Completely malformed JSON      → [ParseResult.Failure], never crashes
 * - Per-entry validation failures  → entry skipped + structured log, others continue
 * - Unknown JSON fields            → silently ignored (Moshi `.lenient()`)
 * - Missing optional fields        → safe defaults applied
 * - `nsfw` as boolean/int/string   → [FlexibleBooleanAdapter] handles all forms
 * - Absurdly large repos           → capped at [MAX_ENTRIES] entries (DoS guard)
 * - Non-https APK URLs             → entry skipped (security)
 * - Duplicate package names within a single repo → highest versionCode wins
 */
@Singleton
class RepoIndexParser @Inject constructor(private val moshi: Moshi) {

    companion object {
        /** Maximum entries accepted from a single repo to guard against malicious payloads. */
        private const val MAX_ENTRIES = 5_000

        // FNV-1a 64-bit constants for stable source-ID derivation
        private const val FNV_OFFSET_BASIS = -3750763034362895579L // 0xcbf29ce484222325
        private const val FNV_PRIME        = 1099511628211L

        /** Matches ISO 639-1 codes ("en", "ja") and Tachiyomi's "all". */
        val LANG_PATTERN = Regex("^[a-z]{2,5}$")
    }

    private val listAdapter by lazy {
        moshi.adapter<List<RawIndexEntry>>(
            Types.newParameterizedType(List::class.java, RawIndexEntry::class.java)
        ).lenient()   // tolerate trailing commas, some malformed structure
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun parse(json: String, repoUrl: String): ParseResult {
        if (json.isBlank()) {
            return ParseResult.Failure(FailureReason.EMPTY_RESPONSE, "Response body is empty")
        }

        val rawEntries: List<RawIndexEntry>? = try {
            listAdapter.fromJson(json)
        } catch (e: Exception) {
            Timber.w(e, "RepoIndexParser: malformed JSON from %s", repoUrl)
            return ParseResult.Failure(
                reason  = FailureReason.MALFORMED_JSON,
                message = "JSON parse error: ${e.message?.take(200)}"
            )
        }

        if (rawEntries == null) {
            return ParseResult.Failure(FailureReason.MALFORMED_JSON, "Parsed result was null")
        }

        val baseUrl = deriveBaseUrl(repoUrl)

        // Pre-allocate with expected capacity to avoid ArrayList resizing on large repos.
        val cappedSize  = minOf(rawEntries.size, MAX_ENTRIES)
        val valid       = ArrayList<RepoIndexEntry>(cappedSize)
        // Skips are rare on well-maintained repos; use a small initial capacity.
        val skipped     = ArrayList<ValidationResult.Skip>(4)
        // Intra-repo dedup: package → (versionCode, indexInValid).
        // Storing the insertion index makes upgrades an O(1) indexed replace
        // instead of the previous O(N) indexOfFirst scan (was O(N²) overall).
        val seenInRepo  = HashMap<String, Pair<Int, Int>>(cappedSize * 4 / 3 + 1)

        if (rawEntries.size > MAX_ENTRIES) {
            Timber.w(
                "RepoIndexParser: repo %s has %d entries, capping at %d",
                repoUrl, rawEntries.size, MAX_ENTRIES
            )
        }

        // Use index loop (vs take()) to avoid allocating a capped sub-list copy.
        for (i in 0 until cappedSize) {
            when (val result = validate(rawEntries[i], repoUrl, baseUrl)) {
                is ValidationResult.Ok -> {
                    val entry = result.entry
                    val seen  = seenInRepo[entry.packageName]
                    if (seen == null) {
                        seenInRepo[entry.packageName] = entry.versionCode to valid.size
                        valid.add(entry)
                    } else if (entry.versionCode > seen.first) {
                        // O(1) indexed replace — no linear scan needed.
                        seenInRepo[entry.packageName] = entry.versionCode to seen.second
                        valid[seen.second] = entry
                    }
                }
                is ValidationResult.Skip -> skipped.add(result)
            }
        }

        logSkipped(skipped, repoUrl)

        Timber.d(
            "RepoIndexParser: %d valid / %d skipped from %s",
            valid.size, skipped.size, repoUrl
        )

        return ParseResult.Success(valid)
    }

    // ── Validation ────────────────────────────────────────────────────────────

    private fun validate(
        raw:     RawIndexEntry,
        repoUrl: String,
        baseUrl: String
    ): ValidationResult {

        fun skip(reason: String): ValidationResult.Skip {
            val label = raw.packageName ?: raw.pkgTachi ?: raw.name ?: "<unknown>"
            return ValidationResult.Skip(label = label, reason = reason)
        }

        // ── 1. Package name ──────────────────────────────────────────────────
        val pkg = (raw.packageName ?: raw.pkgTachi)
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: return skip("missing package name (no 'package' or 'pkg' field)")

        if (!pkg.contains('.'))
            return skip("invalid package name (no dot separator): $pkg")

        // Guard against suspiciously short package names
        if (pkg.length < 5)
            return skip("package name too short: $pkg")

        // ── 2. Display name ──────────────────────────────────────────────────
        val name = raw.name?.trim()?.takeIf { it.isNotBlank() }
            ?: return skip("missing 'name' field for $pkg")

        // ── 3. Version code ──────────────────────────────────────────────────
        val versionCode = (raw.versionCode ?: raw.versionCodeTachi)
            ?: return skip("missing 'versionCode' or 'code' for $pkg")
        if (versionCode <= 0)
            return skip("versionCode must be > 0 (was $versionCode) for $pkg")

        // ── 4. APK URL ───────────────────────────────────────────────────────
        val apkUrl: String = when {
            !raw.apkUrl.isNullOrBlank() -> {
                val u = raw.apkUrl.trim()
                if (!u.hasHttpsScheme())
                    return skip("apkUrl must be HTTPS (security): $u for $pkg")
                u
            }
            !raw.apkFilename.isNullOrBlank() -> {
                val filename = raw.apkFilename.trim().trimStart('/')
                if (filename.isBlank())
                    return skip("apk filename is blank for $pkg")
                // Guard against path traversal in filenames
                if (filename.contains("..") || filename.contains('/'))
                    return skip("unsafe apk filename: $filename for $pkg")
                buildUrl(baseUrl, "apk", filename)
            }
            else -> return skip("no 'apkUrl' or 'apk' field for $pkg")
        }

        // ── 5. Source ID ─────────────────────────────────────────────────────
        val rawSourceId = raw.sourceId
            ?: raw.sources?.firstOrNull { (it.id ?: 0L) > 0L }?.id

        val sourceId: Long = if (rawSourceId != null && rawSourceId > 0L) {
            rawSourceId
        } else {
            val derived = stableSourceId(pkg)
            Timber.d(
                "RepoIndexParser: no sourceId in JSON for %s — derived %d from package hash",
                pkg, derived
            )
            derived
        }

        // ── 6. Icon URL ──────────────────────────────────────────────────────
        val iconUrl: String? = when {
            !raw.iconUrl.isNullOrBlank() && raw.iconUrl.trim().hasHttpScheme() ->
                raw.iconUrl.trim()
            baseUrl.hasHttpScheme() ->
                buildUrl(baseUrl, "icon", "$pkg.png")
            else -> null
        }

        // ── 7. Language ──────────────────────────────────────────────────────
        val lang = raw.lang?.trim()?.lowercase()
            ?.takeIf { it.matches(LANG_PATTERN) }
            ?: "all"

        // ── 8. Version name ──────────────────────────────────────────────────
        val versionName = raw.versionName?.trim()?.takeIf { it.isNotBlank() }
            ?: "$versionCode"   // synthesize from versionCode if absent

        return ValidationResult.Ok(
            RepoIndexEntry(
                packageName = pkg,
                name        = name,
                versionName = versionName,
                versionCode = versionCode,
                lang        = lang,
                apkUrl      = apkUrl,
                iconUrl     = iconUrl,
                sourceId    = sourceId,
                isNsfw      = raw.isNsfw ?: false,
                repoUrl     = repoUrl
            )
        )
    }

    // ── URL helpers ───────────────────────────────────────────────────────────

    /**
     * Derives the repo base URL by stripping the final path segment when it
     * looks like an index file.
     *
     * Examples:
     * - `https://host/repo/index.min.json` → `https://host/repo`
     * - `https://host/repo/`              → `https://host/repo`
     * - `https://host/repo`               → `https://host/repo`
     */
    private fun deriveBaseUrl(repoUrl: String): String {
        val trimmed = repoUrl.trim().trimEnd('/')
        return if (trimmed.substringAfterLast('/').contains('.'))
            trimmed.substringBeforeLast('/')
        else
            trimmed
    }

    /**
     * Builds a URL from [base] + [segments], ensuring:
     * - No double slashes between segments
     * - Each segment has any leading/trailing slashes stripped before joining
     */
    private fun buildUrl(base: String, vararg segments: String): String {
        val cleanBase = base.trimEnd('/')
        val path = segments.joinToString("/") { it.trim('/').trimStart('.') }
        return "$cleanBase/$path"
    }

    private fun String.hasHttpScheme() =
        startsWith("http://", ignoreCase = true) ||
        startsWith("https://", ignoreCase = true)

    private fun String.hasHttpsScheme() =
        startsWith("https://", ignoreCase = true)

    // ── Source ID derivation ──────────────────────────────────────────────────

    /**
     * Derives a stable, positive, non-zero source ID from a package name using
     * FNV-1a 64-bit hashing. This gives better distribution than `hashCode()`
     * and is consistent across JVM versions and platforms.
     */
    private fun stableSourceId(packageName: String): Long {
        var hash = FNV_OFFSET_BASIS
        for (ch in packageName) {
            hash = hash xor ch.code.toLong()
            hash *= FNV_PRIME
        }
        // Fold to positive, guarantee non-zero
        return maxOf(1L, if (hash < 0L) (hash and Long.MAX_VALUE) else hash)
    }

    // ── Logging ───────────────────────────────────────────────────────────────

    private fun logSkipped(skipped: List<ValidationResult.Skip>, repoUrl: String) {
        if (skipped.isEmpty()) return

        // Group by reason for compact, actionable log output
        val grouped = skipped.groupBy({ it.reason }, { it.label })
        grouped.forEach { (reason, labels) ->
            Timber.w(
                "RepoIndexParser [%s] skipped %d entries — %s: %s",
                repoUrl.substringAfterLast('/').take(40),
                labels.size,
                reason,
                labels.take(5).joinToString() + if (labels.size > 5) " …(+${labels.size - 5} more)" else ""
            )
        }
    }

    // ── Companion / constants ─────────────────────────────────────────────────


}

// ── Result types ──────────────────────────────────────────────────────────────

sealed class ParseResult {
    data class Success(val entries: List<RepoIndexEntry>) : ParseResult()
    data class Failure(val reason: FailureReason, val message: String) : ParseResult()
}

private sealed class ValidationResult {
    data class Ok(val entry: RepoIndexEntry)                : ValidationResult()
    data class Skip(val label: String, val reason: String) : ValidationResult()
}

// ── Raw JSON models ───────────────────────────────────────────────────────────
//
// All fields are nullable — Moshi never crashes on missing or wrong-typed values.
// Dual-name pairs (e.g. packageName / pkgTachi) cover both supported schemas.

@JsonClass(generateAdapter = true)
data class RawIndexEntry(
    // Shared fields present in both schemas
    @Json(name = "name")        val name:             String?,
    @Json(name = "lang")        val lang:             String?,
    @Json(name = "version")     val versionName:      String?,
    @Json(name = "iconUrl")     val iconUrl:          String?,
    @Json(name = "sourceId")    val sourceId:         Long?,

    // Mangetsu-native schema
    @Json(name = "package")     val packageName:      String?,
    @Json(name = "apkUrl")      val apkUrl:           String?,
    @Json(name = "versionCode") val versionCode:      Int?,

    // Tachiyomi / Keiyoushi schema
    @Json(name = "pkg")         val pkgTachi:         String?,
    @Json(name = "apk")         val apkFilename:      String?,
    @Json(name = "code")        val versionCodeTachi: Int?,
    @Json(name = "sources")     val sources:          List<RawSource>?,

    // Tolerant boolean: accepts true/false, 0/1, "true"/"false" — see FlexibleBooleanAdapter
    @Json(name = "nsfw") @FlexibleBoolean val isNsfw: Boolean?
)

@JsonClass(generateAdapter = true)
data class RawSource(
    @Json(name = "id")      val id:      Long?,
    @Json(name = "lang")    val lang:    String?,
    @Json(name = "name")    val name:    String?,
    @Json(name = "baseUrl") val baseUrl: String?
)
