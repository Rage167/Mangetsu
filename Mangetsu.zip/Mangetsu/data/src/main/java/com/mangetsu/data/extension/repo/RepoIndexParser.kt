package com.mangetsu.data.extension.repo

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Strict but forgiving parser for repository index JSON.
 *
 * Handles:
 * - Completely malformed JSON           → FailureReason.MALFORMED_JSON
 * - Entries missing required fields     → entry skipped, others kept
 * - Extra unknown fields               → ignored (Moshi default)
 * - Empty array                        → Success with empty list
 * - Null values in non-null fields     → entry skipped
 * - Wrong field types                  → entry skipped
 */
@Singleton
class RepoIndexParser @Inject constructor(private val moshi: Moshi) {

    private val listAdapter by lazy {
        moshi.adapter<List<RawIndexEntry>>(
            Types.newParameterizedType(List::class.java, RawIndexEntry::class.java)
        ).lenient()   // lenient = tolerate trailing commas, unquoted strings
    }

    /**
     * Parses [json] into a list of validated [RepoIndexEntry] objects.
     *
     * @param json     Raw JSON string from the network or cache.
     * @param repoUrl  The source URL — embedded in each entry for attribution.
     * @return [ParseResult.Success] always if JSON is structurally valid;
     *         [ParseResult.Failure] only if JSON cannot be parsed at all.
     */
    fun parse(json: String, repoUrl: String): ParseResult {
        if (json.isBlank()) {
            return ParseResult.Failure(FailureReason.EMPTY_RESPONSE, "Response body is empty")
        }

        val rawEntries = try {
            listAdapter.fromJson(json)
        } catch (e: Exception) {
            Timber.w(e, "RepoIndexParser: malformed JSON from $repoUrl")
            return ParseResult.Failure(
                reason  = FailureReason.MALFORMED_JSON,
                message = "JSON parse error: ${e.message?.take(120)}"
            )
        }

        if (rawEntries == null) {
            return ParseResult.Failure(FailureReason.MALFORMED_JSON, "Parsed result was null")
        }

        val valid   = mutableListOf<RepoIndexEntry>()
        val skipped = mutableListOf<String>()

        for (raw in rawEntries) {
            val validated = validate(raw, repoUrl)
            if (validated != null) {
                valid += validated
            } else {
                skipped += raw.packageName ?: raw.name ?: "<unknown>"
            }
        }

        if (skipped.isNotEmpty()) {
            Timber.w("RepoIndexParser: skipped ${skipped.size} invalid entries from $repoUrl: $skipped")
        }

        Timber.d("RepoIndexParser: parsed ${valid.size} valid / ${skipped.size} skipped from $repoUrl")
        return ParseResult.Success(valid)
    }

    // ── Validation ────────────────────────────────────────────────────────────

    private fun validate(raw: RawIndexEntry, repoUrl: String): RepoIndexEntry? {
        // Required string fields — must be non-null and non-blank
        val pkg     = raw.packageName?.takeIf { it.isNotBlank() } ?: return null
        val name    = raw.name?.takeIf { it.isNotBlank() }        ?: return null
        val apkUrl  = raw.apkUrl?.takeIf { it.isNotBlank() }      ?: return null

        // apkUrl must look like an HTTP(S) URL
        if (!apkUrl.startsWith("http://") && !apkUrl.startsWith("https://")) return null

        // sourceId must be a positive non-zero long
        val sourceId = raw.sourceId ?: return null
        if (sourceId <= 0L) return null

        // versionCode must be a positive int
        val versionCode = raw.versionCode?.takeIf { it > 0 } ?: return null

        return RepoIndexEntry(
            packageName = pkg,
            name        = name,
            versionName = raw.versionName?.takeIf { it.isNotBlank() } ?: "1.0",
            versionCode = versionCode,
            lang        = raw.lang?.takeIf { it.isNotBlank() }?.lowercase() ?: "en",
            apkUrl      = apkUrl.trim(),
            iconUrl     = raw.iconUrl?.takeIf { it.startsWith("http") },
            sourceId    = sourceId,
            isNsfw      = raw.isNsfw ?: false,
            repoUrl     = repoUrl
        )
    }
}

sealed class ParseResult {
    data class Success(val entries: List<RepoIndexEntry>) : ParseResult()
    data class Failure(val reason: FailureReason, val message: String) : ParseResult()
}

// ── Raw JSON model (all fields nullable to survive bad input) ─────────────────

@JsonClass(generateAdapter = true)
data class RawIndexEntry(
    @Json(name = "package")     val packageName: String?,
    @Json(name = "name")        val name:        String?,
    @Json(name = "apkUrl")      val apkUrl:      String?,
    @Json(name = "version")     val versionName: String?,
    @Json(name = "versionCode") val versionCode: Int?,
    @Json(name = "lang")        val lang:        String?,
    @Json(name = "sourceId")    val sourceId:    Long?,
    @Json(name = "iconUrl")     val iconUrl:     String?,
    @Json(name = "nsfw") @FlexibleBoolean val isNsfw: Boolean?
)
