package com.mangetsu.data.extension.repo

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Strict but forgiving parser for repository index JSON.
 *
 * Supports two schemas:
 *
 * **Mangetsu-native schema** (docs/example-repo-index.json):
 * ```json
 * { "package": "...", "apkUrl": "https://...", "versionCode": 1,
 *   "sourceId": 123, "iconUrl": "https://...", ... }
 * ```
 *
 * **Tachiyomi / Keiyoushi schema** (index.min.json):
 * ```json
 * { "pkg": "...", "apk": "filename.apk", "code": 1,
 *   "sources": [{"id": 123456, ...}], ... }
 * ```
 * In the Tachiyomi schema the APK URL is constructed as:
 *   `<repoBaseUrl>/apk/<apk-filename>`
 * and the icon URL as:
 *   `<repoBaseUrl>/icon/<pkg>.png`
 *
 * Handles:
 * - Completely malformed JSON           → FailureReason.MALFORMED_JSON
 * - Entries missing required fields     → entry skipped, others kept
 * - Extra unknown fields               → ignored (Moshi default)
 * - Empty array                        → Success with empty list
 * - Null values in non-null fields     → entry skipped
 * - Mixed-schema repos                 → handled transparently
 */
@Singleton
class RepoIndexParser @Inject constructor(private val moshi: Moshi) {

    private val listAdapter by lazy {
        moshi.adapter<List<RawIndexEntry>>(
            Types.newParameterizedType(List::class.java, RawIndexEntry::class.java)
        ).lenient()
    }

    fun parse(json: String, repoUrl: String): ParseResult {
        if (json.isBlank()) {
            return ParseResult.Failure(FailureReason.EMPTY_RESPONSE, "Response body is empty")
        }

        val rawEntries = try {
            listAdapter.fromJson(json)
        } catch (e: Exception) {
            Timber.w(e, "RepoIndexParser: malformed JSON from $repoUrl")
            return ParseResult.Failure(
                reason  = FailureReason.MALFORMED_JSON,
                message = "JSON parse error: ${e.message?.take(200)}"
            )
        }

        if (rawEntries == null) {
            return ParseResult.Failure(FailureReason.MALFORMED_JSON, "Parsed result was null")
        }

        val baseUrl  = repoUrl.trimEnd('/')
            .let { if (it.endsWith(".json")) it.substringBeforeLast('/') else it }

        val valid   = mutableListOf<RepoIndexEntry>()
        val skipped = mutableListOf<String>()

        for (raw in rawEntries) {
            val validated = validate(raw, repoUrl, baseUrl)
            if (validated != null) {
                valid += validated
            } else {
                skipped += raw.packageName ?: raw.pkgTachi ?: raw.name ?: "<unknown>"
            }
        }

        if (skipped.isNotEmpty()) {
            Timber.w("RepoIndexParser: skipped ${skipped.size} invalid entries from $repoUrl: " +
                skipped.take(10).joinToString())
        }

        Timber.d("RepoIndexParser: parsed ${valid.size} valid / ${skipped.size} skipped from $repoUrl")
        return ParseResult.Success(valid)
    }

    // ── Validation ────────────────────────────────────────────────────────────

    private fun validate(raw: RawIndexEntry, repoUrl: String, baseUrl: String): RepoIndexEntry? {
        // ── Package name: "package" (native) or "pkg" (Tachiyomi) ────────────
        val pkg = (raw.packageName ?: raw.pkgTachi)
            ?.takeIf { it.isNotBlank() } ?: return null

        // ── Display name ──────────────────────────────────────────────────────
        val name = raw.name?.takeIf { it.isNotBlank() } ?: return null

        // ── APK URL: "apkUrl" (native full URL) or "apk" (Tachiyomi filename) ─
        val apkUrl: String = when {
            // Native schema: full URL provided
            !raw.apkUrl.isNullOrBlank() && raw.apkUrl.startsWith("http") -> raw.apkUrl.trim()

            // Tachiyomi schema: construct URL from base + /apk/ + filename
            !raw.apkFilename.isNullOrBlank() -> "$baseUrl/apk/${raw.apkFilename.trim()}"

            // Nothing usable
            else -> return null
        }

        // ── Version code: "versionCode" (native) or "code" (Tachiyomi) ───────
        val versionCode = (raw.versionCode ?: raw.versionCodeTachi)
            ?.takeIf { it > 0 } ?: return null

        // ── Source ID: top-level "sourceId" (native) or sources[0].id (Tachi) ─
        val sourceId: Long = raw.sourceId
            ?: raw.sources?.firstOrNull()?.id
            ?: derivedSourceId(pkg)

        // ── Icon URL: "iconUrl" (native) or constructed from base URL ─────────
        val iconUrl: String? = when {
            !raw.iconUrl.isNullOrBlank() && raw.iconUrl.startsWith("http") -> raw.iconUrl.trim()
            !raw.pkgTachi.isNullOrBlank() -> "$baseUrl/icon/${raw.pkgTachi.trim()}.png"
            else -> null
        }

        return RepoIndexEntry(
            packageName = pkg,
            name        = name,
            versionName = raw.versionName?.takeIf { it.isNotBlank() } ?: "1.0",
            versionCode = versionCode,
            lang        = raw.lang?.takeIf { it.isNotBlank() }?.lowercase() ?: "all",
            apkUrl      = apkUrl,
            iconUrl     = iconUrl,
            sourceId    = sourceId,
            isNsfw      = raw.isNsfw ?: false,
            repoUrl     = repoUrl
        )
    }

    /**
     * Derives a stable source ID from the package name when none is provided.
     * Uses the same algorithm as Tachiyomi's source ID generation to maximise
     * compatibility, while ensuring we never return 0.
     */
    private fun derivedSourceId(packageName: String): Long {
        var hash = packageName.hashCode().toLong()
        if (hash == 0L) hash = packageName.length.toLong()
        return if (hash < 0) -hash else hash
    }
}

sealed class ParseResult {
    data class Success(val entries: List<RepoIndexEntry>) : ParseResult()
    data class Failure(val reason: FailureReason, val message: String) : ParseResult()
}

// ── Raw JSON model ────────────────────────────────────────────────────────────
//
// All fields are nullable to survive bad/missing input.
// Each pair of fields covers both the native Mangetsu schema and the
// Tachiyomi/Keiyoushi schema — whichever is non-null wins in validate().

@JsonClass(generateAdapter = true)
data class RawIndexEntry(
    // Shared
    @Json(name = "name")        val name:             String?,
    @Json(name = "lang")        val lang:             String?,
    @Json(name = "version")     val versionName:      String?,
    @Json(name = "iconUrl")     val iconUrl:          String?,
    @Json(name = "sourceId")    val sourceId:         Long?,

    // Native Mangetsu schema
    @Json(name = "package")     val packageName:      String?,
    @Json(name = "apkUrl")      val apkUrl:           String?,
    @Json(name = "versionCode") val versionCode:      Int?,

    // Tachiyomi / Keiyoushi schema
    @Json(name = "pkg")         val pkgTachi:         String?,
    @Json(name = "apk")         val apkFilename:      String?,
    @Json(name = "code")        val versionCodeTachi: Int?,
    @Json(name = "sources")     val sources:          List<RawSource>?,

    // nsfw — tolerant adapter handles boolean, int, string, null
    @Json(name = "nsfw") @FlexibleBoolean val isNsfw: Boolean?
)

@JsonClass(generateAdapter = true)
data class RawSource(
    @Json(name = "id")      val id:      Long?,
    @Json(name = "lang")    val lang:    String?,
    @Json(name = "name")    val name:    String?,
    @Json(name = "baseUrl") val baseUrl: String?
)
