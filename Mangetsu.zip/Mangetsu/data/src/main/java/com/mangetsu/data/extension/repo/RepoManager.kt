package com.mangetsu.data.extension.repo

import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.toDomain
import com.mangetsu.data.extension.ExtensionInstaller
import com.mangetsu.data.extension.download.ApkDownloadManager
import com.mangetsu.data.extension.download.DownloadState
import com.mangetsu.data.extension.lifecycle.ExtensionLifecycleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Top-level orchestrator for the repository system.
 *
 * Responsibilities:
 * - Manage user-added repos (add/remove/refresh)
 * - Coordinate multi-repo fetching via [MultiRepoFetcher]
 * - Annotate results with version status via [VersionManager]
 * - Track per-extension install/update progress
 * - Expose reactive [RepoScreenState] for the UI layer
 */
@Singleton
class RepoManager @Inject constructor(
    private val db:               MangetsuDatabase,
    private val fetcher:          MultiRepoFetcher,
    private val versionManager:   VersionManager,
    private val installer:        ExtensionInstaller,
    private val downloadManager:  ApkDownloadManager,
    private val lifecycleManager: ExtensionLifecycleManager,
    private val cache:            RepoCache
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ── State exposed to UI ───────────────────────────────────────────────────

    private val _state = MutableStateFlow(RepoScreenState())
    val state: Flow<RepoScreenState> = _state.asStateFlow()

    // Per-package download/install progress
    private val _installProgress = MutableStateFlow<Map<String, InstallProgress>>(emptyMap())
    val installProgress: Flow<Map<String, InstallProgress>> = _installProgress.asStateFlow()

    // ── Repos CRUD ────────────────────────────────────────────────────────────

    fun getRepos(): Flow<List<ExtensionRepo>> =
        db.extensionRepoDao().getAll().map { list -> list.map { it.toDomain() } }

    /**
     * Validates [url], persists the repo, fetches its index, and refreshes state.
     *
     * Note: we skip the validateUrl() HEAD probe here — fetchSingle() performs
     * the real GET and surfaces all the same error conditions (INVALID_URL,
     * HTTP_ERROR, NETWORK_ERROR) without the extra round trip.
     */
    suspend fun addRepo(url: String): AddRepoResult = withContext(Dispatchers.IO) {
        // Prevent duplicates before any network work
        val existing = db.extensionRepoDao().getByUrl(url)
        if (existing != null) return@withContext AddRepoResult.AlreadyExists

        // Fetch the index — this is the real validation: if the URL is bad,
        // unreachable, or non-JSON the failure reason is surfaced directly.
        val fetchResult = fetcher.fetchSingle(url)
        val entries = when (fetchResult) {
            is RepoFetchResult.Success -> fetchResult.entries
            is RepoFetchResult.Failure -> return@withContext when (fetchResult.reason) {
                FailureReason.INVALID_URL -> AddRepoResult.InvalidUrl(fetchResult.message)
                else                      -> AddRepoResult.FetchFailed(fetchResult.message)
            }
        }

        val repoName = entries.firstOrNull()?.name?.substringBefore(" ")?.trim()
            ?: url.substringAfterLast("/").substringBefore(".")
            ?: "Repository"

        val entity = com.mangetsu.data.database.entity.ExtensionRepoEntity(
            name       = repoName,
            url        = url,
            lastSynced = System.currentTimeMillis()
        )
        val id = db.extensionRepoDao().insert(entity)
        Timber.i("RepoManager: added repo '$repoName' id=$id url=$url")

        // Trigger a full state refresh
        scope.launch { refreshState(forceRefresh = false) }

        AddRepoResult.Success(
            repo    = db.extensionRepoDao().getById(id)!!.toDomain(),
            entries = entries.size
        )
    }

    suspend fun removeRepo(repoId: Long) = withContext(Dispatchers.IO) {
        val entity = db.extensionRepoDao().getById(repoId) ?: return@withContext
        cache.evict(entity.url)
        db.extensionRepoDao().deleteById(repoId)
        Timber.d("RepoManager: removed repo $repoId")
        scope.launch { refreshState(forceRefresh = false) }
    }

    // ── Refresh ───────────────────────────────────────────────────────────────

    /**
     * Refreshes all repos. Each repo is fetched concurrently.
     * Failures are surfaced in [RepoScreenState.errors] but don't block others.
     */
    suspend fun refreshAll(forceRefresh: Boolean = true) {
        _state.update { it.copy(isRefreshing = true, errors = emptyList()) }
        refreshState(forceRefresh)
    }

    suspend fun refreshSingle(repoId: Long, forceRefresh: Boolean = true) =
        withContext(Dispatchers.IO) {
            val entity = db.extensionRepoDao().getById(repoId) ?: return@withContext
            val result = fetcher.fetchSingle(entity.url, forceRefresh)
            if (result is RepoFetchResult.Success) {
                db.extensionRepoDao().updateLastSynced(repoId, System.currentTimeMillis())
            }
            scope.launch { refreshState(forceRefresh = false) }
        }

    // ── Install / Update ──────────────────────────────────────────────────────

    /**
     * Downloads and installs a single extension.
     * Progress is tracked in [installProgress].
     */
    suspend fun installExtension(extension: Extension) = withContext(Dispatchers.IO) {
        val pkg = extension.packageName
        if (_installProgress.value[pkg]?.isActive == true) {
            Timber.d("RepoManager: install already in progress for $pkg")
            return@withContext
        }

        setProgress(pkg, InstallProgress.Downloading(pkg, 0))

        try {
            // Observe download states
            scope.launch {
                downloadManager.downloads.collect { map ->
                    val ds = map[pkg] ?: return@collect
                    when (ds) {
                        is DownloadState.Downloading -> setProgress(
                            pkg, InstallProgress.Downloading(pkg, ds.progress)
                        )
                        is DownloadState.Retrying -> setProgress(
                            pkg, InstallProgress.Retrying(pkg, ds.attempt, ds.maxAttempts)
                        )
                        else -> Unit
                    }
                }
            }

            val apkFile = downloadManager.download(pkg, extension.apkUrl)
            setProgress(pkg, InstallProgress.Installing(pkg))

            installer.install(pkg, apkFile.absolutePath)
            // Actual loading triggered by PackageEventReceiver

        } catch (e: Exception) {
            Timber.e(e, "RepoManager: install failed for $pkg")
            setProgress(pkg, InstallProgress.Failed(pkg, e.message ?: "Unknown error"))
        } finally {
            downloadManager.cleanup(pkg)
        }
    }

    /**
     * Updates all extensions that have a newer version available in any repo.
     *
     * Installs are intentionally sequential: launching N concurrent PackageInstaller
     * sessions exhausts Android's session limit and saturates the network. Each
     * [installExtension] call awaits its own completion before the next begins.
     */
    suspend fun updateAll() = withContext(Dispatchers.IO) {
        val updates = versionManager.getUpdates(_state.value.rawEntries)
        Timber.i("RepoManager: updating ${updates.size} extensions")
        updates.forEach { ext -> installExtension(ext) }
    }



    // ── Internal ──────────────────────────────────────────────────────────────

    private suspend fun refreshState(forceRefresh: Boolean) = withContext(Dispatchers.IO) {
        val repos     = db.extensionRepoDao().getAllOnce()
        val repoUrls  = repos.map { it.url }

        if (repoUrls.isEmpty()) {
            _state.value = RepoScreenState(
                repos        = emptyList(),
                extensions   = emptyList(),
                rawEntries   = emptyList(),
                updateCount  = 0,
                isRefreshing = false
            )
            return@withContext
        }

        val multiResult = fetcher.fetchAll(repoUrls, forceRefresh)

        // Update lastSynced for successful repos
        multiResult.perRepo.filterIsInstance<RepoFetchResult.Success>().forEach { success ->
            val entity = repos.find { it.url == success.repoUrl }
            if (entity != null) {
                db.extensionRepoDao().updateLastSynced(entity.id, System.currentTimeMillis())
            }
        }

        val annotated   = versionManager.annotate(multiResult.merged)
        val updateCount = annotated.count { it.status == ExtensionStatus.UPDATE_AVAILABLE }

        _state.update {
            it.copy(
                repos        = repos.map { e -> e.toDomain() },
                extensions   = annotated,
                rawEntries   = multiResult.merged,
                updateCount  = updateCount,
                isRefreshing = false,
                errors       = multiResult.failures.map { f ->
                    RepoError(f.repoUrl, f.reason.name, f.message)
                },
                cacheStats   = RepoCacheStats(
                    totalSizeBytes = cache.totalSizeBytes(),
                    repoCount      = repos.size
                )
            )
        }
    }

    private fun setProgress(packageName: String, progress: InstallProgress) {
        _installProgress.update { it + (packageName to progress) }
    }

    private suspend fun com.mangetsu.data.database.dao.ExtensionRepoDao.getAllOnce() =
        getAll().first()


}

// ── UI state models ───────────────────────────────────────────────────────────

data class RepoScreenState(
    val repos:        List<ExtensionRepo>   = emptyList(),
    val extensions:   List<Extension>       = emptyList(),
    val rawEntries:   List<RepoIndexEntry>  = emptyList(),
    val updateCount:  Int                   = 0,
    val isRefreshing: Boolean               = false,
    val errors:       List<RepoError>       = emptyList(),
    val cacheStats:   RepoCacheStats?       = null
)

data class RepoError(
    val repoUrl: String,
    val kind:    String,
    val message: String
)

data class RepoCacheStats(
    val totalSizeBytes: Long,
    val repoCount:      Int
)

sealed class AddRepoResult {
    data class Success(val repo: ExtensionRepo, val entries: Int) : AddRepoResult()
    data class InvalidUrl(val reason: String)                     : AddRepoResult()
    data class FetchFailed(val message: String)                   : AddRepoResult()
    data object AlreadyExists                                     : AddRepoResult()
}

sealed class InstallProgress {
    abstract val packageName: String
    val isActive: Boolean get() = this is Downloading || this is Retrying || this is Installing

    data class Downloading(override val packageName: String, val percent: Int) : InstallProgress()
    data class Retrying(override val packageName: String, val attempt: Int, val max: Int) : InstallProgress()
    data class Installing(override val packageName: String) : InstallProgress()
    data class Done(override val packageName: String) : InstallProgress()
    data class Failed(override val packageName: String, val message: String) : InstallProgress()
}
