package com.mangetsu.data.extension.repo

import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionStatus
import com.mangetsu.data.database.MangetsuDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Compares installed extension versions against repository versions to
 * produce correctly-annotated [Extension] lists with update status.
 */
@Singleton
class VersionManager @Inject constructor(private val db: MangetsuDatabase) {

    /**
     * Annotates [repoEntries] with [ExtensionStatus] by comparing against
     * the installed versions in Room. Sorted: updates first, then available,
     * then installed, each group alphabetically.
     */
    suspend fun annotate(repoEntries: List<RepoIndexEntry>): List<Extension> =
        withContext(Dispatchers.IO) {
            val installedMap = installedVersionMap()
            val annotated = repoEntries.map { entry ->
                entry.toExtension(installedVersionCode = installedMap[entry.packageName])
            }
            annotated.sortedWith(compareBy({ statusSortKey(it.status) }, { it.name.lowercase() }))
        }

    /** Returns only entries that have an update available. */
    suspend fun getUpdates(repoEntries: List<RepoIndexEntry>): List<Extension> =
        annotate(repoEntries).filter { it.status == ExtensionStatus.UPDATE_AVAILABLE }

    /** Returns the count of available updates without full annotation. */
    suspend fun updateCount(repoEntries: List<RepoIndexEntry>): Int =
        withContext(Dispatchers.IO) {
            val map = installedVersionMap()
            repoEntries.count { e -> (map[e.packageName] ?: -1) < e.versionCode && map.containsKey(e.packageName) }
        }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private suspend fun installedVersionMap(): Map<String, Int> =
        withContext(Dispatchers.IO) {
            db.installedExtensionDao()
                .getAll()
                .first()
                .associate { it.packageName to it.versionCode }
        }

    private fun statusSortKey(status: ExtensionStatus) = when (status) {
        ExtensionStatus.UPDATE_AVAILABLE -> 0
        ExtensionStatus.AVAILABLE        -> 1
        ExtensionStatus.INSTALLED        -> 2
        ExtensionStatus.INSTALLING       -> 3
        ExtensionStatus.ERROR            -> 4
    }
}
