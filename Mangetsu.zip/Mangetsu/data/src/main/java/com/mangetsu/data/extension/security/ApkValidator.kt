package com.mangetsu.data.extension.security

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import timber.log.Timber
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Validates an extension APK before the host attempts to load its DEX.
 *
 * ## Checks performed (in order):
 * 1. **File existence & readability** — the APK path must point to a real, non-empty file.
 * 2. **ZIP integrity** — the APK (which is a ZIP) must be structurally valid.
 * 3. **DEX presence** — the APK must contain at least one `classes*.dex` entry.
 * 4. **Manifest meta-data** — must declare `mangetsu.extension = true`.
 * 5. **Signature consistency** — if the package is already installed, the certificate
 *    of the file on disk must match the certificate of the installed package.
 *    This prevents a malicious replacement of a known-good extension APK.
 * 6. **Package ID sanity** — the APK must not claim to be the host package itself.
 *
 * All checks are designed to fail *closed* — on any unexpected error the APK
 * is considered invalid and loading is refused.
 */
@Singleton
class ApkValidator @Inject constructor(
    private val context: Context
) {

    companion object {
        private const val EXTENSION_MARKER  = "mangetsu.extension"
        private const val HOST_PACKAGE      = "com.mangetsu.app"
        private const val MIN_APK_SIZE      = 4096L    // 4 KB — reject obviously empty files
        private const val MAX_APK_SIZE      = 50L * 1024 * 1024  // 50 MB guard
    }

    data class ValidationResult(
        val valid:   Boolean,
        val reason:  String  = "OK",
        val apkPath: String  = ""
    )

    /**
     * Run all validation checks against the APK at [apkPath].
     *
     * @param apkPath        Absolute path to the APK file to validate.
     * @param packageName    Expected package name (from the DB / repo index).
     * @return [ValidationResult] with `valid = true` only if all checks pass.
     */
    fun validate(apkPath: String, packageName: String): ValidationResult {
        return runCatching {
            checkFileBasics(apkPath)
                ?: checkZipIntegrity(apkPath)
                ?: checkDexPresence(apkPath)
                ?: checkManifestMarker(apkPath, packageName)
                ?: checkNotHostPackage(packageName)
                ?: checkSignatureConsistency(apkPath, packageName)
                ?: ValidationResult(valid = true, apkPath = apkPath)
        }.getOrElse { e ->
            Timber.e(e, "ApkValidator: unexpected error for $apkPath")
            ValidationResult(valid = false, reason = "Validation threw: ${e.message}", apkPath = apkPath)
        }
    }

    // ── Individual checks — return non-null ValidationResult on FAILURE ───────

    private fun checkFileBasics(apkPath: String): ValidationResult? {
        val file = File(apkPath)
        return when {
            !file.exists()       -> fail(apkPath, "File does not exist: $apkPath")
            !file.canRead()      -> fail(apkPath, "File is not readable: $apkPath")
            file.length() < MIN_APK_SIZE ->
                fail(apkPath, "File too small (${file.length()} bytes), likely corrupt")
            file.length() > MAX_APK_SIZE ->
                fail(apkPath, "File exceeds size limit (${file.length()} bytes)")
            else -> null
        }
    }

    private fun checkZipIntegrity(apkPath: String): ValidationResult? {
        return try {
            ZipFile(apkPath).use { /* triggers CRC checks on open */ }
            null
        } catch (e: Exception) {
            fail(apkPath, "ZIP/APK integrity check failed: ${e.message}")
        }
    }

    private fun checkDexPresence(apkPath: String): ValidationResult? {
        val hasDex = ZipFile(apkPath).use { zip ->
            zip.entries().asSequence().any { entry ->
                entry.name.matches(Regex("classes\\d*\\.dex"))
            }
        }
        return if (!hasDex) fail(apkPath, "No DEX file found inside APK") else null
    }

    private fun checkManifestMarker(apkPath: String, packageName: String): ValidationResult? {
        val pm   = context.packageManager
        val info = pm.getPackageArchiveInfo(apkPath, archiveMetaDataFlags()) ?: return fail(
            apkPath, "PackageManager could not parse APK at $apkPath"
        )
        val meta = info.applicationInfo?.metaData

        if (info.packageName != packageName) {
            return fail(
                apkPath,
                "Package name mismatch: expected=$packageName actual=${info.packageName}"
            )
        }

        if (meta?.getBoolean(EXTENSION_MARKER, false) != true) {
            return fail(apkPath, "Missing '$EXTENSION_MARKER' meta-data entry")
        }

        return null
    }

    private fun checkNotHostPackage(packageName: String): ValidationResult? {
        return if (packageName == HOST_PACKAGE)
            fail("", "Extension cannot claim host package ID ($HOST_PACKAGE)")
        else null
    }

    private fun checkSignatureConsistency(apkPath: String, packageName: String): ValidationResult? {
        // Only check if the package is already installed — compares signing certs
        val pm = context.packageManager
        val installedInfo = try {
            pm.getPackageInfo(packageName, installedSignatureFlags())
        } catch (e: PackageManager.NameNotFoundException) {
            return null   // Not installed yet → skip this check
        }

        val installedCert = installedInfo.signingCertificate() ?: return null

        val archiveInfo = pm.getPackageArchiveInfo(apkPath, archiveSignatureFlags())
            ?: return fail(apkPath, "Could not read signature from archive")

        val archiveCert = archiveInfo.signingCertificate()
            ?: return fail(apkPath, "Archive has no signing certificate")

        val match = installedCert.contentEquals(archiveCert)
        return if (!match) fail(apkPath, "Certificate mismatch — APK is not signed by the same key as the installed version")
        else null
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun fail(apkPath: String, reason: String): ValidationResult {
        Timber.w("ApkValidator FAIL [$apkPath]: $reason")
        return ValidationResult(valid = false, reason = reason, apkPath = apkPath)
    }

    private fun archiveMetaDataFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            PackageManager.GET_META_DATA
        else
            @Suppress("DEPRECATION") PackageManager.GET_META_DATA

    private fun archiveSignatureFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            PackageManager.GET_SIGNING_CERTIFICATES
        else
            @Suppress("DEPRECATION") PackageManager.GET_SIGNATURES

    private fun installedSignatureFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            PackageManager.GET_SIGNING_CERTIFICATES
        else
            @Suppress("DEPRECATION") PackageManager.GET_SIGNATURES

    @Suppress("DEPRECATION")
    private fun PackageInfo.signingCertificate(): ByteArray? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
        } else {
            signatures?.firstOrNull()?.toByteArray()
        }
    }

    /** SHA-256 fingerprint of a byte array (for logging only). */
    fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
