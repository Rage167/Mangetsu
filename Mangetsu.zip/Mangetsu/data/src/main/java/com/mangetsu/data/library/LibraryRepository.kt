package com.mangetsu.data.library

import com.mangetsu.core.model.Category
import com.mangetsu.core.model.LibraryFilter
import com.mangetsu.core.model.LibrarySortMode
import com.mangetsu.core.model.Manga
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.entity.CategoryEntity
import com.mangetsu.data.database.entity.MangaCategoryEntity
import com.mangetsu.data.database.toDomain
import com.mangetsu.data.database.toEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LibraryRepository @Inject constructor(private val db: MangetsuDatabase) {

    // ── Library manga ─────────────────────────────────────────────────────────

    fun getLibraryManga(filter: LibraryFilter = LibraryFilter()): Flow<List<Manga>> {
        val flow = if (filter.sortAscending) {
            db.mangaDao().getLibraryMangaSorted(filter.categoryId, filter.sortMode.name)
        } else {
            db.mangaDao().getLibraryMangaSortedDesc(filter.categoryId, filter.sortMode.name)
        }
        return flow.map { entities ->
            entities
                .map { it.toDomain() }
                .filter { manga ->
                    (filter.searchQuery.isBlank() ||
                        manga.title.contains(filter.searchQuery, ignoreCase = true)) &&
                    (!filter.showUnreadOnly || manga.unreadCount > 0)
                }
        }
    }

    fun getLibraryCount(): Flow<Int> = db.mangaDao().getLibraryCount()
    fun getTotalUnread(): Flow<Int>   = db.mangaDao().getTotalUnreadCount()

    suspend fun getMangaById(id: Long): Manga? =
        db.mangaDao().getMangaById(id)?.toDomain()

    suspend fun getMangaByUrl(url: String, sourceId: Long): Manga? =
        db.mangaDao().getMangaByUrl(url, sourceId)?.toDomain()

    suspend fun addToLibrary(manga: Manga): Long = withContext(Dispatchers.IO) {
        val existing = db.mangaDao().getMangaByUrl(manga.url, manga.sourceId)
        val id = if (existing != null) {
            db.mangaDao().setInLibrary(existing.id, true, System.currentTimeMillis())
            existing.id
        } else {
            db.mangaDao().upsert(
                manga.copy(inLibrary = true, dateAdded = System.currentTimeMillis()).toEntity()
            )
        }
        Timber.d("LibraryRepository: added manga $id to library")
        id
    }

    suspend fun removeFromLibrary(mangaId: Long) = withContext(Dispatchers.IO) {
        db.mangaDao().setInLibrary(mangaId, false, 0L)
        db.mangaCategoryDao().deleteForManga(mangaId)
        Timber.d("LibraryRepository: removed manga $mangaId from library")
    }

    suspend fun upsertManga(manga: Manga): Long =
        db.mangaDao().upsert(manga.toEntity())

    suspend fun updateManga(manga: Manga) =
        db.mangaDao().update(manga.toEntity())

    suspend fun setFavorite(mangaId: Long, favorite: Boolean) =
        db.mangaDao().setFavorite(mangaId, favorite)

    suspend fun refreshCounts(mangaId: Long) =
        db.mangaDao().refreshCounts(mangaId)

    // ── Categories ────────────────────────────────────────────────────────────

    fun getCategories(): Flow<List<Category>> =
        db.categoryDao().getAll().map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun getCategoriesOnce(): List<Category> =
        db.categoryDao().getAllOnce().map { it.toDomain() }

    suspend fun getCategoryById(id: Long): Category? =
        db.categoryDao().getById(id)?.toDomain()

    suspend fun createCategory(name: String): Category = withContext(Dispatchers.IO) {
        val existing = db.categoryDao().getAllOnce()
        val order    = existing.maxOfOrNull { it.sortOrder }?.plus(1) ?: 0
        val entity   = CategoryEntity(name = name, sortOrder = order)
        val id       = db.categoryDao().insert(entity)
        db.categoryDao().getById(id)!!.toDomain()
    }

    suspend fun renameCategory(id: Long, name: String) {
        val cat = db.categoryDao().getById(id) ?: return
        db.categoryDao().update(cat.copy(name = name))
    }

    suspend fun deleteCategory(id: Long) = withContext(Dispatchers.IO) {
        db.categoryDao().deleteById(id)
        // manga_category rows cascade via FK
    }

    suspend fun setCategorySort(id: Long, mode: LibrarySortMode, ascending: Boolean) {
        val cat = db.categoryDao().getById(id) ?: return
        db.categoryDao().update(cat.copy(sortMode = mode.name, sortAscending = ascending))
    }

    suspend fun reorderCategories(orderedIds: List<Long>) = withContext(Dispatchers.IO) {
        orderedIds.forEachIndexed { index, id ->
            db.categoryDao().updateOrder(id, index)
        }
    }

    // ── Manga ↔ Category ──────────────────────────────────────────────────────

    fun getCategoryIdsForManga(mangaId: Long): Flow<List<Long>> =
        db.mangaCategoryDao().getCategoryIdsForManga(mangaId)

    suspend fun setMangaCategories(mangaId: Long, categoryIds: List<Long>) =
        db.mangaCategoryDao().setCategories(mangaId, categoryIds)

    suspend fun addMangaToCategory(mangaId: Long, categoryId: Long) =
        db.mangaCategoryDao().insert(MangaCategoryEntity(mangaId, categoryId))

    suspend fun removeMangaFromCategory(mangaId: Long, categoryId: Long) =
        db.mangaCategoryDao().delete(mangaId, categoryId)

    // ── Library with category counts ──────────────────────────────────────────

    fun getLibraryWithCategories(): Flow<LibraryWithCategories> = combine(
        db.categoryDao().getAll(),
        db.mangaDao().getLibraryManga()
    ) { cats, mangas ->
        LibraryWithCategories(
            categories   = cats.map { it.toDomain() },
            allManga     = mangas.map { it.toDomain() },
            totalCount   = mangas.size,
            unreadCount  = mangas.sumOf { it.unreadCount }
        )
    }
}

data class LibraryWithCategories(
    val categories:  List<Category>,
    val allManga:    List<Manga>,
    val totalCount:  Int,
    val unreadCount: Int
)

// ── Entity mappers ────────────────────────────────────────────────────────────

private fun CategoryEntity.toDomain() = Category(
    id            = id,
    name          = name,
    sortOrder     = sortOrder,
    sortMode      = try { LibrarySortMode.valueOf(sortMode) } catch (e: Exception) { LibrarySortMode.ALPHABETICAL },
    sortAscending = sortAscending,
    isDefault     = isDefault
)
