package com.mangetsu.data.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import coil.Coil
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ErrorResult
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.size.Size
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * High-performance manga image loading pipeline.
 *
 * Features:
 * - 256MB memory cache (LRU, bitmap-pool aware)
 * - 512MB disk cache (OkHttp-backed, persistent across sessions)
 * - Prefetch window: loads ±[PREFETCH_WINDOW] pages around current
 * - Cancelled prefetch jobs tracked to avoid duplicate work
 * - Reuses the app-wide [OkHttpClient] (connection pooling)
 * - Downsamples large images to avoid OOM on low-end devices
 */
@Singleton
class ReaderImageLoader @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient
) {
    companion object {
        private const val MEMORY_CACHE_MB  = 256L
        private const val DISK_CACHE_MB    = 512L
        private const val DISK_CACHE_DIR   = "reader_image_cache"
        private const val PREFETCH_WINDOW  = 3       // pages ahead/behind to prefetch
        private const val MAX_BITMAP_DIM   = 4096    // max width or height before downsampling
    }

    // ── Coil ImageLoader ──────────────────────────────────────────────────────

    val imageLoader: ImageLoader by lazy {
        ImageLoader.Builder(context)
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizeBytes((MEMORY_CACHE_MB * 1024 * 1024).toInt())
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(context.cacheDir.resolve(DISK_CACHE_DIR))
                    .maxSizeBytes(DISK_CACHE_MB * 1024 * 1024)
                    .build()
            }
            .okHttpClient(okHttpClient)
            .crossfade(true)
            .allowHardware(true)          // GPU-backed bitmaps where supported
            .allowRgb565(true)            // half memory on older devices (no alpha needed)
            .components {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
    }

    // ── Prefetch ──────────────────────────────────────────────────────────────

    private val prefetchScope  = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    /** Tracks in-flight prefetch jobs keyed by page URL to avoid duplicates. */
    private val prefetchJobs   = ConcurrentHashMap<String, Job>()
    /** URLs already loaded this session — skip re-prefetching. */
    private val prefetchedUrls = ConcurrentHashMap.newKeySet<String>()

    /**
     * Prefetches pages in the range [currentIndex - window, currentIndex + window]
     * from [allUrls]. Already-cached and already-prefetching URLs are skipped.
     *
     * @param allUrls     Full ordered list of page image URLs for the chapter.
     * @param currentIndex Current page index.
     */
    fun prefetch(allUrls: List<String?>, currentIndex: Int) {
        val start = (currentIndex - PREFETCH_WINDOW).coerceAtLeast(0)
        val end   = (currentIndex + PREFETCH_WINDOW).coerceAtMost(allUrls.lastIndex)

        for (i in start..end) {
            val url = allUrls[i] ?: continue
            if (url in prefetchedUrls) continue
            if (prefetchJobs.containsKey(url)) continue

            val job = prefetchScope.launch {
                val request = ImageRequest.Builder(context)
                    .data(url)
                    .size(Size.ORIGINAL)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .networkCachePolicy(CachePolicy.ENABLED)
                    .build()

                when (val result = imageLoader.execute(request)) {
                    is SuccessResult -> {
                        prefetchedUrls.add(url)
                        Timber.v("Prefetched page $i: $url")
                    }
                    is ErrorResult -> Timber.w("Prefetch failed page $i: ${result.throwable.message}")
                }
                prefetchJobs.remove(url)
            }
            prefetchJobs[url] = job
        }
    }

    /**
     * Cancels prefetch jobs for pages outside the current window.
     * Called when the user jumps far ahead/back.
     */
    fun cancelOutOfWindowPrefetches(allUrls: List<String?>, currentIndex: Int) {
        val keepStart = (currentIndex - PREFETCH_WINDOW).coerceAtLeast(0)
        val keepEnd   = (currentIndex + PREFETCH_WINDOW).coerceAtMost(allUrls.lastIndex)
        val keepUrls  = allUrls.subList(keepStart, keepEnd + 1).filterNotNull().toSet()

        val toCancel = prefetchJobs.keys - keepUrls
        toCancel.forEach { url ->
            prefetchJobs.remove(url)?.cancel()
            Timber.v("Cancelled prefetch: $url")
        }
    }

    /** Cancels all in-flight prefetch jobs (called on chapter change or reader close). */
    fun cancelAllPrefetches() {
        prefetchJobs.values.forEach { it.cancel() }
        prefetchJobs.clear()
        prefetchedUrls.clear()
        Timber.d("ReaderImageLoader: all prefetches cancelled")
    }

    /** Evicts the chapter's pages from memory cache (keeps disk cache). */
    fun evictChapterFromMemory(urls: List<String?>) {
        val memCache = imageLoader.memoryCache ?: return
        urls.filterNotNull().forEach { url ->
            memCache.remove(MemoryCache.Key(url))
        }
        Timber.d("ReaderImageLoader: evicted ${urls.size} pages from memory")
    }

    // ── Bitmap utilities ──────────────────────────────────────────────────────

    /**
     * Calculates inSampleSize to downsample an image if it exceeds [MAX_BITMAP_DIM]
     * in either dimension. Used by offline page loading from disk files.
     */
    fun calculateInSampleSize(options: BitmapFactory.Options): Int {
        val height = options.outHeight
        val width  = options.outWidth
        var inSampleSize = 1
        if (height > MAX_BITMAP_DIM || width > MAX_BITMAP_DIM) {
            val halfH = height / 2
            val halfW = width  / 2
            while (halfH / inSampleSize >= MAX_BITMAP_DIM &&
                   halfW / inSampleSize >= MAX_BITMAP_DIM) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    /** Preferred bitmap config — RGB_565 saves 50% memory vs ARGB_8888 for opaque manga pages. */
    val preferredBitmapConfig: Bitmap.Config
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Bitmap.Config.HARDWARE else Bitmap.Config.RGB_565
}
