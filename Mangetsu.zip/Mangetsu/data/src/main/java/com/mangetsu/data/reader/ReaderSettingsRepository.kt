package com.mangetsu.data.reader

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mangetsu.core.model.ReadingMode
import com.mangetsu.core.model.ReaderSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.readerDataStore: DataStore<Preferences>
    by preferencesDataStore(name = "reader_settings")

@Singleton
class ReaderSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val READING_MODE    = stringPreferencesKey("reading_mode")
        val BRIGHTNESS      = floatPreferencesKey("brightness")
        val PAGE_SPACING    = intPreferencesKey("page_spacing")
        val SCALE_TO_FIT    = booleanPreferencesKey("scale_to_fit")
        val SHOW_PAGE_NUM   = booleanPreferencesKey("show_page_numbers")
        val KEEP_SCREEN_ON  = booleanPreferencesKey("keep_screen_on")
        val CROP_BORDERS    = booleanPreferencesKey("crop_borders")
        val MAX_SCALE       = floatPreferencesKey("max_scale_factor")
    }

    val settings: Flow<ReaderSettings> = context.readerDataStore.data.map { prefs ->
        ReaderSettings(
            readingMode     = prefs[Keys.READING_MODE]?.let {
                runCatching { ReadingMode.valueOf(it) }.getOrDefault(ReadingMode.VERTICAL)
            } ?: ReadingMode.VERTICAL,
            brightness      = prefs[Keys.BRIGHTNESS]     ?: -1f,
            pageSpacingDp   = prefs[Keys.PAGE_SPACING]   ?: 8,
            scaleToFit      = prefs[Keys.SCALE_TO_FIT]   ?: true,
            showPageNumbers = prefs[Keys.SHOW_PAGE_NUM]  ?: true,
            keepScreenOn    = prefs[Keys.KEEP_SCREEN_ON] ?: true,
            cropBorders     = prefs[Keys.CROP_BORDERS]   ?: false,
            maxScaleFactor  = prefs[Keys.MAX_SCALE]      ?: 5f
        )
    }

    suspend fun save(settings: ReaderSettings) {
        context.readerDataStore.edit { prefs ->
            prefs[Keys.READING_MODE]   = settings.readingMode.name
            prefs[Keys.BRIGHTNESS]     = settings.brightness
            prefs[Keys.PAGE_SPACING]   = settings.pageSpacingDp
            prefs[Keys.SCALE_TO_FIT]   = settings.scaleToFit
            prefs[Keys.SHOW_PAGE_NUM]  = settings.showPageNumbers
            prefs[Keys.KEEP_SCREEN_ON] = settings.keepScreenOn
            prefs[Keys.CROP_BORDERS]   = settings.cropBorders
            prefs[Keys.MAX_SCALE]      = settings.maxScaleFactor
        }
    }
}
