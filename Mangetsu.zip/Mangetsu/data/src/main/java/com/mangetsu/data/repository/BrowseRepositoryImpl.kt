package com.mangetsu.data.repository

import com.mangetsu.core.model.Manga
import com.mangetsu.core.util.toDomainManga
import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.domain.repository.BrowseRepository
import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.model.SManga
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * UPDATED BrowseRepositoryImpl
 *
 * All source calls now go through [ExtensionRepositoryImpl.safe*] methods,
 * which route through [SafeExtensionCaller] for full error isolation,
 * timeout protection, and circuit-breaker support.
 *
 * If the underlying [ExtensionResult] is an error the exception is rethrown
 * here so the domain use-case's safeCall wrapper catches it as a [Result.Error].
 */
@Singleton
class BrowseRepositoryImpl @Inject constructor(
    private val extRepo: ExtensionRepositoryImpl
) : BrowseRepository {

    override suspend fun getPopularManga(source: MangaSource, page: Int): MangasPage =
        withContext(Dispatchers.IO) {
            extRepo.safePopular(source.id, page).getOrThrow()
        }

    override suspend fun getLatestManga(source: MangaSource, page: Int): MangasPage =
        withContext(Dispatchers.IO) {
            extRepo.safeLatest(source.id, page).getOrThrow()
        }

    override suspend fun searchManga(
        source:  MangaSource,
        page:    Int,
        query:   String,
        filters: FilterList
    ): MangasPage = withContext(Dispatchers.IO) {
        extRepo.safeSearch(source.id, page, query, filters).getOrThrow()
    }

    override suspend fun getMangaDetails(source: MangaSource, manga: Manga): Manga =
        withContext(Dispatchers.IO) {
            val sManga = SManga(id = manga.url, title = manga.title, url = manga.url)
            val result = extRepo.safeMangaDetails(source.id, sManga).getOrThrow()
            result.toDomainManga(source.id).copy(id = manga.id, inLibrary = manga.inLibrary)
        }
}
