package com.mangetsu.data.repository

import com.mangetsu.core.model.Chapter
import com.mangetsu.core.util.toDomainChapter
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.toDomain
import com.mangetsu.data.database.toEntity
import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.domain.repository.ChapterRepository
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.model.SManga
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * UPDATED ChapterRepositoryImpl
 *
 * [syncChapters] now calls through [ExtensionRepositoryImpl.safeChapterList]
 * so the fetch is wrapped by [SafeExtensionCaller] (timeout, circuit-breaker,
 * error isolation).
 */
@Singleton
class ChapterRepositoryImpl @Inject constructor(
    db: MangetsuDatabase,
    private val extRepo: ExtensionRepositoryImpl
) : ChapterRepository {

    private val chapterDao = db.chapterDao()

    override fun getChaptersForManga(mangaId: Long): Flow<List<Chapter>> =
        chapterDao.getChaptersByMangaId(mangaId).map { list -> list.map { it.toDomain() } }

    override suspend fun getChapterById(id: Long): Chapter? =
        chapterDao.getChapterById(id)?.toDomain()

    override suspend fun syncChapters(
        mangaId: Long,
        source:  MangaSource,
        manga:   com.mangetsu.core.model.Manga
    ): List<Chapter> = withContext(Dispatchers.IO) {
        val sManga   = SManga(id = manga.url, title = manga.title, url = manga.url)
        val sChapters = extRepo.safeChapterList(source.id, sManga).getOrThrow()

        val chapters = sChapters.mapIndexed { idx, sc ->
            sc.toDomainChapter(mangaId, source.id, sourceOrder = idx)
        }

        chapterDao.upsertAll(chapters.map { it.toEntity() })
        chapters
    }

    override suspend fun markChapterRead(chapterId: Long, lastPage: Int) =
        chapterDao.markRead(chapterId, lastPage)

    override suspend fun markAllRead(mangaId: Long) =
        chapterDao.markAllRead(mangaId)

    override suspend fun updateDownloadStatus(chapterId: Long, downloaded: Boolean, pageCount: Int) =
        chapterDao.updateDownload(chapterId, downloaded, pageCount)
}
