package com.mangetsu.data.repository

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.ListenableWorker
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.mangetsu.core.model.Download
import com.mangetsu.core.model.DownloadStatus
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.domain.repository.DownloadRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import timber.log.Timber
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.reflect.KClass

@Singleton
class DownloadRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val workManager: WorkManager,
    private val db:          MangetsuDatabase,
    /** Injected worker class to break the data→app circular dependency. */
    @DownloadWorkerClass private val workerClass: Class<out ListenableWorker>
) : DownloadRepository {

    companion object {
        const val KEY_MANGA_ID   = "manga_id"
        const val KEY_CHAPTER_ID = "chapter_id"
        private const val WORK_PREFIX = "download_chapter_"
    }

    private val _downloads = MutableStateFlow<List<Download>>(emptyList())
    override fun getDownloads(): Flow<List<Download>> = _downloads.asStateFlow()

    override suspend fun enqueueDownload(mangaId: Long, chapterId: Long) {
        val manga   = db.mangaDao().getMangaById(mangaId)       ?: return
        val chapter = db.chapterDao().getChapterById(chapterId) ?: return

        if (_downloads.value.any { it.chapterId == chapterId }) return

        _downloads.update { it + Download(
            mangaId     = mangaId,
            chapterId   = chapterId,
            mangaTitle  = manga.title,
            chapterName = chapter.name,
            sourceId    = chapter.sourceId,
            status      = DownloadStatus.QUEUED
        )}

        val request = OneTimeWorkRequest.Builder(workerClass)
            .setInputData(Data.Builder()
                .putLong(KEY_MANGA_ID,   mangaId)
                .putLong(KEY_CHAPTER_ID, chapterId)
                .build())
            .setConstraints(Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("chapter_$chapterId")
            .addTag("manga_$mangaId")
            .build()

        workManager.enqueueUniqueWork(
            "$WORK_PREFIX$chapterId",
            ExistingWorkPolicy.KEEP,
            request
        )
        Timber.d("DownloadRepositoryImpl: enqueued chapter $chapterId")
    }

    override suspend fun cancelDownload(chapterId: Long) {
        workManager.cancelUniqueWork("$WORK_PREFIX$chapterId")
        _downloads.update { it.filter { d -> d.chapterId != chapterId } }
    }

    override suspend fun cancelAllDownloads() {
        _downloads.value.forEach { workManager.cancelAllWorkByTag("chapter_${it.chapterId}") }
        _downloads.value = emptyList()
    }

    override suspend fun deleteDownloadedChapter(chapterId: Long) {
        val chapter = db.chapterDao().getChapterById(chapterId) ?: return
        File(context.filesDir, "downloads/${chapter.mangaId}/$chapterId").deleteRecursively()
        db.chapterDao().updateDownload(chapterId, downloaded = false, pageCount = 0)
    }
}
