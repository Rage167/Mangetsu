package com.mangetsu.data.repository

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class DownloadWorkerClass
