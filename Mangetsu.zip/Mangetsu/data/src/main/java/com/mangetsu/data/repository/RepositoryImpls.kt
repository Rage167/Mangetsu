package com.mangetsu.data.repository

import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.History
import com.mangetsu.core.model.Manga
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.entity.HistoryEntity
import com.mangetsu.data.database.toDomain
import com.mangetsu.data.extension.repo.AddRepoResult
import com.mangetsu.data.extension.repo.MultiRepoFetcher
import com.mangetsu.data.extension.repo.RepoManager
import com.mangetsu.data.extension.repo.UrlValidationResult
import com.mangetsu.data.library.LibraryRepository as DataLibraryRepository
import com.mangetsu.domain.repository.ExtensionRepoRepository
import com.mangetsu.domain.repository.HistoryRepository
import com.mangetsu.domain.repository.LibraryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// ── LibraryRepositoryImpl ─────────────────────────────────────────────────────
// Delegates all work to the richer data.library.LibraryRepository so there is
// a single source of truth. Domain use cases go through this thin adapter.

@Singleton
class LibraryRepositoryImpl @Inject constructor(
    private val delegate: DataLibraryRepository
) : LibraryRepository {

    override fun getLibraryManga(): Flow<List<Manga>> =
        delegate.getLibraryManga()

    override suspend fun getMangaByIdOrNull(id: Long): Manga? =
        delegate.getMangaById(id)

    override suspend fun getMangaByUrl(url: String, sourceId: Long): Manga? =
        delegate.getMangaByUrl(url, sourceId)

    override suspend fun upsertManga(manga: Manga): Long =
        delegate.upsertManga(manga)

    override suspend fun setFavorite(mangaId: Long, favorite: Boolean) =
        delegate.setFavorite(mangaId, favorite)

    override suspend fun updateManga(manga: Manga) =
        delegate.updateManga(manga)

    override suspend fun deleteManga(mangaId: Long) {
        // LibraryRepository doesn't expose delete directly — set inLibrary = false
        delegate.removeFromLibrary(mangaId)
    }

    override fun getUnreadCountFlow(): Flow<Int> =
        delegate.getTotalUnread()
}

// ── ExtensionRepoRepositoryImpl ───────────────────────────────────────────────

@Singleton
class ExtensionRepoRepositoryImpl @Inject constructor(
    private val repoManager: RepoManager,
    private val fetcher:     MultiRepoFetcher
) : ExtensionRepoRepository {

    override fun getRepos(): Flow<List<ExtensionRepo>> = repoManager.getRepos()

    override suspend fun addRepo(url: String): ExtensionRepo =
        when (val r = repoManager.addRepo(url)) {
            is AddRepoResult.Success     -> r.repo
            is AddRepoResult.InvalidUrl  -> throw IllegalArgumentException("Invalid URL: ${r.reason}")
            is AddRepoResult.FetchFailed -> throw Exception("Fetch failed: ${r.message}")
            AddRepoResult.AlreadyExists  -> throw IllegalStateException("Repository already exists")
        }

    override suspend fun removeRepo(id: Long) = repoManager.removeRepo(id)

    override suspend fun refreshRepo(id: Long) = repoManager.refreshSingle(id, forceRefresh = true)

    override suspend fun validateRepoUrl(url: String): Boolean =
        fetcher.validateUrl(url) is UrlValidationResult.Valid
}

// ── HistoryRepositoryImpl ─────────────────────────────────────────────────────

@Singleton
class HistoryRepositoryImpl @Inject constructor(
    private val db: MangetsuDatabase
) : HistoryRepository {

    private val historyDao = db.historyDao()
    private val mangaDao   = db.mangaDao()
    private val chapterDao = db.chapterDao()

    override fun getHistory(): Flow<List<History>> =
        historyDao.getHistory().map { list -> list.map { it.toDomain() } }

    override suspend fun upsertHistory(mangaId: Long, chapterId: Long, lastPage: Int) {
        val manga   = mangaDao.getMangaById(mangaId)       ?: return
        val chapter = chapterDao.getChapterById(chapterId) ?: return
        historyDao.upsert(
            HistoryEntity(
                mangaId      = mangaId,
                chapterId    = chapterId,
                mangaTitle   = manga.title,
                chapterName  = chapter.name,
                thumbnailUrl = manga.thumbnailUrl,
                lastRead     = System.currentTimeMillis(),
                lastPageRead = lastPage,
                chapterNumber = chapter.chapterNumber
            )
        )
    }

    override suspend fun deleteHistory(mangaId: Long) = historyDao.deleteByMangaId(mangaId)
    override suspend fun clearAllHistory()             = historyDao.clearAll()
}
