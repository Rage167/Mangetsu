package com.mangetsu.data.tracking

import com.mangetsu.core.model.TrackRecord
import com.mangetsu.core.model.TrackResult
import com.mangetsu.core.model.TrackSearch
import com.mangetsu.core.model.TrackStatus
import com.mangetsu.core.model.Tracker
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.entity.MangaTrackingEntity
import com.mangetsu.data.database.entity.TrackerAuthEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Central registry for all [TrackerService] implementations.
 *
 * To add a new tracker:
 * 1. Implement [TrackerService]
 * 2. Add it to [trackers] via Hilt multibinding or direct injection
 * 3. The manager handles auth persistence, record sync, and error isolation
 */
@Singleton
class TrackerManager @Inject constructor(
    private val db: MangetsuDatabase
) {
    /** All registered tracker implementations. Add via Hilt multibinding in prod. */
    private val trackers = mutableMapOf<String, TrackerService>()

    fun registerTracker(service: TrackerService) {
        trackers[service.id] = service
        Timber.d("TrackerManager: registered '${service.name}'")
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    fun getAvailableTrackers(): List<Tracker> = trackers.values.map { it.toTracker() }

    suspend fun getLoggedInTrackers(): List<Tracker> = trackers.values
        .filter { it.isLoggedIn() }
        .map { it.toTracker() }

    fun getTrackingForManga(mangaId: Long): Flow<List<TrackRecord>> =
        db.mangaTrackingDao().getTrackingForManga(mangaId).map { entities ->
            entities.map { it.toDomain() }
        }

    suspend fun getTrackingForMangaOnce(mangaId: Long): List<TrackRecord> =
        db.mangaTrackingDao().getTrackingForMangaOnce(mangaId).map { it.toDomain() }

    // ── Search ────────────────────────────────────────────────────────────────

    suspend fun search(trackerId: String, query: String): TrackResult<List<TrackSearch>> {
        val service = trackers[trackerId] ?: return TrackResult.Error("Tracker not found: $trackerId")
        if (!service.isLoggedIn()) return TrackResult.NotLoggedIn
        return withContext(Dispatchers.IO) {
            runCatching { service.search(query) }
                .getOrElse { TrackResult.Error(it.message ?: "Search failed", it) }
        }
    }

    // ── Link manga to tracker ─────────────────────────────────────────────────

    suspend fun addTracking(
        mangaId:   Long,
        trackerId: String,
        remoteId:  Long
    ): TrackResult<TrackRecord> = withContext(Dispatchers.IO) {
        val service = trackers[trackerId] ?: return@withContext TrackResult.Error("Tracker not found")
        if (!service.isLoggedIn()) return@withContext TrackResult.NotLoggedIn

        when (val result = service.addToList(remoteId)) {
            is TrackResult.Success -> {
                db.mangaTrackingDao().upsert(result.data.toEntity(mangaId))
                Timber.i("TrackerManager: linked manga $mangaId to $trackerId#$remoteId")
                result
            }
            else -> result
        }
    }

    suspend fun removeTracking(mangaId: Long, trackerId: String) {
        db.mangaTrackingDao().delete(mangaId, trackerId)
    }

    // ── Sync progress ─────────────────────────────────────────────────────────

    suspend fun syncProgress(
        mangaId:      Long,
        trackerId:    String,
        chaptersRead: Int
    ): TrackResult<TrackRecord> = withContext(Dispatchers.IO) {
        val service  = trackers[trackerId] ?: return@withContext TrackResult.Error("Tracker not found")
        val existing = db.mangaTrackingDao().getTracking(mangaId, trackerId)
            ?: return@withContext TrackResult.Error("No tracking record found")

        if (existing.chaptersRead >= chaptersRead) return@withContext TrackResult.Success(existing.toDomain())

        val updated = existing.toDomain().copy(chaptersRead = chaptersRead)
        when (val result = service.update(updated)) {
            is TrackResult.Success -> {
                db.mangaTrackingDao().updateProgress(
                    mangaId, trackerId, chaptersRead, System.currentTimeMillis()
                )
                result
            }
            else -> result
        }
    }

    suspend fun updateScore(mangaId: Long, trackerId: String, score: Float): TrackResult<TrackRecord> =
        withContext(Dispatchers.IO) {
            val service  = trackers[trackerId] ?: return@withContext TrackResult.Error("Tracker not found")
            val existing = db.mangaTrackingDao().getTracking(mangaId, trackerId)
                ?: return@withContext TrackResult.Error("No tracking record")
            val updated = existing.toDomain().copy(score = score)
            when (val result = service.update(updated)) {
                is TrackResult.Success -> {
                    db.mangaTrackingDao().updateScore(mangaId, trackerId, score)
                    result
                }
                else -> result
            }
        }

    suspend fun updateStatus(mangaId: Long, trackerId: String, status: TrackStatus): TrackResult<TrackRecord> =
        withContext(Dispatchers.IO) {
            val service  = trackers[trackerId] ?: return@withContext TrackResult.Error("Tracker not found")
            val existing = db.mangaTrackingDao().getTracking(mangaId, trackerId)
                ?: return@withContext TrackResult.Error("No tracking record")
            val updated = existing.toDomain().copy(status = status)
            when (val result = service.update(updated)) {
                is TrackResult.Success -> {
                    db.mangaTrackingDao().updateStatus(mangaId, trackerId, status.value)
                    result
                }
                else -> result
            }
        }

    // ── Refresh from remote ───────────────────────────────────────────────────

    suspend fun refreshAll(mangaId: Long) = withContext(Dispatchers.IO) {
        val records = db.mangaTrackingDao().getTrackingForMangaOnce(mangaId)
        records.forEach { entity ->
            val service = trackers[entity.trackerId] ?: return@forEach
            if (!service.isLoggedIn()) return@forEach
            when (val result = service.refresh(entity.remoteId)) {
                is TrackResult.Success -> db.mangaTrackingDao().upsert(result.data.toEntity(mangaId))
                else -> Timber.w("TrackerManager: refresh failed for ${entity.trackerId}")
            }
        }
    }

    // ── Auth ──────────────────────────────────────────────────────────────────

    fun getLoginUrl(trackerId: String): String? = trackers[trackerId]?.getLoginUrl()

    suspend fun handleLoginCallback(trackerId: String, url: String): TrackResult<Tracker> {
        val service = trackers[trackerId] ?: return TrackResult.Error("Tracker not found")
        return when (val result = service.handleLoginCallback(url)) {
            is TrackResult.Success -> {
                db.trackerAuthDao().upsert(
                    TrackerAuthEntity(
                        trackerId  = trackerId,
                        username   = result.data.username,
                        isLoggedIn = true
                    )
                )
                result
            }
            else -> result
        }
    }

    suspend fun logout(trackerId: String) {
        trackers[trackerId]?.logout()
        db.trackerAuthDao().logout(trackerId)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun TrackerService.toTracker() = Tracker(
        id         = id,
        name       = name,
        logoUrl    = logoUrl,
        isLoggedIn = false,  // refreshed via isLoggedIn() when needed
        username   = null
    )
}

// ── Entity mappers ────────────────────────────────────────────────────────────

private fun MangaTrackingEntity.toDomain() = TrackRecord(
    mangaId       = mangaId,
    trackerId     = trackerId,
    remoteId      = remoteId,
    remoteUrl     = remoteUrl,
    title         = title,
    score         = score,
    status        = TrackStatus.fromValue(status),
    chaptersRead  = chaptersRead,
    totalChapters = totalChapters,
    startDate     = startDate,
    finishDate    = finishDate,
    lastSynced    = lastSynced
)

private fun TrackRecord.toEntity(mangaId: Long) = MangaTrackingEntity(
    mangaId       = mangaId,
    trackerId     = trackerId,
    remoteId      = remoteId,
    remoteUrl     = remoteUrl,
    title         = title,
    score         = score,
    status        = status.value,
    chaptersRead  = chaptersRead,
    totalChapters = totalChapters,
    startDate     = startDate,
    finishDate    = finishDate,
    lastSynced    = System.currentTimeMillis()
)
