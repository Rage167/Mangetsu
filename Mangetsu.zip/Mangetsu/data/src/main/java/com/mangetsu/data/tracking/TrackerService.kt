package com.mangetsu.data.tracking

import com.mangetsu.core.model.TrackRecord
import com.mangetsu.core.model.TrackResult
import com.mangetsu.core.model.TrackSearch
import com.mangetsu.core.model.Tracker

/**
 * Abstraction layer for tracking services.
 *
 * Implement this interface to add support for a new tracker
 * (AniList, MyAnimeList, Kitsu, MangaUpdates, etc.)
 *
 * All methods return [TrackResult] so callers never need to handle exceptions.
 */
interface TrackerService {

    /** Stable ID for this tracker (e.g. "anilist", "mal", "kitsu"). */
    val id: String

    /** Display name. */
    val name: String

    /** URL to the tracker logo/icon. */
    val logoUrl: String?

    // ── Auth ──────────────────────────────────────────────────────────────────

    /** Returns the OAuth or login URL the user should open in a WebView / browser. */
    fun getLoginUrl(): String

    /** Called with the callback URL after the user completes OAuth. */
    suspend fun handleLoginCallback(url: String): TrackResult<Tracker>

    /** Logs out and clears stored tokens. */
    suspend fun logout(): TrackResult<Unit>

    /** Returns true if the user is currently authenticated. */
    suspend fun isLoggedIn(): Boolean

    // ── Search ────────────────────────────────────────────────────────────────

    /** Searches the tracker for manga matching [query]. */
    suspend fun search(query: String): TrackResult<List<TrackSearch>>

    // ── Record management ─────────────────────────────────────────────────────

    /** Adds [manga] to the user's list and returns the initial [TrackRecord]. */
    suspend fun addToList(remoteId: Long): TrackResult<TrackRecord>

    /** Pushes local [record] state to the remote tracker. */
    suspend fun update(record: TrackRecord): TrackResult<TrackRecord>

    /** Fetches the current remote state for the given [remoteId]. */
    suspend fun refresh(remoteId: Long): TrackResult<TrackRecord>

    /** Score range and step for this tracker's scoring system. */
    fun scoreRange(): ClosedFloatingPointRange<Float> = 0f..10f
    fun scoreStep(): Float = 0.5f

    /** The status values this tracker supports. */
    fun supportedStatuses(): List<com.mangetsu.core.model.TrackStatus> =
        com.mangetsu.core.model.TrackStatus.entries
}
