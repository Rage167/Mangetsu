package com.mangetsu.data.updates

import com.mangetsu.core.model.LibraryUpdateStatus
import com.mangetsu.core.model.MangaUpdate
import com.mangetsu.core.model.UpdateCheckState
import com.mangetsu.core.model.UpdatesResult
import com.mangetsu.data.database.MangetsuDatabase
import com.mangetsu.data.database.entity.ChapterEntity
import com.mangetsu.data.database.entity.UpdateCheckEntity
import com.mangetsu.data.extension.ExtensionRepositoryImpl
import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.extensionapi.model.SManga
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LibraryUpdateService @Inject constructor(
    private val db:            MangetsuDatabase,
    private val extRepository: ExtensionRepositoryImpl
) {
    companion object {
        const val MIN_CHECK_INTERVAL_MS = 60 * 60 * 1000L
    }

    private val _status = MutableStateFlow(LibraryUpdateStatus())
    val status: Flow<LibraryUpdateStatus> = _status.asStateFlow()

    private val _updates = MutableStateFlow<List<MangaUpdate>>(emptyList())
    val updates: Flow<List<MangaUpdate>> = _updates.asStateFlow()

    val isRunning: Boolean get() = _status.value.state == UpdateCheckState.RUNNING

    suspend fun checkAll(force: Boolean = false) = withContext(Dispatchers.IO) {
        if (isRunning) return@withContext

        val cutoff  = if (force) Long.MAX_VALUE else System.currentTimeMillis() - MIN_CHECK_INTERVAL_MS
        val pending = db.updateCheckDao().getMangaDueForUpdate(cutoff)

        if (pending.isEmpty()) {
            Timber.d("LibraryUpdateService: nothing due for update check")
            return@withContext
        }

        _status.value = LibraryUpdateStatus(
            state = UpdateCheckState.RUNNING,
            total = pending.size
        )
        _updates.value = emptyList()

        var totalNew = 0
        val errors   = mutableListOf<String>()

        pending.forEachIndexed { index, manga ->
            _status.update { it.copy(current = index + 1, currentTitle = manga.title) }

            val result = checkSingleManga(manga.id, manga.sourceId, manga.url, manga.title)
            when {
                result.error != null     -> errors += "${manga.title}: ${result.error}"
                result.newChapters > 0   -> totalNew += result.newChapters
            }
        }

        _status.value = LibraryUpdateStatus(
            state      = UpdateCheckState.COMPLETED,
            current    = pending.size,
            total      = pending.size,
            newUpdates = totalNew,
            errors     = errors
        )
        Timber.i("LibraryUpdateService: done — $totalNew new chapters, ${errors.size} errors")
    }

    suspend fun checkSingleManga(
        mangaId:    Long,
        sourceId:   Long,
        mangaUrl:   String,
        mangaTitle: String
    ): UpdatesResult = withContext(Dispatchers.IO) {
        // Verify source is loaded
        extRepository.getSourceForId(sourceId) ?: return@withContext UpdatesResult(
            mangaId     = mangaId,
            newChapters = 0,
            error       = "Source not loaded (is the extension installed?)"
        )

        val sManga = SManga(id = mangaUrl, title = mangaTitle, url = mangaUrl)

        val remoteChapters = when (val result = extRepository.safeChapterList(sourceId, sManga)) {
            is ExtensionResult.Success -> result.data
            is ExtensionResult.Error   -> {
                recordCheckResult(mangaId, found = 0, error = result.message)
                return@withContext UpdatesResult(
                    mangaId = mangaId, newChapters = 0, error = result.message
                )
            }
        }

        val existingUrls = db.chapterDao()
            .getChaptersForMangaOnce(mangaId)
            .map { it.url }
            .toSet()

        val newEntities = remoteChapters
            .filterNot { it.url in existingUrls }
            .mapIndexed { idx, sc ->
                ChapterEntity(
                    mangaId       = mangaId,
                    sourceId      = sourceId,
                    url           = sc.url,
                    name          = sc.name,
                    chapterNumber = sc.chapterNumber,
                    volumeNumber  = sc.volumeNumber,
                    dateUpload    = sc.dateUpload,
                    scanlator     = sc.scanlator,
                    sourceOrder   = existingUrls.size + idx,
                    dateFetch     = System.currentTimeMillis()
                )
            }

        if (newEntities.isNotEmpty()) {
            db.chapterDao().upsertAll(newEntities)
            db.mangaDao().refreshCounts(mangaId)
            db.mangaDao().setLastUpdated(mangaId, System.currentTimeMillis())

            val manga    = db.mangaDao().getMangaById(mangaId)
            val feedItems = newEntities.map { ch ->
                MangaUpdate(
                    mangaId       = mangaId,
                    mangaTitle    = manga?.title ?: mangaTitle,
                    thumbnailUrl  = manga?.thumbnailUrl,
                    chapterId     = 0L,
                    chapterName   = ch.name,
                    chapterNumber = ch.chapterNumber,
                    dateFetch     = ch.dateFetch,
                    sourceId      = sourceId
                )
            }
            _updates.update { it + feedItems }
        }

        db.mangaDao().setLastChapterCheck(mangaId, System.currentTimeMillis())
        recordCheckResult(mangaId, found = newEntities.size, error = null)

        UpdatesResult(mangaId = mangaId, newChapters = newEntities.size)
    }

    fun clearUpdates()  { _updates.value = emptyList() }
    fun resetStatus()   { _status.value  = LibraryUpdateStatus() }

    private suspend fun recordCheckResult(mangaId: Long, found: Int, error: String?) {
        db.updateCheckDao().upsert(
            UpdateCheckEntity(
                mangaId          = mangaId,
                lastCheck        = System.currentTimeMillis(),
                newChaptersFound = found,
                errorMessage     = error
            )
        )
    }
}
