package com.mangetsu.data.extension.download

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadStateTest {

    @Test
    fun `Downloading isActive is true`() {
        val state = DownloadState.Downloading("com.test", 50, 512_000, 1_024_000)
        assertTrue(state.isActive)
    }

    @Test
    fun `Retrying isActive is true`() {
        val state = DownloadState.Retrying("com.test", 1, 3, 2_000)
        assertTrue(state.isActive)
    }

    @Test
    fun `Queued isActive is false`() {
        val state = DownloadState.Queued("com.test")
        assertFalse(state.isActive)
    }

    @Test
    fun `Completed isActive is false`() {
        val state = DownloadState.Completed("com.test", "/path/to.apk")
        assertFalse(state.isActive)
    }

    @Test
    fun `Failed isActive is false`() {
        val state = DownloadState.Failed("com.test", "HTTP 404")
        assertFalse(state.isActive)
    }

    @Test
    fun `Cancelled isActive is false`() {
        val state = DownloadState.Cancelled("com.test")
        assertFalse(state.isActive)
    }

    @Test
    fun `progressFloat clamps at 0f for negative progress`() {
        val state = DownloadState.Downloading("com.test", -1, 0, -1)
        assertEquals(0f, state.progressFloat, 0.001f)
    }

    @Test
    fun `progressFloat is 0_5 for 50 percent`() {
        val state = DownloadState.Downloading("com.test", 50, 512_000, 1_024_000)
        assertEquals(0.5f, state.progressFloat, 0.001f)
    }

    @Test
    fun `isIndeterminate true when progress is negative`() {
        val state = DownloadState.Downloading("com.test", -1, 0, -1)
        assertTrue(state.isIndeterminate)
    }

    @Test
    fun `isIndeterminate false when progress is zero`() {
        val state = DownloadState.Downloading("com.test", 0, 0, 1_000)
        assertFalse(state.isIndeterminate)
    }

    @Test
    fun `packageName is preserved across all states`() {
        val pkg = "com.my.extension"
        val states: List<DownloadState> = listOf(
            DownloadState.Queued(pkg),
            DownloadState.Downloading(pkg, 0, 0, 0),
            DownloadState.Retrying(pkg, 1, 3, 2000),
            DownloadState.Completed(pkg, "/path"),
            DownloadState.Failed(pkg, "error"),
            DownloadState.Cancelled(pkg)
        )
        states.forEach { assertEquals(pkg, it.packageName) }
    }
}

class InstallProgressTest {

    @Test
    fun `Downloading isActive is true`() {
        assertTrue(InstallProgress.Downloading("com.x", 20).isActive)
    }

    @Test
    fun `Retrying isActive is true`() {
        assertTrue(InstallProgress.Retrying("com.x", 1, 3).isActive)
    }

    @Test
    fun `Installing isActive is true`() {
        assertTrue(InstallProgress.Installing("com.x").isActive)
    }

    @Test
    fun `Done isActive is false`() {
        assertFalse(InstallProgress.Done("com.x").isActive)
    }

    @Test
    fun `Failed isActive is false`() {
        assertFalse(InstallProgress.Failed("com.x", "error").isActive)
    }
}
