package com.mangetsu.data.extension.engine

import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.SourceException
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga
import com.mangetsu.extensionapi.model.SPage
import dalvik.system.DexClassLoader
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SafeExtensionCallerTest {

    private lateinit var caller: SafeExtensionCaller

    @Before
    fun setup() {
        caller = SafeExtensionCaller()
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun mockSource(
        id: Long = 1L,
        block: MangaSource.() -> Unit = {}
    ): MangaSource = mockk<MangaSource>(relaxed = true) {
        every { this@mockk.id } returns id
        every { this@mockk.name } returns "MockSource"
        this.block()
    }

    private fun makeExt(source: MangaSource, pkg: String = "com.mock"): LoadedExtension =
        LoadedExtension(
            packageName = pkg,
            source      = source,
            classLoader = mockk(relaxed = true),
            apkPath     = "/mock.apk",
            versionCode = 1,
            versionName = "1.0",
            lang        = "en"
        )

    // ── Success path ──────────────────────────────────────────────────────────

    @Test
    fun `fetchPopularManga returns Success on happy path`() = runTest {
        val page   = MangasPage(emptyList(), false)
        val source = mockSource()
        coEvery { source.fetchPopularManga(1) } returns page

        val result = caller.fetchPopularManga(makeExt(source), page = 1)

        assertTrue(result.isSuccess)
        assertEquals(page, result.getOrNull())
    }

    @Test
    fun `fetchChapterList returns Success with list`() = runTest {
        val chapters = listOf(SChapter("c1", "Chapter 1"))
        val source   = mockSource()
        coEvery { source.fetchChapterList(any()) } returns chapters

        val result = caller.fetchChapterList(makeExt(source), SManga("m1", "Manga"))
        assertTrue(result.isSuccess)
        assertEquals(1, result.getOrNull()!!.size)
    }

    // ── Error isolation ───────────────────────────────────────────────────────

    @Test
    fun `RuntimeException inside source is caught and mapped to Error`() = runTest {
        val source = mockSource()
        coEvery { source.fetchPopularManga(any()) } throws RuntimeException("boom")

        val result = caller.fetchPopularManga(makeExt(source), 1)

        assertTrue(result.isError)
        val err = result as ExtensionResult.Error
        assertEquals(ErrorKind.SOURCE_EXCEPTION, err.kind)
        assertTrue(err.message.contains("boom"))
    }

    @Test
    fun `SourceException is caught and returned as SOURCE_EXCEPTION error`() = runTest {
        val source = mockSource()
        coEvery { source.fetchPopularManga(any()) } throws SourceException("rate limited")

        val result = caller.fetchPopularManga(makeExt(source), 1)

        assertTrue(result.isError)
        assertEquals(ErrorKind.SOURCE_EXCEPTION, (result as ExtensionResult.Error).kind)
    }

    @Test
    fun `NullPointerException inside source is caught`() = runTest {
        val source = mockSource()
        coEvery { source.fetchMangaDetails(any()) } throws NullPointerException("NPE in extension")

        val result = caller.fetchMangaDetails(makeExt(source), SManga("x", "X"))
        assertTrue(result.isError)
    }

    @Test
    fun `StackOverflowError inside source is caught`() = runTest {
        val source = mockSource()
        coEvery { source.fetchChapterList(any()) } throws StackOverflowError()

        val result = caller.fetchChapterList(makeExt(source), SManga("x", "X"))
        assertTrue(result.isError)
    }

    // ── Circuit breaker ───────────────────────────────────────────────────────

    @Test
    fun `circuit-open extension returns Error without calling source`() = runTest {
        val source = mockSource()
        // Create an ext whose circuit is already open
        val brokenExt = makeExt(source).copy(
            consecutiveErrors = LoadedExtension.CIRCUIT_BREAKER_THRESHOLD
        )

        assertTrue(brokenExt.isCircuitOpen)

        val result = caller.fetchPopularManga(brokenExt, 1)
        assertTrue(result.isError)
        // Source must NOT have been called
        io.mockk.coVerify(exactly = 0) { source.fetchPopularManga(any()) }
    }

    // ── Callback wiring ───────────────────────────────────────────────────────

    @Test
    fun `onCallResult callback fired with true on success`() = runTest {
        var capturedPkg: String? = null
        var capturedSuccess: Boolean? = null
        caller.onCallResult = { pkg, ok -> capturedPkg = pkg; capturedSuccess = ok }

        val source = mockSource()
        coEvery { source.fetchPopularManga(any()) } returns MangasPage(emptyList(), false)

        caller.fetchPopularManga(makeExt(source, "com.test.cb"), 1)

        assertEquals("com.test.cb", capturedPkg)
        assertEquals(true, capturedSuccess)
    }

    @Test
    fun `onCallResult callback fired with false on error`() = runTest {
        var capturedSuccess: Boolean? = null
        caller.onCallResult = { _, ok -> capturedSuccess = ok }

        val source = mockSource()
        coEvery { source.fetchPopularManga(any()) } throws RuntimeException("fail")

        caller.fetchPopularManga(makeExt(source), 1)
        assertEquals(false, capturedSuccess)
    }

    // ── Package attribution ───────────────────────────────────────────────────

    @Test
    fun `error result contains correct sourcePackage`() = runTest {
        val source = mockSource()
        coEvery { source.fetchLatestUpdates(any()) } throws RuntimeException("crash")

        val result = caller.fetchLatestUpdates(makeExt(source, "com.bad.ext"), 1)
        assertEquals("com.bad.ext", (result as ExtensionResult.Error).sourcePackage)
    }

    // ── Page resolution ───────────────────────────────────────────────────────

    @Test
    fun `fetchPageImageUrl forwards to source and returns updated page`() = runTest {
        val original = SPage(0, "https://page.html", null)
        val resolved = original.copy(imageUrl = "https://cdn.example.com/1.jpg")
        val source   = mockSource()
        coEvery { source.fetchPageImageUrl(original) } returns resolved

        val result = caller.fetchPageImageUrl(makeExt(source), original)

        assertTrue(result.isSuccess)
        assertEquals("https://cdn.example.com/1.jpg", result.getOrNull()?.imageUrl)
    }
}
