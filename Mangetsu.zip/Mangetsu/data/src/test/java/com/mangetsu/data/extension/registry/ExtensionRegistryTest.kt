package com.mangetsu.data.extension.registry

import com.mangetsu.data.extension.engine.ExtensionResult
import com.mangetsu.data.extension.engine.LoadedExtension
import com.mangetsu.data.extension.engine.SafeExtensionCaller
import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga
import com.mangetsu.extensionapi.model.SPage
import dalvik.system.DexClassLoader
import io.mockk.every
import io.mockk.mockk
import io.mockk.spyk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ExtensionRegistryTest {

    private lateinit var caller:   SafeExtensionCaller
    private lateinit var registry: ExtensionRegistry

    @Before
    fun setup() {
        caller   = spyk(SafeExtensionCaller())
        registry = ExtensionRegistry(caller)
        registry.initialise()
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun makeSource(id: Long, name: String): MangaSource = object : MangaSource {
        override val id   = id
        override val name = name
        override val lang = "en"
        override suspend fun fetchPopularManga(page: Int)                               = MangasPage(emptyList(), false)
        override suspend fun fetchLatestUpdates(page: Int)                              = MangasPage(emptyList(), false)
        override suspend fun fetchSearchManga(p: Int, q: String, f: FilterList)         = MangasPage(emptyList(), false)
        override suspend fun fetchMangaDetails(manga: SManga)                           = manga
        override suspend fun fetchChapterList(manga: SManga)                            = emptyList<SChapter>()
        override suspend fun fetchPageList(chapter: SChapter)                           = emptyList<SPage>()
    }

    private fun makeLoaded(packageName: String, sourceId: Long): LoadedExtension =
        LoadedExtension(
            packageName = packageName,
            source      = makeSource(sourceId, "Source $sourceId"),
            classLoader = mockk<DexClassLoader>(relaxed = true),
            apkPath     = "/fake/$packageName.apk",
            versionCode = 1,
            versionName = "1.0",
            lang        = "en"
        )

    // ── Registration ──────────────────────────────────────────────────────────

    @Test
    fun `register adds extension to both indices`() = runTest {
        val ext = makeLoaded("com.test.one", 111L)
        registry.register(ext)

        assertNotNull(registry.getExtensionByPackage("com.test.one"))
        assertNotNull(registry.getExtensionBySourceId(111L))
        assertEquals(1, registry.getAllExtensions().size)
    }

    @Test
    fun `registering same package replaces previous entry`() = runTest {
        val ext1 = makeLoaded("com.test.one", 111L)
        val ext2 = makeLoaded("com.test.one", 111L)    // same package / id

        registry.register(ext1)
        registry.register(ext2)

        assertEquals(1, registry.getAllExtensions().size)
    }

    @Test
    fun `unregister removes from both indices`() = runTest {
        val ext = makeLoaded("com.test.one", 111L)
        registry.register(ext)
        registry.unregister("com.test.one")

        assertNull(registry.getExtensionByPackage("com.test.one"))
        assertNull(registry.getSourceById(111L))
        assertTrue(registry.getAllExtensions().isEmpty())
    }

    @Test
    fun `unregister on unknown package is a no-op`() = runTest {
        registry.unregister("com.does.not.exist")  // must not throw
        assertTrue(registry.getAllExtensions().isEmpty())
    }

    // ── Querying ──────────────────────────────────────────────────────────────

    @Test
    fun `getAllSources returns only active extensions`() = runTest {
        val good = makeLoaded("com.test.good", 1L)
        registry.register(good)

        // Manually trip the circuit by injecting enough errors
        repeat(LoadedExtension.CIRCUIT_BREAKER_THRESHOLD) {
            caller.onCallResult?.invoke("com.test.good", false)
        }

        // The source should no longer appear in getAllSources
        assertTrue(registry.getAllSources().isEmpty())
    }

    @Test
    fun `getSourceById returns null for circuit-open extension`() = runTest {
        val ext = makeLoaded("com.test.broken", 99L)
        registry.register(ext)

        repeat(LoadedExtension.CIRCUIT_BREAKER_THRESHOLD) {
            caller.onCallResult?.invoke("com.test.broken", false)
        }

        assertNull(registry.getSourceById(99L))
    }

    // ── Circuit breaker ───────────────────────────────────────────────────────

    @Test
    fun `circuit opens after threshold consecutive errors`() = runTest {
        val ext = makeLoaded("com.test.flaky", 42L)
        registry.register(ext)

        repeat(LoadedExtension.CIRCUIT_BREAKER_THRESHOLD - 1) {
            caller.onCallResult?.invoke("com.test.flaky", false)
        }
        // Not yet tripped
        assertFalse(registry.getExtensionByPackage("com.test.flaky")!!.isCircuitOpen)

        // One more error — trips it
        caller.onCallResult?.invoke("com.test.flaky", false)
        assertTrue(registry.getExtensionByPackage("com.test.flaky")!!.isCircuitOpen)
    }

    @Test
    fun `consecutive error counter resets on success`() = runTest {
        val ext = makeLoaded("com.test.recovery", 55L)
        registry.register(ext)

        repeat(3) { caller.onCallResult?.invoke("com.test.recovery", false) }
        assertEquals(3, registry.getExtensionByPackage("com.test.recovery")!!.consecutiveErrors)

        caller.onCallResult?.invoke("com.test.recovery", true)
        assertEquals(0, registry.getExtensionByPackage("com.test.recovery")!!.consecutiveErrors)
    }

    @Test
    fun `resetCircuit re-enables a disabled extension`() = runTest {
        val ext = makeLoaded("com.test.reset", 77L)
        registry.register(ext)

        repeat(LoadedExtension.CIRCUIT_BREAKER_THRESHOLD) {
            caller.onCallResult?.invoke("com.test.reset", false)
        }
        assertTrue(registry.getExtensionByPackage("com.test.reset")!!.isCircuitOpen)

        registry.resetCircuit("com.test.reset")
        assertFalse(registry.getExtensionByPackage("com.test.reset")!!.isCircuitOpen)
        assertNotNull(registry.getSourceById(77L))
    }

    // ── State flow ────────────────────────────────────────────────────────────

    @Test
    fun `state flow emits updated snapshot after register`() = runTest {
        val ext = makeLoaded("com.test.flow", 200L)
        registry.register(ext)

        val snap = registry.state.first()
        assertTrue(snap.byPackage.containsKey("com.test.flow"))
        assertTrue(snap.bySourceId.containsKey(200L))
    }

    // ── Stats ─────────────────────────────────────────────────────────────────

    @Test
    fun `getStats returns correct success rate`() = runTest {
        val ext = makeLoaded("com.test.stats", 300L)
        registry.register(ext)

        repeat(8) { caller.onCallResult?.invoke("com.test.stats", true) }
        repeat(2) { caller.onCallResult?.invoke("com.test.stats", false) }

        val stats = registry.getStats().first()
        assertEquals(10L, stats.callCount)
        assertEquals(2L,  stats.errorCount)
        assertEquals(0.8f, stats.successRate, 0.01f)
    }

    @Test
    fun `getStats reports circuitOpen correctly`() = runTest {
        val ext = makeLoaded("com.test.statscircuit", 400L)
        registry.register(ext)

        repeat(LoadedExtension.CIRCUIT_BREAKER_THRESHOLD) {
            caller.onCallResult?.invoke("com.test.statscircuit", false)
        }

        val stats = registry.getStats().first()
        assertTrue(stats.circuitOpen)
    }
}
