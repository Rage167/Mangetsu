package com.mangetsu.data.extension.repo

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class RepoIndexParserTest {

    private lateinit var parser: RepoIndexParser

    @Before
    fun setup() {
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        parser = RepoIndexParser(moshi)
    }

    private val repoUrl = "https://test.repo/extensions"

    private fun validEntry(
        pkg:  String  = "com.test.source",
        name: String  = "Test Source",
        apk:  String  = "https://cdn.test/test.apk",
        code: Int     = 1,
        id:   Long    = 100L
    ) = """
        {
          "package": "$pkg",
          "name": "$name",
          "apkUrl": "$apk",
          "version": "1.0",
          "versionCode": $code,
          "lang": "en",
          "sourceId": $id,
          "nsfw": false
        }
    """.trimIndent()

    // ── Valid JSON ─────────────────────────────────────────────────────────────

    @Test
    fun `parses valid single entry`() {
        val json = "[${validEntry()}]"
        val result = parser.parse(json, repoUrl)
        assertTrue(result is ParseResult.Success)
        val entries = (result as ParseResult.Success).entries
        assertEquals(1, entries.size)
        assertEquals("com.test.source", entries[0].packageName)
        assertEquals("Test Source",     entries[0].name)
        assertEquals(100L,              entries[0].sourceId)
        assertEquals(repoUrl,           entries[0].repoUrl)
    }

    @Test
    fun `parses multiple valid entries`() {
        val json = "[${validEntry("com.a", "A", "https://cdn/a.apk", 1, 1L)}, " +
                      "${validEntry("com.b", "B", "https://cdn/b.apk", 2, 2L)}]"
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(2, result.entries.size)
    }

    @Test
    fun `parses empty array as success with no entries`() {
        val result = parser.parse("[]", repoUrl)
        assertTrue(result is ParseResult.Success)
        assertEquals(0, (result as ParseResult.Success).entries.size)
    }

    @Test
    fun `ignores extra unknown fields`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "version":"1","versionCode":1,"lang":"en","sourceId":999,
            "nsfw":false,"unknownFuture":"ignored"}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(1, result.entries.size)
    }

    @Test
    fun `defaults missing optional fields`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "versionCode":1,"sourceId":50}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        val entry = result.entries[0]
        assertEquals("1.0",   entry.versionName)
        assertEquals("en",    entry.lang)
        assertEquals(false,   entry.isNsfw)
    }

    // ── Invalid entries skipped ────────────────────────────────────────────────

    @Test
    fun `skips entry with missing package`() {
        val json = """[{"name":"X","apkUrl":"https://cdn/x.apk","versionCode":1,"sourceId":1}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(0, result.entries.size)
    }

    @Test
    fun `skips entry with missing apkUrl`() {
        val json = """[{"package":"com.x","name":"X","versionCode":1,"sourceId":1}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(0, result.entries.size)
    }

    @Test
    fun `skips entry with non-http apkUrl`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"ftp://cdn/x.apk",
            "versionCode":1,"sourceId":1}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(0, result.entries.size)
    }

    @Test
    fun `skips entry with zero sourceId`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "versionCode":1,"sourceId":0}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(0, result.entries.size)
    }

    @Test
    fun `skips entry with negative versionCode`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "versionCode":-1,"sourceId":1}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(0, result.entries.size)
    }

    @Test
    fun `keeps valid entries when mixed with invalid`() {
        val json = """[
            ${validEntry("com.good", "Good", "https://cdn/g.apk", 1, 1L)},
            {"package":"com.bad","name":"Bad"},
            ${validEntry("com.also.good", "AlsoGood", "https://cdn/ag.apk", 1, 2L)}
        ]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(2, result.entries.size)
        assertEquals("com.good",      result.entries[0].packageName)
        assertEquals("com.also.good", result.entries[1].packageName)
    }

    // ── Malformed JSON ─────────────────────────────────────────────────────────

    @Test
    fun `returns Failure for completely invalid JSON`() {
        val result = parser.parse("not json at all!!!", repoUrl)
        assertTrue(result is ParseResult.Failure)
        assertEquals(FailureReason.MALFORMED_JSON, (result as ParseResult.Failure).reason)
    }

    @Test
    fun `returns Failure for JSON object instead of array`() {
        val result = parser.parse("""{"name":"oops"}""", repoUrl)
        assertTrue(result is ParseResult.Failure)
    }

    @Test
    fun `returns Failure for empty string`() {
        val result = parser.parse("", repoUrl)
        assertTrue(result is ParseResult.Failure)
        assertEquals(FailureReason.EMPTY_RESPONSE, (result as ParseResult.Failure).reason)
    }

    @Test
    fun `returns Failure for blank string`() {
        val result = parser.parse("   ", repoUrl)
        assertTrue(result is ParseResult.Failure)
    }

    // ── Lang normalisation ─────────────────────────────────────────────────────

    @Test
    fun `normalises lang to lowercase`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "versionCode":1,"sourceId":1,"lang":"EN"}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals("en", result.entries[0].lang)
    }

    // ── Icon URL validation ────────────────────────────────────────────────────

    @Test
    fun `accepts valid https icon URL`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "versionCode":1,"sourceId":1,"iconUrl":"https://cdn/icon.png"}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals("https://cdn/icon.png", result.entries[0].iconUrl)
    }

    @Test
    fun `rejects non-http icon URL`() {
        val json = """[{"package":"com.x","name":"X","apkUrl":"https://cdn/x.apk",
            "versionCode":1,"sourceId":1,"iconUrl":"file:///icon.png"}]"""
        val result = parser.parse(json, repoUrl) as ParseResult.Success
        assertEquals(null, result.entries[0].iconUrl)
    }
}
