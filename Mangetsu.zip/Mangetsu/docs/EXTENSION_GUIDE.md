# Mangetsu Extension Developer Guide

## Overview

Mangetsu uses a **plugin system** where content sources are separate APKs installed
alongside the main app. This guide explains how to build and distribute your own extension.

---

## 1. How the Extension System Works

```
Host App (Mangetsu)
    │
    ├── ExtensionLoader
    │       └── Scans installed packages for `mangetsu.extension = true` meta-data
    │       └── Uses PathClassLoader to load the extension DEX at runtime
    │       └── Instantiates the class at `mangetsu.extension.source.class`
    │
    ├── ExtensionInstaller
    │       └── Downloads APK from repository URL
    │       └── Uses PackageInstaller API (no root required)
    │
    └── RepoFetcher
            └── Fetches index.json from user-added repository URLs
            └── Presents available extensions in the UI
```

---

## 2. Quick Start

### Step 1 — Copy the template

```bash
cp -r extension-template/ my-extension/
```

### Step 2 — Configure `build.gradle.kts`

```kotlin
val extName        = "My Source"           // shown in the UI
val extPackage     = "com.example.mysource"
val extVersionCode = 1
val extVersionName = "1.0.0"
val extLang        = "en"                  // ISO 639-1 code
val extSourceId    = 9876543210L           // MUST be globally unique — use a hash
```

### Step 3 — Implement `MangaSource`

Your source class must implement all required methods:

```kotlin
class MySource : MangaSource {
    override val id: Long   = 9876543210L
    override val name       = "My Source"
    override val lang       = "en"

    override suspend fun fetchPopularManga(page: Int): MangasPage { ... }
    override suspend fun fetchLatestUpdates(page: Int): MangasPage { ... }
    override suspend fun fetchSearchManga(page: Int, query: String, filters: FilterList): MangasPage { ... }
    override suspend fun fetchMangaDetails(manga: SManga): SManga { ... }
    override suspend fun fetchChapterList(manga: SManga): List<SChapter> { ... }
    override suspend fun fetchPageList(chapter: SChapter): List<SPage> { ... }
}
```

### Step 4 — Build the APK

```bash
./gradlew assembleRelease
```

### Step 5 — Host the repository

Create an `index.json` file:

```json
[
  {
    "name": "My Source",
    "package": "com.example.mysource",
    "apkUrl": "https://yourhost.com/my-source-v1.apk",
    "version": "1.0.0",
    "versionCode": 1,
    "lang": "en",
    "sourceId": 9876543210,
    "iconUrl": "https://yourhost.com/icon.png",
    "nsfw": false
  }
]
```

Host it at `https://yourhost.com/extensions/index.json`.  
Users add `https://yourhost.com/extensions` in **Extensions → Repos → +**.

---

## 3. MangaSource API Reference

### Models

| Class      | Purpose                                          |
|------------|--------------------------------------------------|
| `SManga`   | Manga metadata (title, cover, author, status...) |
| `SChapter` | Chapter metadata (name, number, date, scanlator) |
| `SPage`    | Single page (index, URL, optional imageUrl)      |
| `MangasPage` | Paginated manga list + hasNextPage flag        |

### Methods

| Method                  | Required | Notes                                               |
|-------------------------|----------|-----------------------------------------------------|
| `fetchPopularManga()`   | ✅       | 1-based `page` param                                |
| `fetchLatestUpdates()`  | ✅       | Can return empty if `supportsLatest = false`        |
| `fetchSearchManga()`    | ✅       | `filters` may be empty                              |
| `fetchMangaDetails()`   | ✅       | Input has `url` set; return fully populated SManga  |
| `fetchChapterList()`    | ✅       | Return newest-first                                 |
| `fetchPageList()`       | ✅       | `imageUrl` can be null — resolved lazily            |
| `fetchPageImageUrl()`   | ⚪ opt   | Only needed if imageUrl isn't known at list time    |
| `getFilterList()`       | ⚪ opt   | Return available search filters                     |

### Filters

```kotlin
override fun getFilterList() = FilterList(listOf(
    Filter.Select("Genre", arrayOf("All", "Action", "Romance")),
    Filter.CheckBox("Completed only"),
    Filter.Sort("Order", arrayOf("Popular", "New")),
    Filter.Text("Author")
))
```

---

## 4. Manifest Requirements

Every extension APK must declare these `<meta-data>` entries:

| Key                                   | Value                        | Required |
|---------------------------------------|------------------------------|----------|
| `mangetsu.extension`                  | `true`                       | ✅       |
| `mangetsu.extension.source.class`     | FQ class name of your source | ✅       |
| `mangetsu.extension.id`               | Unique Long (sourceId)       | ✅       |
| `mangetsu.extension.lang`             | ISO 639-1 code               | ✅       |
| `mangetsu.extension.version.code`     | Int version code             | ✅       |
| `mangetsu.extension.nsfw`             | `true` / `false`             | ⚪       |

---

## 5. Rules and Best Practices

- ✅ Respect `robots.txt` and Terms of Service of the source site.
- ✅ Use `compileOnly` for host-provided dependencies (OkHttp, extension-api).
- ✅ Handle HTTP errors with `SourceException("message")`.
- ✅ Return empty lists rather than throwing for "not found" scenarios.
- ✅ Make your source stateless — don't cache data inside the class.
- ❌ Never bundle copyrighted manga images or text in the APK.
- ❌ Never include API keys in public repositories.
- ❌ Don't crash on unknown status codes — throw `SourceException` instead.

---

## 6. Source ID Generation

Source IDs must be globally unique `Long` values. A simple way to generate one:

```kotlin
// Kotlin — use your package name as a seed
val id = "com.example.mysource".hashCode().toLong().absoluteValue + 1_000_000_000L
```

Or use an online CRC-32 calculator on your package name and convert to Long.

---

## 7. Testing Your Extension

Install your debug APK on a device/emulator alongside Mangetsu debug:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The extension should appear under **Extensions → Installed** within seconds.

---

## 8. Updating Your Extension

1. Increment `versionCode` in `build.gradle.kts`.
2. Build a new APK.
3. Update `index.json` on your host with the new `apkUrl` and `versionCode`.
4. Mangetsu will show an **Update available** badge to users.
