package com.mangetsu.domain.repository

import com.mangetsu.core.model.Chapter
import com.mangetsu.core.model.Download
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.History
import com.mangetsu.core.model.Manga
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.FilterList
import kotlinx.coroutines.flow.Flow

// ── Library ───────────────────────────────────────────────────────────────────

interface LibraryRepository {
    fun getLibraryManga(): Flow<List<Manga>>
    suspend fun getMangaByIdOrNull(id: Long): Manga?
    suspend fun getMangaByUrl(url: String, sourceId: Long): Manga?
    suspend fun upsertManga(manga: Manga): Long
    suspend fun setFavorite(mangaId: Long, favorite: Boolean)
    suspend fun updateManga(manga: Manga)
    suspend fun deleteManga(mangaId: Long)
    fun getUnreadCountFlow(): Flow<Int>
}

// ── Browse / Source ───────────────────────────────────────────────────────────

interface BrowseRepository {
    suspend fun getPopularManga(source: MangaSource, page: Int): MangasPage
    suspend fun getLatestManga(source: MangaSource, page: Int): MangasPage
    suspend fun searchManga(source: MangaSource, page: Int, query: String, filters: FilterList): MangasPage
    suspend fun getMangaDetails(source: MangaSource, manga: Manga): Manga
}

// ── Chapters ──────────────────────────────────────────────────────────────────

interface ChapterRepository {
    fun getChaptersForManga(mangaId: Long): Flow<List<Chapter>>
    suspend fun getChapterById(id: Long): Chapter?
    suspend fun syncChapters(mangaId: Long, source: MangaSource, manga: Manga): List<Chapter>
    suspend fun markChapterRead(chapterId: Long, lastPage: Int)
    suspend fun markAllRead(mangaId: Long)
    suspend fun updateDownloadStatus(chapterId: Long, downloaded: Boolean, pageCount: Int)
}

// ── Extensions ────────────────────────────────────────────────────────────────

interface ExtensionRepository {
    fun getInstalledExtensions(): Flow<List<Extension>>
    fun getAvailableExtensions(): Flow<List<Extension>>
    suspend fun refreshAvailableExtensions()
    suspend fun installExtension(extension: Extension)
    suspend fun uninstallExtension(packageName: String)
    fun getSourceForId(sourceId: Long): MangaSource?
    fun getAllSources(): List<MangaSource>
}

// ── Repos ─────────────────────────────────────────────────────────────────────

interface ExtensionRepoRepository {
    fun getRepos(): Flow<List<ExtensionRepo>>
    suspend fun addRepo(url: String): ExtensionRepo
    suspend fun removeRepo(id: Long)
    suspend fun refreshRepo(id: Long)
    suspend fun validateRepoUrl(url: String): Boolean
}

// ── History ───────────────────────────────────────────────────────────────────

interface HistoryRepository {
    fun getHistory(): Flow<List<History>>
    suspend fun upsertHistory(mangaId: Long, chapterId: Long, lastPage: Int)
    suspend fun deleteHistory(mangaId: Long)
    suspend fun clearAllHistory()
}

// ── Downloads ─────────────────────────────────────────────────────────────────

interface DownloadRepository {
    fun getDownloads(): Flow<List<Download>>
    suspend fun enqueueDownload(mangaId: Long, chapterId: Long)
    suspend fun cancelDownload(chapterId: Long)
    suspend fun cancelAllDownloads()
    suspend fun deleteDownloadedChapter(chapterId: Long)
}

// ── Backup ────────────────────────────────────────────────────────────────────

interface BackupRepository {
    suspend fun createBackup(): ByteArray
    suspend fun restoreBackup(data: ByteArray)
}
