package com.mangetsu.domain.usecase

import com.mangetsu.core.model.Chapter
import com.mangetsu.core.model.Extension
import com.mangetsu.core.model.ExtensionRepo
import com.mangetsu.core.model.Manga
import com.mangetsu.core.util.Result
import com.mangetsu.core.util.safeCall
import com.mangetsu.domain.repository.BrowseRepository
import com.mangetsu.domain.repository.ChapterRepository
import com.mangetsu.domain.repository.DownloadRepository
import com.mangetsu.domain.repository.ExtensionRepoRepository
import com.mangetsu.domain.repository.ExtensionRepository
import com.mangetsu.domain.repository.HistoryRepository
import com.mangetsu.domain.repository.LibraryRepository
import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangasPage
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

// ── Library ───────────────────────────────────────────────────────────────────

class GetLibraryUseCase @Inject constructor(
    private val repo: LibraryRepository
) {
    operator fun invoke(): Flow<List<Manga>> = repo.getLibraryManga()
}

class ToggleFavoriteUseCase @Inject constructor(
    private val repo: LibraryRepository
) {
    suspend operator fun invoke(mangaId: Long, favorite: Boolean): Result<Unit> =
        safeCall { repo.setFavorite(mangaId, favorite) }
}

class AddMangaToLibraryUseCase @Inject constructor(
    private val library: LibraryRepository
) {
    suspend operator fun invoke(manga: Manga): Result<Long> = safeCall {
        library.upsertManga(manga.copy(inLibrary = true, dateAdded = System.currentTimeMillis()))
    }
}

// ── Browse ────────────────────────────────────────────────────────────────────

class GetPopularMangaUseCase @Inject constructor(
    private val browseRepo: BrowseRepository,
    private val extRepo: ExtensionRepository
) {
    suspend operator fun invoke(sourceId: Long, page: Int): Result<MangasPage> = safeCall {
        val source = extRepo.getSourceForId(sourceId)
            ?: throw IllegalArgumentException("Source $sourceId not found")
        browseRepo.getPopularManga(source, page)
    }
}

class GetLatestMangaUseCase @Inject constructor(
    private val browseRepo: BrowseRepository,
    private val extRepo: ExtensionRepository
) {
    suspend operator fun invoke(sourceId: Long, page: Int): Result<MangasPage> = safeCall {
        val source = extRepo.getSourceForId(sourceId)
            ?: throw IllegalArgumentException("Source $sourceId not found")
        browseRepo.getLatestManga(source, page)
    }
}

class SearchMangaUseCase @Inject constructor(
    private val browseRepo: BrowseRepository,
    private val extRepo: ExtensionRepository
) {
    suspend operator fun invoke(
        sourceId: Long,
        page: Int,
        query: String,
        filters: FilterList = FilterList()
    ): Result<MangasPage> = safeCall {
        val source = extRepo.getSourceForId(sourceId)
            ?: throw IllegalArgumentException("Source $sourceId not found")
        browseRepo.searchManga(source, page, query, filters)
    }
}

class GetMangaDetailsUseCase @Inject constructor(
    private val browseRepo: BrowseRepository,
    private val extRepo: ExtensionRepository
) {
    suspend operator fun invoke(sourceId: Long, manga: Manga): Result<Manga> = safeCall {
        val source = extRepo.getSourceForId(sourceId)
            ?: throw IllegalArgumentException("Source $sourceId not found")
        browseRepo.getMangaDetails(source, manga)
    }
}

// ── Chapters ──────────────────────────────────────────────────────────────────

class GetChaptersUseCase @Inject constructor(
    private val chapterRepo: ChapterRepository
) {
    operator fun invoke(mangaId: Long): Flow<List<Chapter>> =
        chapterRepo.getChaptersForManga(mangaId)
}

class SyncChaptersUseCase @Inject constructor(
    private val chapterRepo: ChapterRepository,
    private val extRepo: ExtensionRepository
) {
    suspend operator fun invoke(mangaId: Long, sourceId: Long, manga: Manga): Result<List<Chapter>> =
        safeCall {
            val source = extRepo.getSourceForId(sourceId)
                ?: throw IllegalArgumentException("Source $sourceId not found")
            chapterRepo.syncChapters(mangaId, source, manga)
        }
}

class MarkChapterReadUseCase @Inject constructor(
    private val chapterRepo: ChapterRepository
) {
    suspend operator fun invoke(chapterId: Long, lastPage: Int = 0): Result<Unit> =
        safeCall { chapterRepo.markChapterRead(chapterId, lastPage) }
}

// ── Extensions ────────────────────────────────────────────────────────────────

class GetInstalledExtensionsUseCase @Inject constructor(
    private val repo: ExtensionRepository
) {
    operator fun invoke(): Flow<List<Extension>> = repo.getInstalledExtensions()
}

class GetAvailableExtensionsUseCase @Inject constructor(
    private val repo: ExtensionRepository
) {
    operator fun invoke(): Flow<List<Extension>> = repo.getAvailableExtensions()
}

class InstallExtensionUseCase @Inject constructor(
    private val repo: ExtensionRepository
) {
    suspend operator fun invoke(extension: Extension): Result<Unit> =
        safeCall { repo.installExtension(extension) }
}

class UninstallExtensionUseCase @Inject constructor(
    private val repo: ExtensionRepository
) {
    suspend operator fun invoke(packageName: String): Result<Unit> =
        safeCall { repo.uninstallExtension(packageName) }
}

class RefreshExtensionsUseCase @Inject constructor(
    private val repo: ExtensionRepository
) {
    suspend operator fun invoke(): Result<Unit> =
        safeCall { repo.refreshAvailableExtensions() }
}

// ── Repos ─────────────────────────────────────────────────────────────────────

class GetReposUseCase @Inject constructor(
    private val repo: ExtensionRepoRepository
) {
    operator fun invoke(): Flow<List<ExtensionRepo>> = repo.getRepos()
}

class AddRepoUseCase @Inject constructor(
    private val repo: ExtensionRepoRepository
) {
    suspend operator fun invoke(url: String): Result<ExtensionRepo> = safeCall {
        if (!repo.validateRepoUrl(url)) throw IllegalArgumentException("Invalid or unreachable repo URL")
        repo.addRepo(url)
    }
}

class RemoveRepoUseCase @Inject constructor(
    private val repo: ExtensionRepoRepository
) {
    suspend operator fun invoke(id: Long): Result<Unit> = safeCall { repo.removeRepo(id) }
}

// ── History ───────────────────────────────────────────────────────────────────

class GetHistoryUseCase @Inject constructor(
    private val repo: HistoryRepository
) {
    operator fun invoke() = repo.getHistory()
}

class RecordHistoryUseCase @Inject constructor(
    private val repo: HistoryRepository
) {
    suspend operator fun invoke(mangaId: Long, chapterId: Long, lastPage: Int) =
        safeCall { repo.upsertHistory(mangaId, chapterId, lastPage) }
}

class ClearHistoryUseCase @Inject constructor(
    private val repo: HistoryRepository
) {
    suspend operator fun invoke() = safeCall { repo.clearAllHistory() }
}

// ── Downloads ─────────────────────────────────────────────────────────────────

class EnqueueDownloadUseCase @Inject constructor(
    private val repo: DownloadRepository
) {
    suspend operator fun invoke(mangaId: Long, chapterId: Long): Result<Unit> =
        safeCall { repo.enqueueDownload(mangaId, chapterId) }
}

class GetDownloadsUseCase @Inject constructor(
    private val repo: DownloadRepository
) {
    operator fun invoke() = repo.getDownloads()
}
