package com.mangetsu.extensionapi

/**
 * Metadata about an installed or available extension.
 *
 * This is read from the extension APK's AndroidManifest.xml meta-data entries
 * and also from the repository JSON index.
 *
 * ## AndroidManifest meta-data keys (extension APK side):
 * ```xml
 * <meta-data android:name="mangetsu.extension.source.class"
 *            android:value=".MyMangaSource" />
 * <meta-data android:name="mangetsu.extension.id"      android:value="1234567890" />
 * <meta-data android:name="mangetsu.extension.version" android:value="1" />
 * ```
 */
data class ExtensionManifest(
    /** Extension package name (matches APK applicationId). */
    val packageName: String,

    /** Human-readable extension name. */
    val name: String,

    /** Version name string (e.g. "1.2.3"). */
    val versionName: String,

    /** Version code integer for update comparison. */
    val versionCode: Int,

    /** ISO 639-1 language code covered by the extension. */
    val lang: String,

    /** URL to download the APK from the repository. */
    val apkUrl: String,

    /** URL to the extension's icon image. */
    val iconUrl: String? = null,

    /** Fully-qualified class name of the [MangaSource] implementation. */
    val sourceClass: String,

    /** Numeric source ID. Must be globally unique. */
    val sourceId: Long,

    /** Whether this extension requires NSFW age-gate. */
    val isNsfw: Boolean = false
)
