package com.mangetsu.extensionapi

import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga
import com.mangetsu.extensionapi.model.SPage

/**
 * # MangaSource
 *
 * The core contract that every Mangetsu extension must implement.
 *
 * All methods are **suspend** functions and should be called from a coroutine scope.
 * Extensions are expected to be stateless — do not cache data inside the source instance.
 *
 * ## Implementation notes
 * - Return empty lists rather than throwing exceptions when content is unavailable.
 * - Throw [SourceException] for recoverable errors so the UI can display a useful message.
 * - Never hardcode API keys or access tokens in extensions distributed publicly.
 */
interface MangaSource {

    /** Stable, globally unique identifier for this source (e.g. reverse-DNS + numeric hash). */
    val id: Long

    /** Human-readable name shown in the UI. */
    val name: String

    /** ISO 639-1 language code (e.g. "en", "ja", "pt-BR"). */
    val lang: String

    /** Whether this source requires the user to be logged in. */
    val supportsLatest: Boolean get() = true

    // ──────────────────────────────────────────────────────────────
    // Browse / Discovery
    // ──────────────────────────────────────────────────────────────

    /**
     * Returns a paginated list of popular manga from this source.
     *
     * @param page 1-based page number.
     * @return [MangasPage] containing results and whether more pages exist.
     */
    suspend fun fetchPopularManga(page: Int): MangasPage

    /**
     * Returns the latest updated manga from this source.
     *
     * @param page 1-based page number.
     */
    suspend fun fetchLatestUpdates(page: Int): MangasPage

    /**
     * Searches this source for manga matching the given [query] and [filters].
     *
     * @param page   1-based page number.
     * @param query  Free-text search query.
     * @param filters Source-specific filter list (may be empty).
     */
    suspend fun fetchSearchManga(
        page: Int,
        query: String,
        filters: FilterList = FilterList()
    ): MangasPage

    // ──────────────────────────────────────────────────────────────
    // Detail Loading
    // ──────────────────────────────────────────────────────────────

    /**
     * Fetches and returns full details for a manga that was previously discovered
     * via [fetchPopularManga], [fetchLatestUpdates], or [fetchSearchManga].
     *
     * @param manga The partial [SManga] with at least [SManga.url] set.
     * @return Fully populated [SManga].
     */
    suspend fun fetchMangaDetails(manga: SManga): SManga

    /**
     * Fetches the list of chapters for the given manga.
     *
     * @param manga The manga whose chapters should be fetched.
     * @return List of [SChapter], typically ordered newest-first.
     */
    suspend fun fetchChapterList(manga: SManga): List<SChapter>

    // ──────────────────────────────────────────────────────────────
    // Page Loading
    // ──────────────────────────────────────────────────────────────

    /**
     * Fetches the page list for a given chapter.
     *
     * @param chapter The [SChapter] whose pages should be loaded.
     * @return Ordered list of [SPage].
     */
    suspend fun fetchPageList(chapter: SChapter): List<SPage>

    /**
     * Resolves the final direct image URL for a page whose [SPage.imageUrl] is null.
     * Called lazily only when the image is about to be displayed.
     *
     * @param page The [SPage] to resolve.
     * @return The same page with [SPage.imageUrl] set.
     */
    suspend fun fetchPageImageUrl(page: SPage): SPage = page

    // ──────────────────────────────────────────────────────────────
    // Filters
    // ──────────────────────────────────────────────────────────────

    /**
     * Returns the list of filters supported by this source's search.
     * Return [FilterList] with empty list if no filters are supported.
     */
    fun getFilterList(): FilterList = FilterList()
}

// ──────────────────────────────────────────────────────────────────────────────
// Supporting types
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Result wrapper for paginated manga lists.
 *
 * @property mangas List of [SManga] on the current page.
 * @property hasNextPage Whether there are further pages to load.
 */
data class MangasPage(
    val mangas: List<SManga>,
    val hasNextPage: Boolean
)

/**
 * Typed wrapper around a list of [Filter] objects, ensuring type-safety
 * when sources declare or consume filters.
 */
@JvmInline
value class FilterList(val filters: List<Filter<*>> = emptyList()) {
    operator fun plus(other: FilterList) = FilterList(filters + other.filters)
}

/**
 * Base class for all source-defined search filters.
 *
 * @param T The value type held by this filter (String, Int, Boolean, etc.).
 */
sealed class Filter<T>(
    val name: String,
    var state: T
) {
    /** Simple text input filter. */
    class Text(name: String, state: String = "") : Filter<String>(name, state)

    /** Boolean toggle (checkbox). */
    class CheckBox(name: String, state: Boolean = false) : Filter<Boolean>(name, state)

    /** Single-value select from a fixed list. */
    class Select(name: String, val values: Array<String>, state: Int = 0) :
        Filter<Int>(name, state)

    /** Multiple toggleable options. */
    class TriState(name: String, state: Int = STATE_IGNORE) : Filter<Int>(name, state) {
        companion object {
            const val STATE_IGNORE = 0
            const val STATE_INCLUDE = 1
            const val STATE_EXCLUDE = 2
        }
    }

    /** Grouping wrapper — contains sub-filters. */
    class Group<V>(name: String, val filters: List<Filter<V>>) :
        Filter<List<Filter<V>>>(name, filters)

    /** Sorting selector. */
    class Sort(
        name: String,
        val values: Array<String>,
        state: Selection? = null
    ) : Filter<Sort.Selection?>(name, state) {
        data class Selection(val index: Int, val ascending: Boolean)
    }
}

/**
 * Exception type thrown by sources for user-displayable errors.
 *
 * @param message Human-readable explanation.
 * @param cause   Original exception if wrapping another error.
 */
class SourceException(message: String, cause: Throwable? = null) :
    Exception(message, cause)
