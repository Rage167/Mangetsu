package com.mangetsu.extensionapi.model

/**
 * Represents a single chapter as returned by a [MangaSource].
 */
data class SChapter(
    /** Unique identifier within the source. Usually a relative URL path. */
    val id: String,

    /** Display name (e.g. "Chapter 42" or "Vol.3 Ch.12 - The Tournament"). */
    val name: String,

    /** Chapter number as a float (e.g. 12.5 for a "12.5 extra"). -1 if unknown. */
    val chapterNumber: Float = -1f,

    /** Volume number if available. */
    val volumeNumber: Float? = null,

    /** ISO-8601 upload date string, or epoch millis as string. */
    val dateUpload: Long = 0L,

    /** Scanlation group / uploader name. */
    val scanlator: String? = null,

    /** The URL to the chapter's reader page on the source. */
    val url: String = id,

    /** Language of this chapter (ISO 639-1 code). */
    val lang: String = "en"
)
