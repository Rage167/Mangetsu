package com.mangetsu.extensionapi.model

/**
 * Represents a manga entry as returned by a [MangaSource].
 * Extensions populate this with data from their respective sources.
 */
data class SManga(
    /** Unique identifier within the source. Usually a relative URL path. */
    val id: String,

    /** Display title of the manga. */
    val title: String,

    /** Thumbnail/cover art URL. */
    val thumbnailUrl: String? = null,

    /** Author of the manga. */
    val author: String? = null,

    /** Artist (if different from author). */
    val artist: String? = null,

    /** Full description/synopsis. */
    val description: String? = null,

    /** Genres/tags as a comma-separated string or list. */
    val genre: String? = null,

    /** Publication status. */
    val status: MangaStatus = MangaStatus.UNKNOWN,

    /** Whether full details have been fetched. */
    val initialized: Boolean = false,

    /** The URL to the manga's detail page on the source. */
    val url: String = id
)

enum class MangaStatus(val value: Int) {
    UNKNOWN(0),
    ONGOING(1),
    COMPLETED(2),
    LICENSED(3),
    PUBLISHING_FINISHED(4),
    CANCELLED(5),
    ON_HIATUS(6);

    companion object {
        fun fromValue(value: Int): MangaStatus =
            entries.firstOrNull { it.value == value } ?: UNKNOWN
    }
}
