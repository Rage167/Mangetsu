package com.mangetsu.extensionapi.model

/**
 * Represents a single page inside a chapter.
 *
 * The extension provides [url] and optionally an already-resolved [imageUrl].
 * If [imageUrl] is null, the loader will call [MangaSource.fetchPageImageUrl] to resolve it.
 */
data class SPage(
    /** 0-based index of the page within the chapter. */
    val index: Int,

    /** URL of the page container (may need further resolution). */
    val url: String,

    /** Direct URL to the image file. Null if not yet resolved. */
    val imageUrl: String? = null
)
