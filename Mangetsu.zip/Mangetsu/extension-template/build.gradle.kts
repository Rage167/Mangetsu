/**
 * Mangetsu Extension Template
 * ───────────────────────────
 * Copy this directory, rename the package, and implement MySource.kt.
 *
 * The resulting APK will be discoverable by the Mangetsu host app when:
 *   1. It declares the mangetsu.extension meta-data in its manifest.
 *   2. It is installed on the same device (or shared via a repo index.json).
 */
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ⬇️ Change these for every extension
val extName        = "Example Source"
val extPackage     = "com.mangetsu.extension.example"
val extVersionCode = 1
val extVersionName = "1.0.0"
val extLang        = "en"
val extSourceId    = 1_000_000_001L   // Must be globally unique — use a hash of your domain

android {
    namespace   = extPackage
    compileSdk  = 34

    defaultConfig {
        applicationId  = extPackage
        minSdk         = 26
        targetSdk      = 34
        versionCode    = extVersionCode
        versionName    = extVersionName

        // Manifest placeholders consumed by the template manifest
        manifestPlaceholders["extName"]     = extName
        manifestPlaceholders["extLang"]     = extLang
        manifestPlaceholders["extSourceId"] = extSourceId.toString()
        manifestPlaceholders["extClass"]    = "$extPackage.ExampleSource"
        manifestPlaceholders["extVersion"]  = extVersionCode.toString()
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // The extension-api JAR published by the Mangetsu project.
    // In a real setup this would be a Maven coordinate from your private registry
    // or a local file dependency:
    //   compileOnly(files("libs/extension-api.jar"))
    compileOnly("com.mangetsu:extension-api:1.0.0")

    // OkHttp is provided by the host — declare as compileOnly
    compileOnly("com.squareup.okhttp3:okhttp:4.12.0")

    // Any extra deps you need: jsoup, kotlinx-serialization, etc.
    // implementation("org.jsoup:jsoup:1.17.2")
}
