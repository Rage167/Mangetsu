package com.mangetsu.extension.example

import com.mangetsu.extensionapi.Filter
import com.mangetsu.extensionapi.FilterList
import com.mangetsu.extensionapi.MangaSource
import com.mangetsu.extensionapi.MangasPage
import com.mangetsu.extensionapi.SourceException
import com.mangetsu.extensionapi.model.MangaStatus
import com.mangetsu.extensionapi.model.SChapter
import com.mangetsu.extensionapi.model.SManga
import com.mangetsu.extensionapi.model.SPage
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response

/**
 * # ExampleSource
 *
 * A heavily-commented skeleton for a Mangetsu extension.
 *
 * ## Steps to create a real extension:
 * 1. Copy this file (and the template project) to a new module/repo.
 * 2. Change [id], [name], [lang] to match your source.
 * 3. Set `BASE_URL` to the target website or API root.
 * 4. Implement `fetchPopularManga`, `fetchMangaDetails`, `fetchChapterList`,
 *    `fetchPageList` using OkHttp + your preferred HTML/JSON parser.
 * 5. Update `build.gradle.kts` with a unique `extSourceId`.
 * 6. Build → distribute the APK (or publish to an index.json repository).
 *
 * ## Rules
 * - Do NOT hardcode credentials. Use a login flow if needed.
 * - Respect `robots.txt` and the site's Terms of Service.
 * - Never bundle content directly in the APK.
 */
class ExampleSource : MangaSource {

    // ──────────────────────────────────────────────────────────────────────────
    // Identity — these values MUST match your manifest meta-data
    // ──────────────────────────────────────────────────────────────────────────

    override val id: Long = 1_000_000_001L
    override val name: String = "Example Source"
    override val lang: String = "en"
    override val supportsLatest: Boolean = true

    // ──────────────────────────────────────────────────────────────────────────
    // HTTP client
    //
    // The host app already has an OkHttpClient singleton — in a real extension
    // you'd receive it via constructor injection or a static accessor provided
    // by the extension-api.  For simplicity we construct one here.
    // ──────────────────────────────────────────────────────────────────────────

    private val client: OkHttpClient = OkHttpClient.Builder().build()

    private val BASE_URL = "https://example-manga-site.com"

    // ──────────────────────────────────────────────────────────────────────────
    // Browse
    // ──────────────────────────────────────────────────────────────────────────

    override suspend fun fetchPopularManga(page: Int): MangasPage {
        // Example: GET /api/popular?page=1
        val response = client.get("$BASE_URL/api/popular?page=$page")
        return parseMangaListResponse(response)
    }

    override suspend fun fetchLatestUpdates(page: Int): MangasPage {
        val response = client.get("$BASE_URL/api/latest?page=$page")
        return parseMangaListResponse(response)
    }

    override suspend fun fetchSearchManga(
        page: Int,
        query: String,
        filters: FilterList
    ): MangasPage {
        // Build query params from filters
        val genre  = (filters.filters.firstOrNull { it is Filter.Select } as? Filter.Select)
            ?.let { it.values[it.state] } ?: ""

        val url = buildString {
            append("$BASE_URL/api/search?page=$page&q=$query")
            if (genre.isNotBlank()) append("&genre=$genre")
        }

        val response = client.get(url)
        return parseMangaListResponse(response)
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Detail loading
    // ──────────────────────────────────────────────────────────────────────────

    override suspend fun fetchMangaDetails(manga: SManga): SManga {
        val response = client.get("$BASE_URL${manga.url}")
        val body     = response.bodyString()

        // TODO: Replace with real HTML/JSON parsing (e.g. Jsoup, kotlinx.serialization)
        return manga.copy(
            title       = "Parsed Title",
            author      = "Parsed Author",
            description = "Parsed description from the detail page.",
            genre       = "Action, Adventure",
            status      = MangaStatus.ONGOING,
            initialized = true
        )
    }

    override suspend fun fetchChapterList(manga: SManga): List<SChapter> {
        val response = client.get("$BASE_URL${manga.url}/chapters")
        val body     = response.bodyString()

        // TODO: Parse chapter list from body
        return listOf(
            SChapter(
                id            = "/manga/example/chapter-1",
                name          = "Chapter 1",
                chapterNumber = 1f,
                dateUpload    = System.currentTimeMillis(),
                scanlator     = "Example Scans",
                url           = "/manga/example/chapter-1"
            )
        )
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Page loading
    // ──────────────────────────────────────────────────────────────────────────

    override suspend fun fetchPageList(chapter: SChapter): List<SPage> {
        val response = client.get("$BASE_URL${chapter.url}")
        val body     = response.bodyString()

        // TODO: Parse page URLs from body
        // imageUrl can be null here — the host will call fetchPageImageUrl() for lazy resolution
        return listOf(
            SPage(index = 0, url = "/manga/example/chapter-1/page-1", imageUrl = "https://cdn.example.com/img/1.jpg"),
            SPage(index = 1, url = "/manga/example/chapter-1/page-2", imageUrl = "https://cdn.example.com/img/2.jpg")
        )
    }

    /**
     * Called by the host when [SPage.imageUrl] is null.
     * Use this for sources that require a second request to resolve the final CDN URL.
     */
    override suspend fun fetchPageImageUrl(page: SPage): SPage {
        // Example: the page URL contains a JS variable with the real image URL
        val response = client.get("$BASE_URL${page.url}")
        val body     = response.bodyString()

        // TODO: extract actual image URL from body
        val imageUrl = "https://cdn.example.com/resolved-image.jpg"
        return page.copy(imageUrl = imageUrl)
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Filters
    // ──────────────────────────────────────────────────────────────────────────

    override fun getFilterList(): FilterList = FilterList(
        listOf(
            Filter.Select(
                name   = "Genre",
                values = arrayOf("All", "Action", "Adventure", "Comedy", "Drama", "Fantasy", "Romance", "Sci-Fi")
            ),
            Filter.Select(
                name   = "Status",
                values = arrayOf("Any", "Ongoing", "Completed")
            ),
            Filter.Sort(
                name   = "Sort by",
                values = arrayOf("Popularity", "Latest update", "Title")
            )
        )
    )

    // ──────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ──────────────────────────────────────────────────────────────────────────

    /** Stub — replace with real JSON/HTML parsing */
    private fun parseMangaListResponse(response: Response): MangasPage {
        if (!response.isSuccessful) {
            throw SourceException("HTTP ${response.code}: ${response.message}")
        }
        // TODO: parse JSON array from response.bodyString()
        return MangasPage(mangas = emptyList(), hasNextPage = false)
    }

    private fun OkHttpClient.get(url: String): Response {
        val request = Request.Builder().url(url)
            .addHeader("User-Agent", "Mozilla/5.0 (Mangetsu Extension)")
            .build()
        return newCall(request).execute()
    }

    private fun Response.bodyString(): String =
        body?.string() ?: throw SourceException("Empty response body")
}
